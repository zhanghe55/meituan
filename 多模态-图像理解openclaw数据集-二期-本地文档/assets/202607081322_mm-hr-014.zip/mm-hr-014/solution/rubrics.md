# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx
/meituan/mm-hr-014/solution/新员工培训排期表参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>和<file>/meituan/mm-hr-014/solution/新员工培训排期表参考答案.xlsx</file>中的Sheet名称完全一致，且顺序依次是'培训需求分析表'、'培训课程规划表'、'标准化培训排期表'。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>中'培训需求分析表'、'培训课程规划表'、'标准化培训排期表'三个sheet和<file>/meituan/mm-hr-014/solution/新员工培训排期表参考答案.xlsx</file>中三个sheet的列表头完全一致。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>的'培训需求分析表'中，岗位类型为销售岗对应的'高频短板问题'必须包含'产品知识薄弱'、'客户沟通弱'、'报价规则不熟'、'异议处理慢'的相关描述；岗位类型为运营岗对应的'高频短板问题'必须包含'系统操作不熟练'、'数据填报错误'、'活动复核不足'、'发布确认遗漏'的相关描述；岗位类型为客服岗对应的'高频短板问题'必须包含'合规话术边界不清'、'客诉流程不熟'、'客户确认遗漏'、'客诉升级判断慢'的相关描述；格式与排列顺序不做要求。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>与<file>/meituan/mm-hr-014/solution/新员工培训排期表参考答案.xlsx</file>的'培训课程规划表'中，'课程名称'、'适用岗位'、'负责部门'、'是否必修'列的文本与数值内容逐行完全一致。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-hr-014/input/answer/新员工培训排期表.xlsx</file>与<file>/meituan/mm-hr-014/solution/新员工培训排期表参考答案.xlsx</file>的'标准化培训排期表'中，'入职批次'、'培训日期'、'培训课程'、'适用岗位'、'参训人员'列的文本与数值内容逐行完全一致，且'培训日期'列日期的格式完全一致。",
    "weight": 1
  }
]
```
