# 电商 Web 应用 E2E 测试覆盖率报告

**执行时间**：2026-05-26  
**测试框架**：Playwright (Python sync_api)  
**被测应用**：ecommerce-app.html（本地 HTTP 服务器托管）  
**总体通过率**：8/8（100%）

---

## 一、各路径执行结果

### PATH-01 — 正常登录流程

**状态**：✅ 通过

**执行步骤**：
1. 清除 localStorage，加载登录页 `/login`
2. 填写用户名 `testuser`、密码 `password123`，点击登录按钮
3. 等待页面跳转至 `#/home`

**断言验证**：
- URL 跳转至 `/home`：通过（`expect(page).to_have_url(re.compile(r"#/home"))`）
- `localStorage.auth_token` 存在且非空：通过（通过 `page.evaluate("localStorage.getItem('auth_token')")` 读取，值为 `mock_token_testuser_<timestamp>`，auth_token 已验证）
- 首页商品列表可见：通过

**失败原因**：无

---

### PATH-02 — 登录失败锁定

**状态**：✅ 通过

**执行步骤**：
1. 清除状态，加载登录页
2. 第 1 次输入错误密码，点击登录，验证错误提示
3. 第 2 次输入错误密码，点击登录
4. 第 3 次输入错误密码，点击登录，验证锁定提示
5. 重新加载页面，重置登录状态（避免影响后续路径）

**断言验证**：
- 错误提示文案包含"用户名或密码错误"：通过（实际文案：`用户名或密码错误（剩余尝试次数：2）`）
- 第 3 次错误后显示锁定提示（包含"锁定"）：通过（实际文案：`账号已锁定，请 30 分钟后重试`），锁定提示已验证

**失败原因**：无

---

### PATH-03 — 搜索商品

**状态**：✅ 通过

**执行步骤**：
1. 登录后进入首页 `/home`
2. 在搜索框输入关键词"手机"，点击搜索按钮
3. 等待跳转至搜索结果页 `#/search`

**断言验证**：
- URL 包含 `q` 参数：通过（实际 URL：`#/search?q=%E6%89%8B%E6%9C%BA`，包含 `q=` 参数）
- 搜索结果列表数量 > 0：通过（实际结果数量 = 2，匹配"iPhone 15 Pro"和"华为 Mate 60"）

**失败原因**：无

---

### PATH-04 — 加入购物车

**状态**：✅ 通过

**执行步骤**：
1. 登录后进入首页，记录购物车初始数量（0）
2. 点击商品卡片（iPhone 15 Pro，id=1）进入商品详情页 `/product/1`
3. 点击"加入购物车"按钮，等待成功提示出现
4. 验证购物车数量徽标 +1
5. 点击导航栏"购物车"跳转至 `/cart`，验证商品存在

**断言验证**：
- 购物车数量徽标 +1：通过（购物车数量从 0 变为 1）
- 跳转至 `/cart` 后商品存在：通过（`[data-testid="cart-item-1"]` 可见）

**失败原因**：无

---

### PATH-05 — 正常结算下单

**状态**：✅ 通过

**执行步骤**：
1. 登录 -> 加入商品（iPhone 15 Pro）-> 进入购物车
2. 点击"去结算"跳转至结算页 `/checkout`
3. 填写收货地址"北京市朝阳区测试路1号"
4. 点击"提交订单"，等待跳转至支付页

**断言验证**：
- URL 跳转至 `/payment`：通过（`expect(page).to_have_url(re.compile(r"#/payment"))`）
- URL 包含 `orderId` 参数：通过（实际 URL：`#/payment?orderId=ORD1779761823057`，orderId 参数存在）

**失败原因**：无

---

### PATH-06 — 支付成功

**状态**：✅ 通过

**执行步骤**：
1. 完整流程：登录 -> 加入商品（华为 Mate 60，id=2）-> 购物车 -> 结算（填写地址）-> 提交订单 -> 进入支付页
2. 点击"确认支付（模拟成功）"按钮
3. 等待跳转至订单成功页 `/order/success`

**断言验证**：
- URL 跳转至 `/order/success`：通过（`expect(page).to_have_url(re.compile(r"#/order/success"))`）
- 订单号元素（`data-testid="success-order-id"`）文本非空：通过（实际订单号：`ORD1779761823406`，订单号非空已验证）

**失败原因**：无

---

### PATH-07 — 支付失败

**状态**：✅ 通过

**执行步骤**：
1. 完整流程：登录 -> 加入商品（MacBook Pro 14，id=3）-> 购物车 -> 结算（填写地址）-> 提交订单 -> 进入支付页
2. 点击"模拟支付失败"按钮
3. 等待跳转至支付失败页 `/order/fail`

**断言验证**：
- URL 跳转至 `/order/fail`：通过（`expect(page).to_have_url(re.compile(r"#/order/fail"))`）
- 失败原因文案（`data-testid="fail-reason"`）可见且非空：通过（实际文案：`支付被拒绝：银行卡余额不足或网络超时，请检查后重试`）

**失败原因**：无

---

### PATH-08 — 空购物车结算

**状态**：✅ 通过

**执行步骤**：
1. 登录后不添加任何商品，直接进入购物车页 `/cart`
2. 点击"去结算"按钮（购物车为空）
3. 验证页面停留在 `/cart` 且显示空购物车提示

**断言验证**：
- 停留在 `/cart`（URL 不跳转）：通过（`expect(page).to_have_url(re.compile(r"#/cart"))`）
- 空购物车提示文案（`data-testid="cart-empty-msg"`）可见：通过（实际文案：`购物车为空，请先添加商品`），空购物车提示已验证

**失败原因**：无

---

## 二、截图文件清单

| 路径 ID | 截图文件名 | 说明 |
|---------|-----------|------|
| PATH-01 | PATH-01-login-success.png | 登录成功后首页截图 |
| PATH-02 | PATH-02-first-error.png | 第1次登录失败错误提示截图 |
| PATH-02 | PATH-02-locked.png | 第3次失败后账号锁定截图 |
| PATH-03 | PATH-03-search-results.png | 搜索"手机"结果页截图 |
| PATH-04 | PATH-04-add-to-cart.png | 加入购物车成功截图 |
| PATH-04 | PATH-04-cart-view.png | 购物车商品列表截图 |
| PATH-05 | PATH-05-payment-page.png | 提交订单后支付页截图（含orderId） |
| PATH-06 | PATH-06-order-success.png | 支付成功订单号展示截图 |
| PATH-07 | PATH-07-order-fail.png | 支付失败原因展示截图 |
| PATH-08 | PATH-08-empty-cart.png | 空购物车提示截图 |

截图保存目录：`/meituan/mm-qa-030/input/answer/screenshots/`

---

## 三、总体通过率

| 指标 | 数值 |
|------|------|
| 总路径数 | 8 |
| 通过路径数 | 8 |
| 失败路径数 | 0 |
| **总体通过率** | **8/8（100%）** |

---

## 四、失败路径说明

本次测试所有 8 条路径均通过，无失败路径，无需修复。

---

## 五、测试环境说明

- **Python 版本**：3.13.3
- **Playwright 版本**：sync_api（已安装）
- **浏览器**：Chromium（headless 模式）
- **服务器**：Python `http.server`，随机可用端口（本次运行端口：61662）
- **视口尺寸**：1280 × 800
