"""
电商 Web 应用 E2E 自动化测试脚本
覆盖 PATH-01 ~ PATH-08 共 8 条测试路径
使用 playwright.sync_api 同步 API
"""

import os
import re
import sys
import socket
import threading
import http.server
import functools
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

# ===== 路径配置 =====
BASE_DIR = Path(__file__).parent
SCREENSHOTS_DIR = BASE_DIR / "screenshots"
HTML_FILE = Path(__file__).parent.parent / "ecommerce-app.html"

SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

# ===== 测试结果收集 =====
test_results = {}


def find_free_port():
    """自动探测可用端口"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


def start_server(directory, port):
    """在指定目录启动 HTTP 服务器"""
    handler = functools.partial(
        http.server.SimpleHTTPRequestHandler,
        directory=str(directory)
    )
    httpd = http.server.HTTPServer(("127.0.0.1", port), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd


def screenshot(page, name):
    """截图并保存"""
    path = str(SCREENSHOTS_DIR / name)
    page.screenshot(path=path, full_page=True)
    print(f"  [截图] {name}")
    return path


def record_result(path_id, passed, reason="", screenshots=None):
    test_results[path_id] = {
        "passed": passed,
        "reason": reason,
        "screenshots": screenshots or []
    }


# ===== PATH-01：正常登录流程 =====
def test_path_01(page, base_url):
    """PATH-01: 正常登录流程 /login -> /home"""
    print("\n[PATH-01] 正常登录流程")
    shots = []
    try:
        # 清除 localStorage，确保从登录页开始
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)

        # 填写正确的用户名和密码
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")

        # 等待跳转到 /home（hash 路由）
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 断言1：URL 包含 /home
        expect(page).to_have_url(re.compile(r"#/home"))

        # 断言2：localStorage 中 auth_token 存在
        auth_token = page.evaluate("localStorage.getItem('auth_token')")
        assert auth_token is not None and auth_token != "", \
            f"auth_token 不存在或为空，实际值：{auth_token}"

        # 断言3：首页内容可见
        expect(page.locator("[data-testid='home-products']")).to_be_visible(timeout=5000)

        shots.append(screenshot(page, "PATH-01-login-success.png"))
        record_result("PATH-01", True, "登录成功，URL跳转至/home，auth_token已验证", shots)
        print("  [PASS] PATH-01 通过")
    except Exception as e:
        shots.append(screenshot(page, "PATH-01-FAIL.png"))
        record_result("PATH-01", False, str(e), shots)
        print(f"  [FAIL] PATH-01 失败: {e}")


# ===== PATH-02：登录失败锁定 =====
def test_path_02(page, base_url):
    """PATH-02: 登录失败锁定 /login -> 锁定提示"""
    print("\n[PATH-02] 登录失败锁定")
    shots = []
    try:
        # 清除状态，重新加载登录页
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)

        # 第1次错误登录
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "wrongpass1")
        page.click("[data-testid='login-btn']")
        page.wait_for_selector("[data-testid='login-error']:not(.hidden)", timeout=5000)

        # 断言1：错误提示文案包含"用户名或密码错误"
        error_el = page.locator("[data-testid='login-error']")
        expect(error_el).to_be_visible(timeout=5000)
        error_text = error_el.inner_text()
        assert "用户名或密码错误" in error_text, \
            f"错误提示文案不包含'用户名或密码错误'，实际：{error_text}"

        shots.append(screenshot(page, "PATH-02-first-error.png"))

        # 第2次错误登录
        page.fill("[data-testid='login-password']", "wrongpass2")
        page.click("[data-testid='login-btn']")
        page.wait_for_timeout(500)

        # 第3次错误登录（触发锁定）
        page.fill("[data-testid='login-password']", "wrongpass3")
        page.click("[data-testid='login-btn']")
        page.wait_for_timeout(500)

        # 断言2：第3次错误后显示锁定提示
        lock_text = page.locator("[data-testid='login-error']").inner_text()
        assert "锁定" in lock_text or "locked" in lock_text.lower(), \
            f"锁定提示不包含'锁定'，实际：{lock_text}"

        shots.append(screenshot(page, "PATH-02-locked.png"))

        # 重置登录状态（避免影响后续路径）
        # 通过 JS 直接重置 state
        page.evaluate("""
            () => {
                // 重置登录按钮
                const btn = document.getElementById('login-btn');
                if (btn) btn.disabled = false;
                // 隐藏错误提示
                const err = document.getElementById('login-error');
                if (err) err.classList.add('hidden');
                // 清空输入框
                document.getElementById('login-username').value = '';
                document.getElementById('login-password').value = '';
            }
        """)
        # 通过重新加载页面彻底重置 JS state（loginAttempts/locked）
        page.reload()
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)

        record_result("PATH-02", True, "登录失败提示正常，第3次错误后锁定提示已验证", shots)
        print("  [PASS] PATH-02 通过")
    except Exception as e:
        shots.append(screenshot(page, "PATH-02-FAIL.png"))
        record_result("PATH-02", False, str(e), shots)
        print(f"  [FAIL] PATH-02 失败: {e}")


# ===== PATH-03：搜索商品 =====
def test_path_03(page, base_url):
    """PATH-03: 搜索商品 /home -> /search"""
    print("\n[PATH-03] 搜索商品")
    shots = []
    try:
        # 确保已登录
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 在首页搜索框输入关键词
        page.fill("[data-testid='home-search-input']", "手机")
        page.click("[data-testid='home-search-btn']")

        # 等待搜索结果页
        page.wait_for_url(re.compile(r"#/search"), timeout=10000)

        # 断言1：URL 包含 q 参数
        current_url = page.url
        assert "q=" in current_url or "search" in current_url, \
            f"URL 不包含 q 参数，实际 URL：{current_url}"

        # 断言2：搜索结果列表数量 > 0
        results = page.locator("[data-testid='search-results'] .product-card")
        count = results.count()
        assert count > 0, f"搜索结果数量为 0"

        shots.append(screenshot(page, "PATH-03-search-results.png"))
        record_result("PATH-03", True, f"搜索成功，URL包含q参数，结果数量={count}", shots)
        print(f"  [PASS] PATH-03 通过，搜索结果数量={count}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-03-FAIL.png"))
        record_result("PATH-03", False, str(e), shots)
        print(f"  [FAIL] PATH-03 失败: {e}")


# ===== PATH-04：加入购物车 =====
def test_path_04(page, base_url):
    """PATH-04: 加入购物车 /product/:id -> /cart（数量+1）"""
    print("\n[PATH-04] 加入购物车")
    shots = []
    try:
        # 确保已登录
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 记录加入购物车前的数量
        cart_count_before = int(page.locator("[data-testid='cart-count']").inner_text())

        # 点击第一个商品进入详情页
        page.locator("[data-testid='product-card-1']").click()
        page.wait_for_url(re.compile(r"#/product"), timeout=10000)
        page.wait_for_selector("[data-testid='add-to-cart-btn']", timeout=5000)

        # 点击加入购物车
        page.click("[data-testid='add-to-cart-btn']")
        page.wait_for_selector("[data-testid='add-cart-msg']:not(.hidden)", timeout=5000)

        # 断言1：购物车数量徽标 +1
        cart_count_after = int(page.locator("[data-testid='cart-count']").inner_text())
        assert cart_count_after == cart_count_before + 1, \
            f"购物车数量未+1，前={cart_count_before}，后={cart_count_after}"

        shots.append(screenshot(page, "PATH-04-add-to-cart.png"))

        # 跳转至购物车
        page.click("a[onclick=\"navigate('cart')\"]")
        page.wait_for_url(re.compile(r"#/cart"), timeout=10000)

        # 断言2：购物车中商品存在
        cart_item = page.locator("[data-testid='cart-item-1']")
        expect(cart_item).to_be_visible(timeout=5000)

        shots.append(screenshot(page, "PATH-04-cart-view.png"))
        record_result("PATH-04", True, f"加入购物车成功，数量从{cart_count_before}变为{cart_count_after}，购物车商品存在", shots)
        print(f"  [PASS] PATH-04 通过，购物车数量 {cart_count_before} -> {cart_count_after}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-04-FAIL.png"))
        record_result("PATH-04", False, str(e), shots)
        print(f"  [FAIL] PATH-04 失败: {e}")


# ===== PATH-05：正常结算下单 =====
def test_path_05(page, base_url):
    """PATH-05: 正常结算下单 /cart -> /payment（依赖PATH-04已加入商品）"""
    print("\n[PATH-05] 正常结算下单")
    shots = []
    try:
        # 确保已登录且购物车有商品（重新执行加入购物车流程）
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 加入商品到购物车
        page.locator("[data-testid='product-card-1']").click()
        page.wait_for_url(re.compile(r"#/product"), timeout=10000)
        page.click("[data-testid='add-to-cart-btn']")
        page.wait_for_selector("[data-testid='add-cart-msg']:not(.hidden)", timeout=5000)

        # 进入购物车
        page.click("a[onclick=\"navigate('cart')\"]")
        page.wait_for_url(re.compile(r"#/cart"), timeout=10000)
        page.wait_for_selector("[data-testid='checkout-btn']", timeout=5000)

        # 点击去结算
        page.click("[data-testid='checkout-btn']")
        page.wait_for_url(re.compile(r"#/checkout"), timeout=10000)

        # 填写收货地址
        page.fill("[data-testid='checkout-address']", "北京市朝阳区测试路1号")

        # 提交订单
        page.click("[data-testid='submit-order-btn']")

        # 等待跳转至支付页
        page.wait_for_url(re.compile(r"#/payment"), timeout=15000)

        # 断言1：URL 跳转至 /payment
        expect(page).to_have_url(re.compile(r"#/payment"))

        # 断言2：URL 包含 orderId 参数
        current_url = page.url
        assert "orderId=" in current_url, \
            f"URL 不包含 orderId 参数，实际 URL：{current_url}"

        shots.append(screenshot(page, "PATH-05-payment-page.png"))
        record_result("PATH-05", True, f"结算成功，URL跳转至/payment，orderId参数存在，URL={current_url}", shots)
        print(f"  [PASS] PATH-05 通过，URL={current_url}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-05-FAIL.png"))
        record_result("PATH-05", False, str(e), shots)
        print(f"  [FAIL] PATH-05 失败: {e}")


# ===== PATH-06：支付成功 =====
def test_path_06(page, base_url):
    """PATH-06: 支付成功 /payment -> /order/success"""
    print("\n[PATH-06] 支付成功")
    shots = []
    try:
        # 完整流程：登录 -> 加入购物车 -> 结算 -> 支付
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 加入商品
        page.locator("[data-testid='product-card-2']").click()
        page.wait_for_url(re.compile(r"#/product"), timeout=10000)
        page.click("[data-testid='add-to-cart-btn']")
        page.wait_for_selector("[data-testid='add-cart-msg']:not(.hidden)", timeout=5000)

        # 购物车 -> 结算
        page.click("a[onclick=\"navigate('cart')\"]")
        page.wait_for_url(re.compile(r"#/cart"), timeout=10000)
        page.click("[data-testid='checkout-btn']")
        page.wait_for_url(re.compile(r"#/checkout"), timeout=10000)
        page.fill("[data-testid='checkout-address']", "上海市浦东新区测试路2号")
        page.click("[data-testid='submit-order-btn']")
        page.wait_for_url(re.compile(r"#/payment"), timeout=15000)

        # 点击确认支付（模拟成功）
        page.click("[data-testid='pay-success-btn']")

        # 等待跳转至订单成功页
        page.wait_for_url(re.compile(r"#/order/success"), timeout=15000)

        # 断言1：URL 跳转至 /order/success
        expect(page).to_have_url(re.compile(r"#/order/success"))

        # 断言2：订单号元素文本非空
        order_id_el = page.locator("[data-testid='success-order-id']")
        expect(order_id_el).to_be_visible(timeout=5000)
        order_id_text = order_id_el.inner_text()
        assert order_id_text.strip() != "", \
            f"订单号元素文本为空"

        shots.append(screenshot(page, "PATH-06-order-success.png"))
        record_result("PATH-06", True, f"支付成功，URL跳转至/order/success，订单号非空={order_id_text}", shots)
        print(f"  [PASS] PATH-06 通过，订单号={order_id_text}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-06-FAIL.png"))
        record_result("PATH-06", False, str(e), shots)
        print(f"  [FAIL] PATH-06 失败: {e}")


# ===== PATH-07：支付失败 =====
def test_path_07(page, base_url):
    """PATH-07: 支付失败 /payment -> /order/fail"""
    print("\n[PATH-07] 支付失败")
    shots = []
    try:
        # 完整流程：登录 -> 加入购物车 -> 结算 -> 模拟支付失败
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 加入商品
        page.locator("[data-testid='product-card-3']").click()
        page.wait_for_url(re.compile(r"#/product"), timeout=10000)
        page.click("[data-testid='add-to-cart-btn']")
        page.wait_for_selector("[data-testid='add-cart-msg']:not(.hidden)", timeout=5000)

        # 购物车 -> 结算
        page.click("a[onclick=\"navigate('cart')\"]")
        page.wait_for_url(re.compile(r"#/cart"), timeout=10000)
        page.click("[data-testid='checkout-btn']")
        page.wait_for_url(re.compile(r"#/checkout"), timeout=10000)
        page.fill("[data-testid='checkout-address']", "广州市天河区测试路3号")
        page.click("[data-testid='submit-order-btn']")
        page.wait_for_url(re.compile(r"#/payment"), timeout=15000)

        # 点击模拟支付失败
        page.click("[data-testid='pay-fail-btn']")

        # 等待跳转至支付失败页
        page.wait_for_url(re.compile(r"#/order/fail"), timeout=15000)

        # 断言1：URL 跳转至 /order/fail
        expect(page).to_have_url(re.compile(r"#/order/fail"))

        # 断言2：失败原因文案可见
        fail_reason_el = page.locator("[data-testid='fail-reason']")
        expect(fail_reason_el).to_be_visible(timeout=5000)
        fail_text = fail_reason_el.inner_text()
        assert fail_text.strip() != "", f"失败原因文案为空"

        shots.append(screenshot(page, "PATH-07-order-fail.png"))
        record_result("PATH-07", True, f"支付失败流程正常，URL跳转至/order/fail，失败原因={fail_text}", shots)
        print(f"  [PASS] PATH-07 通过，失败原因={fail_text}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-07-FAIL.png"))
        record_result("PATH-07", False, str(e), shots)
        print(f"  [FAIL] PATH-07 失败: {e}")


# ===== PATH-08：空购物车结算 =====
def test_path_08(page, base_url):
    """PATH-08: 空购物车结算 /cart -> /cart（提示）"""
    print("\n[PATH-08] 空购物车结算")
    shots = []
    try:
        # 登录后直接进入空购物车
        page.goto(base_url)
        page.evaluate("localStorage.clear()")
        page.goto(base_url)
        page.wait_for_selector("[data-testid='login-username']", timeout=10000)
        page.fill("[data-testid='login-username']", "testuser")
        page.fill("[data-testid='login-password']", "password123")
        page.click("[data-testid='login-btn']")
        page.wait_for_url(re.compile(r"#/home"), timeout=10000)

        # 直接进入购物车（不加任何商品）
        page.click("a[onclick=\"navigate('cart')\"]")
        page.wait_for_url(re.compile(r"#/cart"), timeout=10000)
        page.wait_for_selector("[data-testid='checkout-btn']", timeout=5000)

        # 点击去结算（购物车为空）
        page.click("[data-testid='checkout-btn']")
        page.wait_for_timeout(1000)

        # 断言1：停留在 /cart（URL 不跳转）
        current_url = page.url
        assert "#/cart" in current_url, \
            f"应停留在/cart，实际 URL：{current_url}"
        expect(page).to_have_url(re.compile(r"#/cart"))

        # 断言2：空购物车提示文案可见
        empty_msg_el = page.locator("[data-testid='cart-empty-msg']")
        expect(empty_msg_el).to_be_visible(timeout=5000)
        empty_text = empty_msg_el.inner_text()
        assert empty_text.strip() != "", f"空购物车提示文案为空"

        shots.append(screenshot(page, "PATH-08-empty-cart.png"))
        record_result("PATH-08", True, f"空购物车结算正常，停留在/cart，提示文案={empty_text}", shots)
        print(f"  [PASS] PATH-08 通过，提示文案={empty_text}")
    except Exception as e:
        shots.append(screenshot(page, "PATH-08-FAIL.png"))
        record_result("PATH-08", False, str(e), shots)
        print(f"  [FAIL] PATH-08 失败: {e}")


# ===== 主执行入口 =====
def main():
    # 自动探测可用端口
    port = find_free_port()
    html_dir = str(HTML_FILE.parent)
    html_filename = HTML_FILE.name

    print(f"[服务器] 启动 HTTP 服务器，端口={port}，目录={html_dir}")
    httpd = start_server(html_dir, port)
    base_url = f"http://127.0.0.1:{port}/{html_filename}"
    print(f"[服务器] 应用地址：{base_url}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(viewport={"width": 1280, "height": 800})
        page = context.new_page()

        # 按顺序执行 8 条测试路径
        # PATH-04 和 PATH-05 有依赖关系，PATH-05 内部已包含加入购物车步骤
        test_path_01(page, base_url)
        test_path_02(page, base_url)
        test_path_03(page, base_url)
        test_path_04(page, base_url)
        test_path_05(page, base_url)
        test_path_06(page, base_url)
        test_path_07(page, base_url)
        test_path_08(page, base_url)

        context.close()
        browser.close()

    httpd.shutdown()

    # 打印汇总
    print("\n" + "=" * 60)
    print("测试执行汇总")
    print("=" * 60)
    passed = sum(1 for r in test_results.values() if r["passed"])
    total = len(test_results)
    for path_id, result in test_results.items():
        status = "PASS" if result["passed"] else "FAIL"
        print(f"  [{status}] {path_id}: {result['reason'][:80]}")
    print(f"\n总体通过率：{passed}/{total} ({passed/total*100:.1f}%)")
    print("=" * 60)

    return test_results


if __name__ == "__main__":
    results = main()
    # 如有失败则以非零退出码退出
    failed = [k for k, v in results.items() if not v["passed"]]
    if failed:
        print(f"\n失败路径：{', '.join(failed)}")
        sys.exit(1)
    else:
        print("\n所有测试路径均通过！")
        sys.exit(0)
