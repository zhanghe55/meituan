# Rubrics

> **rubric 权重合计 6 分,每条独立评分、互不重叠。**
>
> **门槛规则:BC-1 是门槛项(2 分)。BC-1 未通过则本卷判 0 分,BC-2~BC-5 一律不计分。** BC-1 通过后,BC-2~BC-5 各自独立判分。

## 文件读取路径
```path
/meituan/mm-sre-014/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【门槛项】<file>/meituan/mm-sre-014/input/answers.json</file> 须同时满足两个条件,任一不满足则 BC-1 得 0 分且 BC-2~BC-5 均不计分:(1) failed_service 判断为 `payment`(而非因调用它而报错的上游 checkout / frontend,也非错误率绝对值更高的常驻噪声 product-reviews);(2) fault_type 判断为错误型故障(gRPC 调用错误 / 报错,而非变慢或资源耗尽)。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "【新增增量 vs 常驻噪声,仅 BC-1 通过时计分】evidence 体现对『新增增量 vs 常驻噪声』的甄别:payment 错误率对齐注入时刻从干净的 0 拉起,而 frontend / product-reviews 虽绝对值高但基线本就有,是环境噪声须排除。提到 payment从0拉起、对齐注入时刻看时序拐点、product-reviews / frontend是背景噪声 / 基线高 中的任意一项即得分。本项只考甄别逻辑,不要求给出具体数值(数值在 BC-5 判)。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "【根因行为,仅 BC-1 通过时计分】root_cause 指向 paymentFailure 行为——payment 的 Charge gRPC 处理对(几乎)所有支付请求抛错(Invalid token / 应用层校验失败),checkout 在 PlaceOrder 中调用 payment.Charge,失败向上游传播导致下单失败。提到 paymentFailure、Charge、Invalid token、feature flag、checkout 调用 Charge 传播 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "【三信号运用,仅 BC-1 通过时计分】evidence 体现:trace 的 Charge span 带 error / gRPC ERROR / `Invalid token` 描述;checkout PlaceOrder span 同步失败(传播);日志层零 ERROR、签名藏在 WARN 级(`Invalid token`),不能只按 ERROR 过滤。提到 Charge span error / Invalid token、checkout PlaceOrder 传播、日志WARN签名或『别只过滤ERROR』 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "【量化峰值,仅 BC-1 通过时计分】evidence 指认关键信号并读出窗口内峰值量级(涉及具体数值时以窗口内最大值为准):(a) 指认到 payment(而非噪声 frontend / product-reviews)的错误率信号(traces_span_metrics_calls_total{status_code=\"STATUS_CODE_ERROR\",service_name=\"payment\"},或等价的看板 Error Rate 面板),(b) 明确的『0 → 峰 ~0.87/s』峰值量级读数。缺信号指认或缺峰值量级读数均不得分。",
    "weight": 1
  }
]
```
