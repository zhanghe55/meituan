**To:** orders@kitchenpro-factory.de
**From:** procurement@kitchenpro-factory.de
**Subject:** Purchase Order Submission – ORD-2026-003

---

Dear Orders Team,

Please find below the details of the purchase order we are submitting for production scheduling. The signed order form is attached as a PDF file.

---

**Order Details:**

**Order 1 – Casa Bella S.r.l.**
- Order No.: ORD-2026-003
- Dealer Name: Casa Bella S.r.l.
- Product Name: Wardrobe Set 2000mm (WRB-2000-SET)
- Quantity: 40 sets

---

Please confirm receipt of this order and proceed with production scheduling accordingly.

**Attachment:**
- `ORD-2026-003_Casa Bella S.r.l._order.pdf`

Best regards,
Procurement Department
KitchenPro Factory GmbH
procurement@kitchenpro-factory.de
