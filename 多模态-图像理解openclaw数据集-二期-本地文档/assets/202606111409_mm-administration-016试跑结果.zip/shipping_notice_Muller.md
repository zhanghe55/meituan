**To:** hans.mueller@muller-gmbh.de
**From:** procurement@kitchenpro-factory.de
**Subject:** Shipment Notice – ORD-2026-001 (Müller GmbH) – 2026-06-23

---

Dear Hans Müller,

We are pleased to inform you that your order is scheduled for shipment. Please find the shipment details below.

---

## Order Information

| Field | Details |
|---|---|
| Order No. | ORD-2026-001 |
| Product Name | Walk-in Wardrobe Set (WIC-4391-SET) |
| Shipment Quantity | 85 sets |
| Color Specification | Front: Ivory White (F-101) / Body: Warm White (B-102) |

---

## Cargo Information

| Field | Details |
|---|---|
| Total Volume | 45.6 m³ |
| Gross Weight | 8,500 kg |
| Container Arrangement | 2 × 20' containers (incl. 1 consolidated with Nordic Home AB ORD-2026-002) |

**Consolidated Shipment Note:** Your order volume (45.6 m³) exceeds one full 20' container (32.7 m³). The first container (32.7 m³) will be dispatched exclusively for your order on **2026-06-23**. The remaining volume (12.9 m³) will be consolidated with Nordic Home AB's remaining cargo in a shared container, dispatched on **2026-06-24**.

---

## Shipment Schedule

| Container | Contents | Estimated Dispatch Date | Estimated Arrival Date |
|---|---|---|---|
| Container 1 (Full, Müller only) | ORD-2026-001 partial (32.7 m³) | 2026-06-23 | 2026-07-23 |
| Container 2 (Consolidated) | ORD-2026-001 remainder (12.9 m³) + ORD-2026-002 remainder (5.7 m³) | 2026-06-24 | 2026-07-24 |

---

## Balance Payment Information

| Field | Details |
|---|---|
| Balance Amount | EUR 50,575.00 (70% of EUR 72,250.00) |
| Payment Due Date | **2026-06-09** (14 days before scheduled shipment on 2026-06-23) |
| Remittance Account | KitchenPro Factory GmbH, IBAN: DE12 6007 0070 0512 3456 00, BIC: COBADEFFXXX |

Please ensure the balance payment is received by **2026-06-09** to avoid any delay in shipment.

---

## Import Clearance Documents

The following documents will be provided for import customs clearance. Please ensure your customs broker is prepared to receive them:

1. **Commercial Invoice** – Issued by KitchenPro Factory GmbH; states the declared value, product description, quantity, and terms of sale (Incoterms). Required for customs valuation and duty assessment.

2. **Packing List** – Details the contents, dimensions, gross/net weight, and carton count of each container. Required for customs inspection and cargo verification.

3. **Bill of Lading (B/L)** – Issued by the shipping carrier; serves as the title document for the goods and is required to take delivery at the destination port.

4. **Certificate of Origin** – Certifies the country of manufacture (Germany). Required for preferential tariff treatment under applicable trade agreements (e.g., EU–Germany origin).

5. **Customs Export Declaration (EX1 / AES Filing)** – Filed by the exporter with German customs authorities. Required for legal export from the EU.

6. **Fumigation Certificate (if applicable)** – Required if wooden packaging materials (pallets, crates) are used, in accordance with ISPM 15 phytosanitary standards.

> **Note:** Furniture products (HS Chapter 94) are standard commercial goods and do not require special import/export licenses under normal circumstances. However, if any components contain materials subject to CITES regulations (e.g., certain tropical wood species), an additional CITES permit may be required. Please confirm with your customs broker if applicable.

---

Should you have any questions regarding the shipment arrangement, please do not hesitate to contact us.

Best regards,
Procurement Department
KitchenPro Factory GmbH
procurement@kitchenpro-factory.de
Tel: +49 711 123456
