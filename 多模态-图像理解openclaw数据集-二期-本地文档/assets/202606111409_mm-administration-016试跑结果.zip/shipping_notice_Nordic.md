**To:** order@nordichome.se
**From:** procurement@kitchenpro-factory.de
**Subject:** Shipment Notice – ORD-2026-002 (Nordic Home AB) – 2026-06-24

---

Dear Nordic Home AB Purchasing Department,

We are pleased to inform you that your order is scheduled for shipment. Please find the shipment details below.

---

## Order Information

| Field | Details |
|---|---|
| Order No. | ORD-2026-002 |
| Product Name | Dining Chair 850mm (DC-850-SET) |
| Shipment Quantity | 200 sets |
| Color Specification | Front: Warm Grey (F-175) / Body: Natural Oak (B-310) |

---

## Cargo Information

| Field | Details |
|---|---|
| Total Volume | 38.4 m³ |
| Gross Weight | 3,200 kg |
| Container Arrangement | 2 × 20' containers (incl. 1 consolidated with Müller GmbH ORD-2026-001) |

**Consolidated Shipment Note:** Your order volume (38.4 m³) exceeds one full 20' container (32.7 m³). The first container (32.7 m³) will be dispatched exclusively for your order on **2026-06-24**. The remaining volume (5.7 m³) will be consolidated with Müller GmbH's remaining cargo (12.9 m³) in a shared container, also dispatched on **2026-06-24**.

---

## Shipment Schedule

| Container | Contents | Estimated Dispatch Date | Estimated Arrival Date |
|---|---|---|---|
| Container 1 (Full, Nordic only) | ORD-2026-002 partial (32.7 m³) | 2026-06-24 | 2026-07-24 |
| Container 2 (Consolidated) | ORD-2026-002 remainder (5.7 m³) + ORD-2026-001 remainder (12.9 m³) | 2026-06-24 | 2026-07-24 |

---

## Balance Payment Information

| Field | Details |
|---|---|
| Balance Amount | EUR 22,400.00 (70% of EUR 32,000.00) |
| Payment Due Date | **2026-06-10** (14 days before scheduled shipment on 2026-06-24) |
| Remittance Account | KitchenPro Factory GmbH, IBAN: DE12 6007 0070 0512 3456 00, BIC: COBADEFFXXX |

Please ensure the balance payment is received by **2026-06-10** to avoid any delay in shipment.

---

## Import Clearance Documents

The following documents will be provided for import customs clearance. Please ensure your customs broker is prepared to receive them:

1. **Commercial Invoice** – Issued by KitchenPro Factory GmbH; states the declared value, product description, quantity, and terms of sale (Incoterms). Required for customs valuation and duty assessment.

2. **Packing List** – Details the contents, dimensions, gross/net weight, and carton count of each container. Required for customs inspection and cargo verification.

3. **Bill of Lading (B/L)** – Issued by the shipping carrier; serves as the title document for the goods and is required to take delivery at the destination port.

4. **Certificate of Origin** – Certifies the country of manufacture (Germany). Required for preferential tariff treatment under applicable trade agreements (e.g., EU–Germany origin).

5. **Customs Export Declaration (EX1 / AES Filing)** – Filed by the exporter with German customs authorities. Required for legal export from the EU.

6. **Fumigation Certificate (if applicable)** – Required if wooden packaging materials (pallets, crates) are used, in accordance with ISPM 15 phytosanitary standards. This is particularly relevant for your order given the Natural Oak body material.

> **Note:** Furniture products (HS Chapter 94) are standard commercial goods and do not require special import/export licenses under normal circumstances. However, if any components contain materials subject to CITES regulations (e.g., certain tropical wood species such as Natural Oak sourced from regulated regions), an additional CITES permit may be required. Please confirm with your customs broker if applicable.

---

Should you have any questions regarding the shipment arrangement, please do not hesitate to contact us.

Best regards,
Procurement Department
KitchenPro Factory GmbH
procurement@kitchenpro-factory.de
Tel: +49 711 123456
