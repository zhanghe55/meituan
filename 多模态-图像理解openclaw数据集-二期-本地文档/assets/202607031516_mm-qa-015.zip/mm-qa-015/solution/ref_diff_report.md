# API接口差异报告

## 差异汇总

### 差异1：POST /api/v1/users 响应中 age 字段类型不一致
- **HTTP端点**：`POST /api/v1/users`
- **字段名**：`age`
- **type**：`data_type`
- **Swagger定义**：`integer`（见 swagger_api.html POST /api/v1/users Response 201）
- **实际返回值**：`"28"`（字符串）
- **JSON路径**：`response.data.age`
- **分析**：Swagger 文档定义 age 为 integer，实际返回值为字符串 `"28"`，与 Swagger 定义的类型不一致。此差异涉及 Swagger 文档对比。

### 差异2：截图 api_doc_01.png 中 POST /api/v1/users 参数 age 类型与 Swagger 不一致
- **HTTP端点**：`POST /api/v1/users`
- **字段名**：`age`
- **type**：`data_type`
- **Swagger定义**：`integer`（见 swagger_api.html POST /api/v1/users Parameters）
- **截图定义**：`string`（见 api_doc_01.png POST /api/v1/users 参数表，age 的 Type 列为 string）
- **分析**：截图中 POST /api/v1/users 参数表的 age 类型标注为 string，与 Swagger 文档定义的 integer 不一致。此差异为截图与 Swagger 文档定义对比，不涉及实际返回值。
- **截图编号**：`api_doc_01.png`

### 差异3：边界值推断 — POST /api/v1/users 缺少 age 类型校验
- **HTTP端点**：`POST /api/v1/users`
- **字段名**：`age`
- **type**：`required_field`
- **边界值测试用例**：`TC-003`
- **触发数据来源**：`test_data_boundary.json`，不在 `response_logs.json` 中
- **分析**：TC-003 构造了 age 为字符串 `"twenty-five"` 的请求，预期返回 400。结合 Swagger 定义 age 为 integer（必填），推断接口缺少对 age 字段的类型校验。实际 response_logs.json 中 POST /api/v1/users 返回 201 且 age 为字符串 `"28"`，进一步验证了类型校验缺失。

### 差异4：边界值推断 — POST /api/v1/orders 缺少 quantity 正数校验
- **HTTP端点**：`POST /api/v1/orders`
- **字段名**：`quantity`
- **type**：`required_field`
- **边界值测试用例**：`TC-006`
- **触发数据来源**：`test_data_boundary.json`，不在 `response_logs.json` 中
- **分析**：TC-006 构造了 quantity 为 `-5` 的请求，预期返回 400。Swagger 定义 quantity 为 integer（must be positive），推断接口缺少对 quantity 字段的正数校验。

### 差异5：边界值推断 — POST /api/v1/users 缺少 email 格式校验
- **HTTP端点**：`POST /api/v1/users`
- **字段名**：`email`
- **type**：`required_field`
- **边界值测试用例**：`TC-005`
- **触发数据来源**：`test_data_boundary.json`，不在 `response_logs.json` 中
- **分析**：TC-005 构造了包含特殊字符的 email 请求（`test<script>alert('xss')</script>@example.com`），预期返回 400。Swagger 定义 email 为 valid format，推断接口缺少对 email 字段的格式校验。
