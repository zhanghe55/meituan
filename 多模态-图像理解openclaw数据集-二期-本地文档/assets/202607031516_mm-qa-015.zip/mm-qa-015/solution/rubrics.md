# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-qa-015/input/answer/diff_report.md
/meituan/mm-qa-015/input/answer/test_cases.json
/meituan/mm-qa-015/solution/ref_diff_report.md
/meituan/mm-qa-015/solution/ref_test_cases.json
```

---

## 打分规则

```json
[
  {
    "id": "01",
    "content": "已输出<file>/meituan/mm-qa-015/input/answer/diff_report.md</file>和<file>/meituan/mm-qa-015/input/answer/test_cases.json</file>两个文件，若缺少任意一个文件，则整体判定为 FAIL。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "读取<file>/meituan/mm-qa-015/input/answer/diff_report.md</file>，与<file>/meituan/mm-qa-015/solution/ref_diff_report.md</file>对照，检查差异描述是否在参考答案范围内：须包含至少4个有效差异，且每个差异的type字段必须是以下之一：field_name/data_type/required_field/response_structure/missing_field；类型未使用指定枚举值的差异不计入有效数量。若有效差异不足4个、或存在不在参考答案范围内的差异、或type枚举值不正确，则不得分。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "读取<file>/meituan/mm-qa-015/input/answer/diff_report.md</file>，报告中每个涉及实际返回值的差异必须引用具体JSON路径，且路径必须精确到字段级别；对于missing_field类型的差异，路径须写至缺失字段本身，并注明'该字段在实际返回中不存在'。JSON路径须与<file>/meituan/mm-qa-015/solution/ref_diff_report.md</file>一致。缺少任意一项字段、路径层级不正确或与参考答案不一致不得分。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "读取<file>/meituan/mm-qa-015/input/answer/diff_report.md</file>，报告中至少1个差异必须明确引用边界值测试用例ID，引用ID须为TC-003、TC-005、TC-006之一，未引用测试用例ID或引用ID不在上述范围内不得分。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "读取<file>/meituan/mm-qa-015/input/answer/diff_report.md</file>，报告中至少1个差异必须涉及Swagger文档定义与截图定义或实际返回值的对比说明，未涉及Swagger文档对比不得分。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "读取<file>/meituan/mm-qa-015/input/answer/test_cases.json</file>，与<file>/meituan/mm-qa-015/solution/ref_test_cases.json</file>对照，检查用例内容是否一致：必须为根级JSON数组格式，且每条用例必须包含method、url、params、expected_status四个字段，params必须为键值对对象，用例内容须与diff_report.md中发现的差异关联，体现对具体问题的回归验证意图。顶层格式不正确、缺少任意字段或用例与差异报告无关联不得分。",
    "weight": 1
  }
]
```
