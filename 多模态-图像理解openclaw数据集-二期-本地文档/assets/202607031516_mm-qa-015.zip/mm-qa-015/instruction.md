# API接口自动化测试 - 接口文档截图与响应数据校验

## 任务背景
你是API测试工程师，收到了一组API接口文档的截图（PNG格式）、Swagger在线文档和对应的curl命令输出日志。你需要以Swagger文档为权威定义基准，对比实际响应数据与Swagger定义之间的差异；截图作为辅助参考，用于识别文档自身的不一致问题。

## 可用资源
1. **接口文档截图**：位于 `/meituan/mm-qa-015/input/api_doc_screenshots/` 目录，包含3张截图：
   - `api_doc_01.png` - 用户接口文档截图
   - `api_doc_02.png` - 订单接口文档截图
   - `api_doc_03.png` - 产品接口文档截图

2. **接口响应日志**：位于 `/meituan/mm-qa-015/input/response_logs.json`，包含6个接口的实际curl请求响应数据

3. **边界值测试数据**：位于 `/meituan/mm-qa-015/input/test_data_boundary.json`，包含8个边界场景测试用例

4. **Swagger API文档**：位于 `/meituan/mm-qa-015/input/swagger_api.html`

## 任务要求

### 第一步：读取接口文档截图（辅助参考）
1. 依次读取 `/meituan/mm-qa-015/input/api_doc_screenshots/` 目录中的3张PNG截图
2. 从截图中提取接口端点路径、HTTP方法、参数列表和响应示例，作为后续对比的辅助参考

### 第二步：部署并查看Swagger文档（权威基准）
1. 使用Python内置模块或系统工具启动本地HTTP服务，将swagger_api.html部署为可访问的Web页面
2. 使用browser工具打开部署后的Swagger文档页面
3. 从页面中提取各个接口的完整参数定义和响应示例，作为差异对比的权威基准
4. 将Swagger文档中的定义与截图中的定义进行对比，识别文档自身的不一致问题

### 第三步：读取响应日志
1. 读取 `/meituan/mm-qa-015/input/response_logs.json` 文件
2. 提取每个接口的实际返回数据

### 第四步：对比分析差异
以Swagger文档为权威定义基准，识别以下类型的差异：
- **field_name**：字段名差异
- **data_type**：数据类型差异（如integer vs string）
- **required_field**：必填项差异或参数校验缺失
- **response_structure**：响应结构差异
- **missing_field**：字段缺失（实际返回值或截图中缺少Swagger定义的字段）

需覆盖以下对比维度，优先级由高到低：
1. **实际返回 vs Swagger**（核心）：实际返回值与Swagger文档不一致时必须记录
2. **截图 vs Swagger**（辅助）：截图定义与Swagger文档不一致时记录，标注"此差异为截图与Swagger文档定义对比，不涉及实际返回值"
3. **截图 vs 实际返回**：仅在截图与Swagger定义一致时，此维度结论方可作为辅助佐证

至少1个差异必须通过边界值测试用例推断触发（标注对应TC-ID），至少1个差异必须明确涉及Swagger文档对比。差异报告中有效差异总数不少于4个。

### 第五步：引用边界值测试用例
1. 读取 `/meituan/mm-qa-015/input/test_data_boundary.json` 中的测试用例
2. 根据测试用例的入参设计和预期状态码，结合Swagger定义，识别接口可能存在的校验缺失或行为异常
3. 在差异报告中，将通过边界值用例推断出的差异标注对应的测试用例ID（TC-001至TC-008），并注明触发数据来自test_data_boundary.json，不在response_logs.json中

### 第六步：生成输出
1. 生成接口差异报告：`/meituan/mm-qa-015/input/answer/diff_report.md`
2. 生成基于差异分析的回归测试用例：`/meituan/mm-qa-015/input/answer/test_cases.json`，每条用例须针对差异报告中发现的具体问题设计，用于验证该问题修复后的接口行为是否符合Swagger定义

## 输出路径
| 文件 | 路径 |
|------|------|
| 接口差异报告 | `/meituan/mm-qa-015/input/answer/diff_report.md` |
| 回归测试用例 | `/meituan/mm-qa-015/input/answer/test_cases.json` |

## 注意事项
- 每个差异必须标注type字段（取值为上述五种枚举之一），至少1个差异需标注对应的截图编号（如api_doc_01.png）
- 必须明确指出字段名和HTTP端点
- 每个涉及实际返回值的差异需引用response_logs.json中的具体JSON路径（精确到字段级别，如response.data.age），注意，对于 `missing_field` 类型的差异，路径须写至缺失字段本身，并注明"该字段在实际返回中不存在"，不得仅写到父对象层级；纯文档对比差异（仅涉及截图与Swagger定义对比，不涉及实际返回值）需明确标注"此差异为截图与Swagger文档定义对比，不涉及实际返回值"
- 边界值推断触发的差异需标注对应的测试用例ID
- test_cases.json必须为根级JSON数组`[{...}]`格式，每条用例包含method、url、params（键值对对象）、expected_status四个必填字段；用例内容须与diff_report.md中发现的差异关联，体现对具体问题的回归验证意图

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
