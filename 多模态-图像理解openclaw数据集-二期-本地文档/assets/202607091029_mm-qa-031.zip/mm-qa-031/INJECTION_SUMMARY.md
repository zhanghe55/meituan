# Bug Injection Summary — figma-D2-L3-1

## b007 (L3 / D2)
- **位置**: `js/state.js:duplicateSlide()`
- **描述**: duplicateSlide() 深度拷贝幻灯片后将 newSlide.speakerNotes 重置为空字符串，导致复制出的幻灯片丢失原有演讲备注；幻灯片的元素、布局、背景等均正确复制，只有备注悄然消失。
- **预期行为**: 复制幻灯片后，新幻灯片应拥有与原幻灯片完全相同的演讲备注内容。

