# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx
/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 A 列（故障编号）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 A 列内容完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 B 列（问题页面）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 B 列内容完全一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 C 列（缺陷描述）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 C 列内容完全一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 D 列（缺陷类型）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 D 列内容完全一致",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 E 列（严重等级）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 E 列内容完全一致",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/QA-001/input/answer/APP巡检测试bug报告.xlsx</file> 的 F 列（产生原因）内容与 <file>/meituan/QA-001/solution/参考答案APP巡检测试bug报告.xlsx</file> 的 F 列内容完全一致",
    "weight": 1
  }
]
```
