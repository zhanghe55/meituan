这是一个 Web 应用，页面地址：

```
http://webapp:8000
```

> **注意**：环境中存在 HTTP 代理，代理无法解析 Docker 内部主机名 `webapp`，且 agent-browser 内置的 Chromium 不支持 `no_proxy` 环境变量。请按以下步骤访问页面：
>
> 1. 先获取 webapp 的 IP 地址：`getent hosts webapp`（例如得到 `10.7.130.2`）
> 2. 使用 agent-browser 时，需要清除所有代理环境变量并使用 IP 地址访问：
> ```bash
> export http_proxy="" && export https_proxy="" && export HTTP_PROXY="" && export HTTPS_PROXY="" && agent-browser open http://<IP>:8000
> ```
> - 查看截图时，请使用 **`read`** 工具直接读取截图文件（`read /path/to/screenshot.png`），
>   不要使用 `image` 工具，`image` 工具在当前环境下不可用。
> - agent-browser 使用说明 详见：`~/.agents/skills/agent-browser/SKILL.md`

该应用是一个邮件管理 Web 应用。请完成以下每道题描述的业务操作，
在操作过程中像 QA 工程师一样观察应用行为，
判断执行过程的页面信息**是否存在 bug**，
判断执行过程中的操作反馈**是否存在 bug**，
判断执行过程中和该操作的关联模块反馈中**是否存在 bug**。

> **Bug 判断标准**：与同类产品的功能差异属于应用的设计选择，不算 bug。
> 只有应用内部行为自相矛盾、或操作结果与应用自身的反馈提示不一致时，才应列为 bug。

测试必须通过浏览器交互工具进行，不得通过 curl、cat、read 等方式直接读取应用的 JS/CSS 源码文件。

---

## 题目

以下四条路径中，每条路径可能存在 bug，也可能不存在 bug，请依次执行并独立判断。

**路径 A**
在收件箱中找到几封未加星标的邮件，逐一点击星标图标为其添加星标，然后进入 Starred 视图浏览这些邮件，再逐一点击取消星标，最后回到 Starred 视图。

---

**路径 B**
进入 Settings > Filters and Blocked Addresses，创建一条以邮件主题关键词为条件的新过滤规则，配置应用标签的动作后保存；然后在 Filters 列表中找到该规则，点击 edit 编辑并新增一项动作，保存更改。

---

**路径 C**
进入 Settings > General，将主题（Theme）更改为深色模式（Dark），将显示密度（Density）更改为紧凑（Compact），保存设置后返回收件箱，再进入 Settings > General 恢复为默认设置并保存。

---

**路径 D**
在收件箱中选择一封邮件将其贪睡（Snooze）至明天，然后进入 Snoozed 视图，找到该邮件并通过更多菜单执行解除贪睡（Unsnooze）操作，之后进入收件箱浏览邮件列表。

---

## 文件输出要求

如需截图，请保存到 `/app/input/screenshots/` 目录下

对每条路径，根据你的实际操作观察，判断是否存在 bug：
- **A**：路径 A 存在 bug
- **B**：路径 B 存在 bug
- **C**：路径 C 存在 bug
- **D**：路径 D 存在 bug
- **E**：以上路径均不存在 bug

将答案写入 `/app/input/answer.json`，格式如下：

```json
{
  "answer": "A",
  "trigger_steps": "复现该 bug 的操作序列",
  "observed": "实际看到了什么",
  "expected": "正确情况下应该是什么",
  "severity": "high / medium / low"
}
```

answer 为 A、B、C、D、E 之一。若 answer 为 E（无 bug），其余字段可留空字符串。
