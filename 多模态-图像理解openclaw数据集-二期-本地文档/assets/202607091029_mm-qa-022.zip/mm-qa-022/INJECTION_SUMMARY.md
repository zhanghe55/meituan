# Bug Injection Summary — bigmail-D2-L3-1

## (L3 / D2)
- **位置**: `js/state.js:unsnoozeEmails()`
- **描述**: `unsnoozeEmails()` 在清除 `isSnoozed` 和 `snoozeUntil` 后，遗漏了 `email.labels.push('INBOX')` 步骤；邮件从 Snoozed 视图消失，但未被加回 INBOX 标签，`getInboxEmails()` 过滤 `e.labels.includes('INBOX')` 导致邮件无法出现在收件箱，邮件进入隐身状态。
- **预期行为**: 解除贪睡（Unsnooze）后，邮件应从 Snoozed 视图消失并重新出现在收件箱中。
