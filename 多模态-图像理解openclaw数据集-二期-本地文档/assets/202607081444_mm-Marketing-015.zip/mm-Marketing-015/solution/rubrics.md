# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-015/input/answer/修改意见反馈单.xlsx
/meituan/mm-Marketing-015/input/answer/物料分发计划表.xlsx
/meituan/mm-Marketing-015/solution/参考答案_修改意见反馈单.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-015/input/answer/修改意见反馈单.xlsx</file>的表头内容应与<file>/meituan/mm-Marketing-015/solution/参考答案_修改意见反馈单.xlsx</file>的表头内容和顺序完全一致；",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-015/input/answer/修改意见反馈单.xlsx</file>与<file>/meituan/mm-Marketing-015/solution/参考答案_修改意见反馈单.xlsx</file>`海报编号`、`海报用途`、`审核维度`、`审核结论`四列的文本、数值内容以及数据顺序须保持一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-015/input/answer/修改意见反馈单.xlsx</file>与<file>/meituan/mm-Marketing-015/solution/参考答案_修改意见反馈单.xlsx</file>`问题描述`、`正确内容`两列每个单元格的对应内容表达含义一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-015/input/answer/物料分发计划表.xlsx</file>表头内容依次为`海报编号`、`海报文件名`、`投放渠道`、`对接人`、`联系方式`、`投放时间`、`注意事项`",
    "weight": 1
  },

  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-015/input/answer/物料分发计划表.xlsx</file>中，不包含任何海报编号为P01、P02、P03、P04、P05的数据行（因5张海报均未通过审核，分发计划表中不应有任何可分发物料的记录行，可接受包含分发计划表中无可分发物料的相关说明）",
    "weight": 1
  }
]
```
