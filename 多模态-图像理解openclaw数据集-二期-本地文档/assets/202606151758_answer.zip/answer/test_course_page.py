# -*- coding: utf-8 -*-
"""
课程详情页自动化测试
对应测试用例：TC-001 ~ TC-014
期望值来源：course_detail_prototype.png（正常态原型图）与 course_detail_states.png（多状态对比图）
运行方式：在 input/answer/ 目录下执行 python -m pytest test_course_page.py -v
         或 python -m unittest test_course_page -v
"""

import sys
import os
import unittest

# 将 input 目录加入 sys.path，以便 import course_page
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import course_page


# ──────────────────────────────────────────────
# Fixtures（测试数据，依据原型图与多状态对比图构造）
# ──────────────────────────────────────────────

def make_discount_course():
    """折扣课程：原型图正常态 ¥199 / ¥399 / 限时5折，共12章，第1章可试看"""
    return {
        "id": "course_001",
        "title": "Python 数据分析实战 · 从入门到项目",
        "price": 199,
        "original_price": 399,
        "discount_label": "限时5折",
        "is_free": False,
        "status": "on_sale",
        "stock": None,
        "chapters": [
            {"title": "第1章 课程介绍与环境", "trial": True},
            {"title": "第2章 NumPy 数据处理", "trial": False},
            {"title": "第3章 Pandas 实战", "trial": False},
            {"title": "第4章 数据清洗", "trial": False},
            {"title": "第5章 数据可视化", "trial": False},
            {"title": "第6章 Matplotlib 基础", "trial": False},
            {"title": "第7章 Seaborn 进阶", "trial": False},
            {"title": "第8章 统计分析", "trial": False},
            {"title": "第9章 机器学习入门", "trial": False},
            {"title": "第10章 项目实战一", "trial": False},
            {"title": "第11章 项目实战二", "trial": False},
            {"title": "第12章 总结与展望", "trial": False},
        ],
    }


def make_off_shelf_course():
    """下架课程：多状态对比图①下架态"""
    c = make_discount_course()
    c["status"] = "off_shelf"
    return c


def make_sold_out_course():
    """售罄课程：多状态对比图②库存为0"""
    c = make_discount_course()
    c["stock"] = 0
    return c


def make_free_course():
    """免费课程：多状态对比图④免费课程态"""
    return {
        "id": "course_free",
        "title": "Python 数据分析实战",
        "price": 0,
        "original_price": None,
        "discount_label": None,
        "is_free": True,
        "status": "on_sale",
        "stock": None,
        "chapters": [
            {"title": "第1章 课程介绍与环境", "trial": True},
            {"title": "第2章 NumPy 数据处理", "trial": False},
        ],
    }


def make_guest_user():
    """未登录用户"""
    return {"logged_in": False, "purchased_ids": [], "favorite_ids": []}


def make_logged_user(purchased=None, favorites=None):
    """已登录用户，可选已购买/已收藏课程列表"""
    return {
        "logged_in": True,
        "purchased_ids": purchased or [],
        "favorite_ids": favorites or [],
    }


# ──────────────────────────────────────────────
# 测试类
# ──────────────────────────────────────────────

class TestPurchaseFlow(unittest.TestCase):
    """购买流程场景（TC-001 ~ TC-005）"""

    def test_TC001_guest_click_purchase_goto_login(self):
        """TC-001：未登录用户点击「立即购买」跳转登录页"""
        course = make_discount_course()
        user = make_guest_user()
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "goto_login",
                         "未登录用户点击购买应跳转登录页")

    def test_TC002_logged_unpurchased_goto_pay(self):
        """TC-002：已登录未购买用户点击「立即购买」进入支付页"""
        course = make_discount_course()
        user = make_logged_user()
        # 按钮状态：文案「立即购买」，enabled=True
        btn = course_page.get_purchase_button(course, user)
        self.assertEqual(btn["text"], "立即购买")
        self.assertTrue(btn["enabled"])
        # 点击动作
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "goto_pay",
                         "已登录未购买用户点击购买应进入支付页")

    def test_TC003_purchased_button_goto_study(self):
        """TC-003：已购买用户按钮文案为「去学习」，点击进入学习页（多状态对比图③）"""
        course = make_discount_course()
        user = make_logged_user(purchased=["course_001"])
        # 按钮文案应为「去学习」（多状态对比图③已购买态）
        btn = course_page.get_purchase_button(course, user)
        self.assertEqual(btn["text"], "去学习",
                         "已购买用户按钮文案应为「去学习」")
        self.assertTrue(btn["enabled"])
        # 点击动作
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "goto_study")

    def test_TC004_off_shelf_button_disabled(self):
        """TC-004：课程下架时购买按钮置灰不可点击（多状态对比图①）"""
        course = make_off_shelf_course()
        user = make_logged_user()
        btn = course_page.get_purchase_button(course, user)
        self.assertFalse(btn["enabled"],
                         "下架课程购买按钮应置灰（enabled=False）")
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "blocked:off_shelf")

    def test_TC005_sold_out_button_text_and_disabled(self):
        """TC-005：库存为0时按钮显示「已售罄」且不可点击（多状态对比图②）"""
        course = make_sold_out_course()
        user = make_logged_user()
        btn = course_page.get_purchase_button(course, user)
        self.assertEqual(btn["text"], "已售罄",
                         "售罄课程按钮文案应为「已售罄」")
        self.assertFalse(btn["enabled"],
                         "售罄课程购买按钮应置灰（enabled=False）")
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "blocked:sold_out")


class TestPriceDisplay(unittest.TestCase):
    """价格展示场景（TC-006 ~ TC-007）"""

    def test_TC006_discount_price_three_elements(self):
        """TC-006：折扣课程同时展示折扣价、划线原价与折扣标签三要素（原型图价格区）"""
        course = make_discount_course()
        result = course_page.get_price_display(course)
        # 类型为折扣
        self.assertEqual(result["type"], "discount")
        # 折扣价 ¥199（原型图红色高亮）
        self.assertEqual(result["price"], 199)
        # 划线原价 ¥399（原型图划线）
        self.assertEqual(result["original_price"], 399)
        # 折扣标签「限时5折」（原型图橙色标签）
        self.assertEqual(result["discount_label"], "限时5折")

    def test_TC007_free_course_price_and_button(self):
        """TC-007：免费课程价格区显示「免费」，按钮文案为「立即学习」（多状态对比图④）"""
        course = make_free_course()
        user = make_logged_user()
        price = course_page.get_price_display(course)
        # 价格区显示「免费」（多状态对比图④绿色免费文字）
        self.assertEqual(price["type"], "free")
        self.assertEqual(price["display"], "免费")
        self.assertEqual(price["price"], 0)
        # 按钮文案「立即学习」（多状态对比图④橙色按钮）
        btn = course_page.get_purchase_button(course, user)
        self.assertEqual(btn["text"], "立即学习")
        self.assertTrue(btn["enabled"])


class TestCourseCatalog(unittest.TestCase):
    """课程目录场景（TC-008 ~ TC-010）"""

    def test_TC008_catalog_default_collapsed_shows_3_chapters(self):
        """TC-008：目录默认收起仅显示前3章，展开入口为「展开全部 12 章」（原型图目录区）"""
        course = make_discount_course()
        result = course_page.get_catalog(course, expanded=False)
        # 仅显示前3章（原型图：第1章、第2章、第3章）
        self.assertEqual(len(result["visible"]), 3)
        self.assertEqual(result["visible"][0]["title"], "第1章 课程介绍与环境")
        self.assertEqual(result["visible"][1]["title"], "第2章 NumPy 数据处理")
        self.assertEqual(result["visible"][2]["title"], "第3章 Pandas 实战")
        # 展开入口文案（原型图橙色「展开全部 12 章 ▼」）
        self.assertEqual(result["expand_entry"], "展开全部 12 章")
        self.assertEqual(result["total"], 12)

    def test_TC009_catalog_expanded_shows_all_chapters(self):
        """TC-009：点击展开后显示全部12章，入口变为「收起」"""
        course = make_discount_course()
        result = course_page.get_catalog(course, expanded=True)
        # 全部12章
        self.assertEqual(len(result["visible"]), 12)
        self.assertEqual(result["total"], 12)
        # 入口变为「收起」
        self.assertEqual(result["expand_entry"], "收起")

    def test_TC010_trial_chapter_playable_locked_chapter_not(self):
        """TC-010：可试看章节未购买可播放，锁定章节未购买不可播放（原型图目录可试看标签与锁图标）"""
        course = make_discount_course()
        guest = make_guest_user()
        logged_unpurchased = make_logged_user()

        # 第1章（index=0）：trial=True，原型图显示蓝色「可试看」标签
        # 未登录用户也可播放
        self.assertTrue(course_page.can_play_chapter(course, guest, 0),
                        "可试看章节（第1章）未登录用户应可播放")
        # 已登录未购买也可播放
        self.assertTrue(course_page.can_play_chapter(course, logged_unpurchased, 0),
                        "可试看章节（第1章）已登录未购买用户应可播放")

        # 第2章（index=1）：trial=False，原型图显示锁图标
        # 未登录不可播放
        self.assertFalse(course_page.can_play_chapter(course, guest, 1),
                         "锁定章节（第2章）未登录用户不可播放")
        # 已登录未购买不可播放
        self.assertFalse(course_page.can_play_chapter(course, logged_unpurchased, 1),
                         "锁定章节（第2章）已登录未购买用户不可播放")

        # 已购买用户可播放锁定章节
        purchased_user = make_logged_user(purchased=["course_001"])
        self.assertTrue(course_page.can_play_chapter(course, purchased_user, 1),
                        "锁定章节（第2章）已购买用户应可播放")


class TestFavorite(unittest.TestCase):
    """收藏功能场景（TC-011 ~ TC-012）"""

    def test_TC011_logged_user_add_and_remove_favorite(self):
        """TC-011：已登录用户收藏后图标变实心，再次点击取消收藏（原型图底部空心心形）"""
        course = make_discount_course()
        user = make_logged_user()

        # 初始未收藏
        self.assertNotIn("course_001", user["favorite_ids"])

        # 第一次点击：收藏
        result = course_page.click_favorite(user, course)
        self.assertEqual(result, "added", "首次点击收藏应返回 'added'")
        self.assertIn("course_001", user["favorite_ids"],
                      "收藏后课程ID应出现在 favorite_ids 中")

        # 第二次点击：取消收藏
        result = course_page.click_favorite(user, course)
        self.assertEqual(result, "removed", "再次点击应返回 'removed'")
        self.assertNotIn("course_001", user["favorite_ids"],
                         "取消收藏后课程ID应从 favorite_ids 中移除")

    def test_TC012_guest_click_favorite_goto_login(self):
        """TC-012：未登录用户点击收藏跳转登录页（原型图底部收藏按钮）"""
        course = make_discount_course()
        user = make_guest_user()
        result = course_page.click_favorite(user, course)
        self.assertEqual(result, "goto_login",
                         "未登录用户点击收藏应跳转登录页")


class TestAbnormalScenario(unittest.TestCase):
    """异常场景（TC-013 ~ TC-014）"""

    def test_TC013_off_shelf_page_notice_and_blocked(self):
        """TC-013：课程下架时顶部显示「该课程已下架」提示（多状态对比图①红色横幅）"""
        course = make_off_shelf_course()
        # 页面顶部提示（多状态对比图①红色警告横幅）
        notice = course_page.get_page_notice(course)
        self.assertEqual(notice, "该课程已下架",
                         "下架课程应显示「该课程已下架」提示")
        # 购买按钮置灰
        user = make_logged_user()
        btn = course_page.get_purchase_button(course, user)
        self.assertFalse(btn["enabled"])
        # 点击购买被阻断
        result = course_page.click_purchase(course, user)
        self.assertEqual(result, "blocked:off_shelf")

    def test_TC014_on_sale_course_no_notice(self):
        """TC-014：正常在售课程页面无下架提示"""
        course = make_discount_course()
        notice = course_page.get_page_notice(course)
        self.assertIsNone(notice,
                          "正常在售课程不应有下架提示，get_page_notice 应返回 None")


if __name__ == "__main__":
    unittest.main(verbosity=2)
