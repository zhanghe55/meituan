# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx
/meituan/mm-Operations-013/solution/清螨士除螨仪618大促活动筹备表-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'可报名活动'中的文字和数值需要和<file>/meituan/mm-Operations-013/solution/清螨士除螨仪618大促活动筹备表-参考答案.xlsx</file>'可报名活动'中的文字和数值需要一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'可用产品'中的文字和数值需要和<file>/meituan/mm-Operations-013/solution/清螨士除螨仪618大促活动筹备表-参考答案.xlsx</file>'可用产品'中的文字和数值需要一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'活动主图初审结果'中'A列和B列'的文字和数值需要和<file>/meituan/mm-Operations-013/solution/清螨士除螨仪618大促活动筹备表-参考答案.xlsx</file>'活动主图初审结果'中'A列和B列'的文字和数值需要一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'活动主图初审结果'中素材ID为'CMY004'、'CMY010'的备注列应为'无'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'活动主图初审结果'中素材ID为'CMY011'的备注列应为'logo错误，与公司logo不符'，意思一致即可",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'活动主图初审结果'中素材ID为'CMY016'的备注列应为'无实物图，只有包装'，意思一致即可",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-013/input/answer/清螨士除螨仪618大促活动筹备表.xlsx</file>'活动主图初审结果'中素材ID为'CMY013'的备注列应为'背景图为合成场景，非真实家居场景'，意思一致即可",
    "weight": 1
  }
]
```
