# Rubrics

> **每个 rubric 独立评分,rubric 权重合计 3 分。**
> **⚠️ 评分规则:要求数值完全对齐**

## 文件读取路径
```path
/meituan/mm-sre-020/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "GET /api/recommendations的峰值是3 seconds",
    "weight": 1
  },
  {
    "id": "BC-2",
    "content": "frontend error rate最高的是oteldemo.ProductCatalogService/GetProduct",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "product-reviews和load-generator在2026-0702-16:20:00时刻最接近",
    "weight": 1
  }
]
```
