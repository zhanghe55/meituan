# UI 视觉验收 Skill

## Skill 名称
`ui-visual-qa`

## 概述

本 skill 用于驱动 AI Agent 执行自动化 UI 视觉合规检查。流程覆盖品牌规范解析、浏览器截图采集、计算样式偏差检测、CSS 修正文件生成，以及修复前后的像素级截图对比分析。

---

## 前置依赖

- Python 3.8+
- `playwright`（`pip install playwright && playwright install chromium`）
- `PyMuPDF`（`pip install pymupdf`）
- `Pillow` + `numpy`（`pip install Pillow numpy`）——用于像素级截图比对，必须安装，不可跳过

---

## 执行流程

### 阶段一 — 解析品牌规范 PDF

**步骤 1.1：从 PDF 提取品牌 Token**

使用 `PyMuPDF`（fitz）读取品牌规范 PDF 的全部文本，解析并构建结构化字典，重点提取：

- 颜色：各组件的 Hex 色值（Primary Button、Secondary Button 等）
- 字体：各元素的 font-size、font-weight、line-height
- 间距：各组件的 padding、margin、gap
- 圆角：各组件类型的 border-radius
- 尺寸：各组件的 height、min-width

Token 结构示例：
```json
{
  "primary_button": {
    "background": "#0052D9",
    "color": "#FFFFFF",
    "font_size": "14px",
    "font_weight": "500",
    "height": "40px"
  },
  "navbar": {
    "height": "60px",
    "background": "#FFFFFF",
    "padding_horizontal": "24px"
  },
  "spacing": {
    "spacing-xl": "32px"
  },
  "cards_grid": {
    "gap": "32px"
  }
}
```

**步骤 1.2：保存 Token 文件**

将解析结果保存到：
```
input/answer/brand_tokens.json
```

---

### 阶段二 — 启动服务并采集原始截图

**步骤 2.1：启动本地 HTTP 服务**

```python
import http.server, threading, os

def start_server(directory, port=8765):
    os.chdir(directory)
    handler = http.server.SimpleHTTPRequestHandler
    httpd = http.server.HTTPServer(("", port), handler)
    t = threading.Thread(target=httpd.serve_forever)
    t.daemon = True
    t.start()
    return httpd
```

将服务根目录指向 `index.html` 所在目录。

**步骤 2.2：采集修复前截图**

使用 Playwright 采集完整页面截图：

```python
from playwright.sync_api import sync_playwright

def capture_screenshot(url, output_path):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        page.goto(url)
        page.wait_for_load_state("networkidle")
        page.screenshot(path=output_path, full_page=True)
        browser.close()
```

保存到：
```
input/answer/screenshot_before.png
```

---

### 阶段三 — 自动化偏差检测

**步骤 3.1：通过 Playwright 提取计算样式**

对每个关键组件，使用 `page.evaluate()` 获取计算后的 CSS 属性值。**所有属性值必须来自 `window.getComputedStyle()`，严禁直接读取 CSS 文件进行文本比对。**

```python
def get_computed_styles(page, selector, properties):
    return page.evaluate(f"""
        () => {{
            const el = document.querySelector('{selector}');
            if (!el) return null;
            const cs = window.getComputedStyle(el);
            const result = {{}};
            {chr(10).join([f"result['{p}'] = cs.getPropertyValue('{p}');" for p in properties])}
            return result;
        }}
    """)
```

需检测的选择器及属性：

| 选择器 | 需提取的属性 |
|---|---|
| `.btn-primary` | background-color、height、font-size、font-weight、color |
| `.btn-secondary` | background-color、color、height |
| `.navbar` | height、background-color、padding-left |
| `.cards-grid` | gap |
| `.form-input` | height、border-radius、padding-left、font-size |
| `.card` | border-radius、padding、background-color |

**步骤 3.2：与品牌 Token 对比**

对每个提取值与对应 Token 进行比对，计算偏差：
- 颜色：将 `rgb(r, g, b)` 规范化为 `#RRGGBB` 后进行精确匹配，记录实测值与规范值
- 尺寸：解析为整数后计算差值 `deviation = actual_px - spec_px`
- 圆角：同尺寸处理方式

将所有发现记录为结构化列表。

---

### 阶段四 — 生成视觉差异报告

**步骤 4.1：生成 `visual_diff_report.md`**

报告结构如下：

```markdown
# UI 视觉验收报告
**页面**：[URL]
**品牌规范**：brand-spec.pdf
**生成时间**：[时间戳]
**截图**：screenshot_before.png（本次运行采集）

---

## 汇总
| 总检测数 | 通过 | 失败 | 通过率 |
|---|---|---|---|
| N | M | K | X% |

---

## 偏差详情

### [DEV-001] 组件：[组件名]
- **属性**：[CSS 属性名]
- **选择器**：[CSS 选择器]
- **规范值**：[期望值]
- **实测值**：[浏览器计算值]
- **偏差**：[差值，如 −4px 或颜色不匹配]
- **严重程度**：高 / 中 / 低

[每处偏差重复上述结构]

---

## 通过项
[列出与规范一致的属性]
```

保存到：
```
input/answer/visual_diff_report.md
```

**步骤 4.2：严重程度分级标准**

| 严重程度 | 判定标准 |
|---|---|
| 高 | 主要交互元素颜色不匹配；尺寸偏差 > 4px |
| 中 | 间距偏差 2–4px；次要元素颜色不匹配 |
| 低 | 偏差 ≤ 2px；非交互元素间距问题 |

---

### 阶段五 — 生成 CSS 修正文件

**步骤 5.1：创建 `style_fixed.css`**

新建文件，不得覆盖原始 `style.css`，仅包含需要修正的 CSS 规则。每处修正属性上方必须附带注释：`/* FIXED: was [原始值], brand spec requires [规范值] */`

示例：
```css
/* ============================================
   style_fixed.css — 品牌合规修正
   由 UI Visual QA Agent 生成
   原始文件：style.css
   ============================================ */

.btn-primary {
  /* FIXED: was [原始色值], brand spec requires #0052D9 */
  background-color: #0052D9;
}

.navbar {
  /* FIXED: was [原始高度], brand spec requires 60px */
  height: 60px;
}

.cards-grid {
  /* FIXED: was [原始间距], brand spec requires 32px (spacing-xl) */
  gap: 32px;
}
```

保存到：
```
input/answer/style_fixed.css
```

---

### 阶段六 — 注入修正、采集截图并输出对比分析

**步骤 6.1：注入修正并采集修复后截图**

将 `style_fixed.css` 注入页面后采集截图：

```python
def capture_after_screenshot(page, fixed_css_path, output_path):
    with open(fixed_css_path) as f:
        css = f.read()
    page.add_style_tag(content=css)
    page.wait_for_timeout(500)
    page.screenshot(path=output_path, full_page=True)
```

保存到：
```
input/answer/screenshot_after.png
```

**步骤 6.2：像素级截图差异分析**

使用 Pillow 对 `screenshot_before.png` 和 `screenshot_after.png` 进行像素级比对，裁剪以下三个关键区域分别分析：

```python
from PIL import Image, ImageChops
import numpy as np

def compare_region(before_path, after_path, bbox):
    """bbox: (left, top, right, bottom) 单位像素"""
    before = Image.open(before_path).crop(bbox)
    after = Image.open(after_path).crop(bbox)
    diff = ImageChops.difference(before, after)
    arr = np.array(diff)
    changed_pixels = np.count_nonzero(arr.sum(axis=2))
    total_pixels = arr.shape[0] * arr.shape[1]
    return changed_pixels, total_pixels, changed_pixels / total_pixels * 100
```

针对 Step 3 中检测到的每处偏差，自行确定对应的页面区域范围，裁剪后逐一调用上述函数，记录实际比对结果。

**步骤 6.3：在报告末尾追加对比分析**

将像素级比对的实际测量结果追加写入 `visual_diff_report.md`，内容需包含：

- 两张截图的引用
- 每处偏差对应区域的实测变化数据（从截图中读取，不得使用预设数值）
- 每个区域的视觉变化说明

---

## 输出文件清单

所有输出文件保存至 `input/answer/`：

| 文件 | 说明 |
|---|---|
| `brand_tokens.json` | 从 PDF 解析的品牌 Token |
| `screenshot_before.png` | 修复前完整页面截图 |
| `screenshot_after.png` | 注入修正 CSS 后的完整页面截图 |
| `visual_diff_report.md` | 偏差报告，含像素级修复前后对比分析 |
| `style_fixed.css` | 仅包含修正规则的新 CSS 文件 |

---

## 异常处理

- 若某选择器在页面中未找到，记录 `SKIP: 选择器未找到` 并继续执行
- 若 PDF 解析失败，立即抛出错误，不得在缺少品牌 Token 的情况下继续执行
- 若本地服务启动失败，依次尝试端口 8766、8767
- 严禁覆盖原始 `style.css`，始终写入 `style_fixed.css`
- 像素级截图比对为必须执行步骤，不得跳过

---

## 注意事项

- 本 skill 可复用于任何具备品牌规范 PDF 和 HTML/CSS 源文件的前端项目
- 执行过程中无需人工介入
- Skill 中所有相对路径均相对于任务根目录，Agent 需根据实际工作目录自行解析
- 阶段六的像素级比对数据必须来自实际运行结果，报告中所有数值均须真实测量得出
