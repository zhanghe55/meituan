# Rubrics 

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-qa-014/input/answer/visual_diff_report.md
/meituan/mm-qa-014/input/answer/style_fixed.css
/meituan/mm-qa-014/input/answer/brand_tokens.json
/meituan/mm-qa-014/input/answer/screenshot_before.png
/meituan/mm-qa-014/input/answer/screenshot_after.png
/meituan/mm-qa-014/solution/ref_brand_tokens.json
/meituan/mm-qa-014/solution/ref_visual_diff_report.md
```

---

## 打分规则

```json
[
  {
    "id": "01",
    "content": "读取<file>/meituan/mm-qa-014/input/answer/brand_tokens.json</file>，与<file>/meituan/mm-qa-014/solution/ref_brand_tokens.json</file>对照，检查关键内容是否一致：须包含 Primary Button、Secondary Button、Navigation Bar、Spacing Tokens、Cards Grid 品牌 Token 分类，且各分类下的关键数值须与 ref_brand_tokens.json 中对应记录完全一致。属性名映射允许合理差异（如 'Background Color' 与 'background-color' 视为等价），但数值必须准确。缺少任意一个 Token 分类或关键数值不一致不得分。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "读取<file>/meituan/mm-qa-014/input/answer/visual_diff_report.md</file>，与<file>/meituan/mm-qa-014/solution/ref_visual_diff_report.md</file>对照，检查偏差记录的关键内容是否一致：须明确记录不通过数值为 3，且每条偏差记录须包含组件名、属性、选择器、规范值、实测值、严重程度等字段。3 处不通过须分别为：(1) 组件名=Navigation Bar, 属性=height, 选择器=.navbar, 规范值=60px, 实测值=45px, 严重程度=High；(2) 组件名=Primary Button, 属性=background-color, 选择器=.btn-primary, 规范值=#0052D9, 实测值=#F25C00, 严重程度=High；(3) 组件名=Cards Grid, 属性=gap, 选择器=.cards-grid, 规范值=32px, 实测值=16px, 严重程度=Medium。缺少任意一项字段或数值不一致不得分。",
    "weight": 1
  },  
  {
    "id": "03",
    "content": "<file>/meituan/mm-qa-014/input/answer/style_fixed.css</file> 正确修复了以下三项，且每项均包含 'FIXED:' 开头的原始值注释：(1) .navbar 的 height 修正为 60px；(2) .btn-primary 的 background-color 修正为 #0052D9；(3) .cards-grid 的 gap 修正为 32px",
    "weight": 1
  },
   {
    "id": "04",
    "content": "输出了<file>/meituan/mm-qa-014/input/answer/screenshot_before.png</file>和<file>/meituan/mm-qa-014/input/answer/screenshot_after.png</file>两张截图",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-qa-014/input/answer/visual_diff_report.md</file> 末尾包含截图对比分析内容，记录了Navbar（导航栏）渲染宽度变宽了、Primary Button 由橙色变为蓝色、Cards Grid 卡片间距变宽，这三个区域的像素级差异，验证了修复生效。",
    "weight": 1
  }
]
```
