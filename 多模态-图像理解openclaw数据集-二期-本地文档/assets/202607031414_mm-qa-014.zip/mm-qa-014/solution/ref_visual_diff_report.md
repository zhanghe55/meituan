# TechFlow Dashboard — 视觉差异报告

## 1. 品牌 Token 提取结果

| Token 分类 | 关键属性 |
|-----------|---------|
| Primary Button | background-color: #0052D9, color: #FFFFFF, font-size: 14px, font-weight: 500, border-radius: 6px, padding: 10px 20px, border: none, min-width: 88px, height: 40px |
| Secondary Button | background-color: #F2F3FF, color: #0052D9, font-size: 14px, font-weight: 500, border-radius: 6px, padding: 10px 20px, border: 1px solid #0052D9, min-width: 88px, height: 40px |
| Navigation Bar | height: 60px, background-color: #FFFFFF, border-bottom: 1px solid #DDE1E6, padding: 24px, nav-link-font-size: 14px, nav-link-color: #1A1A2E, nav-link-gap: 32px, active-link-color: #0052D9 |
| Spacing Tokens | spacing-xs: 4px, spacing-sm: 8px, spacing-md: 16px, spacing-lg: 24px, spacing-xl: 32px, spacing-2xl: 48px |
| Cards Grid | gap: 32px, spacing-token: spacing-xl |

---

## 2. 自动化偏差检测结果

### 汇总

- **检测总数**: 6 个组件
- **不通过**: 3

### 不通过项

#### DEV-001

- **组件名**: Navigation Bar
- **属性**: height
- **选择器**: `.navbar`
- **规范值**: 60px
- **实测值**: 45px
- **严重程度**: High

#### DEV-002

- **组件名**: Primary Button
- **属性**: background-color
- **选择器**: `.btn-primary`
- **规范值**: #0052D9
- **实测值**: #F25C00
- **严重程度**: High

#### DEV-003

- **组件名**: Cards Grid
- **属性**: gap
- **选择器**: `.cards-grid`
- **规范值**: 32px
- **实测值**: 16px
- **严重程度**: Medium




