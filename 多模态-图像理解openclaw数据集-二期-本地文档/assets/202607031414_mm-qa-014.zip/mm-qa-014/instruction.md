你是一个 UI 视觉验收 Agent。使用 **ui-visual-qa** skill，根据品牌规范 PDF 对前端页面的 CSS 实现进行自动化视觉合规检查，识别所有与品牌规范的偏差，生成修正 CSS 文件，并输出含截图对比分析的视觉差异报告。

输入文件在：
```
/meituan/mm-qa-014/input/brand-spec.pdf #TechFlow品牌视觉规范手册（含颜色、字体、间距、组件规格）
/meituan/mm-qa-014/input/index.html       # 待验收的前端页面
/meituan/mm-qa-014/input/style.css        # 待验收的 CSS 样式文件
```

**Step 1 — 解析品牌规范 PDF，提取量化指标**

使用 `PyMuPDF` 读取品牌规范 PDF 的全部文本，提取 Primary Button（background-color、height、font-size、color）、Secondary Button（background-color、height、color）、Navigation Bar（height、background-color、padding）、Spacing Tokens（spacing-xl gap）、Cards Grid（gap）等品牌 Token，构建结构化字典保存到：
```
/meituan/mm-qa-014/input/answer/brand_tokens.json
```
注意：必须通过代码解析 PDF 提取属性值，严禁使用硬编码数值。

**Step 2 — 捕获原始视觉状态**

启动本地服务渲染 index.html，使用 `playwright` 捕获完整页面截图，保存到：
```
/meituan/mm-qa-014/input/answer/screenshot_before.png
```
注意：必须基于浏览器渲染后的计算样式进行审计，所有属性值必须通过 `window.getComputedStyle()` 从实际渲染的 DOM 元素获取，严禁仅通过静态 CSS 文本分析。

**Step 3 — 自动化偏差检测**

通过 `page.evaluate()` + `window.getComputedStyle()` 从浏览器获取实际渲染值，对比 brand_tokens.json 识别所有不一致属性。颜色值需规范化为 Hex 格式后精确匹配，尺寸值需解析为数字后记录偏差量。需检测的选择器及属性：`.navbar`（height、background-color、padding-left）、`.btn-primary`（background-color、height、font-size、color）、`.btn-secondary`（background-color、height、color）、`.cards-grid`（gap）、`.form-input`（height、border-radius、font-size、padding-left）、`.card`（border-radius、padding、background-color）。

**Step 4 — 生成视觉差异报告**

将每处偏差的组件名、属性、选择器、规范值、实测值及严重程度记录到：
```
/meituan/mm-qa-014/input/answer/visual_diff_report.md
```

严重程度（Severity）判定标准：
- **High**：对品牌识别有显著影响的偏差，如核心品牌色错误、破坏页面整体结构的关键尺寸错误
- **Medium**：影响组件一致性但未破坏整体结构的偏差，如间距、边距不符合规范导致视觉拥挤或松散
- **Low**：对整体视觉影响轻微的偏差，如次要元素的微小尺寸差异、不影响品牌识别的细节偏差

**Step 5 — 生成 CSS 修正文件**

将所有修正规则输出到：
```
/meituan/mm-qa-014/input/answer/style_fixed.css
```
每处修正上方必须附带注释：`/* FIXED: was [原始值], brand spec requires [规范值] */`。

**Step 6 — 验证修正效果并输出截图对比分析**

将 style_fixed.css 注入页面，再次截图保存到：
```
/meituan/mm-qa-014/input/answer/screenshot_after.png
```
针对上述发现的视觉差异，对两张截图进行像素级差异分析，验证修复是否生效，并将结果记录保存在 visual_diff_report.md 中。

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。