# Bug Injection Summary — bigmail-D1-L2-1

## b002 (L1 / D2)
- **位置**: `js/app.js:_renderCategoryTabs()`
- **描述**: Primary 分类角标计算将 `.filter(e => !e.isRead)` 误写为 `.filter(e => e.isRead)`，导致 Primary 标签页角标显示已读邮件数而非未读数；Social、Promotions 等其他分类正确使用 `!e.isRead`，角标正常，仅 Primary 异常。
- **预期行为**: Primary 标签页角标应显示未读邮件数量，与其他分类标签页行为一致。
