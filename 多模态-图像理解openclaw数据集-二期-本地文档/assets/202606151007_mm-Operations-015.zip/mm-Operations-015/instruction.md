你是配送风控专员，负责处理骑手配送异常工单并对责任归属进行判定。请根据以下输入文件完成`待审核`工单的定责判定与分析报告的输出。

**输入的图片**:
```
/meituan/mm-Operations-015/input/定责判定采集材料/骑手李强-异常发生路段监控画面.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手王磊-异常发生路段监控画面.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手赵阳-取餐商家环境画面.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手刘洋-异常发生路段行车记录画面.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手刘洋-异常发生路段路面特写.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手陈默-取餐外包装画面.jpg
/meituan/mm-Operations-015/input/定责判定采集材料/骑手陈默-送达后内物画面.jpg
```
以上图片由平台风控系统从多渠道采集汇总，来源包括：异常发生时刻路段的市政/道路监控截帧、合作商户门店监控截帧、骑手事后现场手机拍摄上传、行车记录画面、用户投诉时随单附图等。


**输入的异常工单导出数据（1份）和规则与规范文档（4份）**:
```
/meituan/mm-Operations-015/input/骑手异常工单数据.csv
/meituan/mm-Operations-015/input/骑手装备与操作规范.md
/meituan/mm-Operations-015/input/定责判定规则.md
/meituan/mm-Operations-015/input/安全积分管理规则.md
/meituan/mm-Operations-015/input/定责报告填写规范.md
```

## 任务说明
1. 读取所有输入文件，结合`骑手异常工单数据.csv`、`骑手装备与操作规范.md`、`定责判定规则.md`，对每位待审核骑手的异常工单进行综合判定，得出定责结论；
2. 根据定责结论，查`安全积分管理规则.md`计算每位骑手的积分扣除数额、扣除后剩余积分、累计违规次数及触发的对应处罚；
3. 将5位骑手的定责分析与积分处罚结果输出为一个 Word 文档报告，文档结构严格按照`定责报告填写规范.md`执行。

**最终报告输出路径**：
```
/meituan/mm-Operations-015/input/answer/骑手配送异常定责分析报告.docx
```

请直接执行命令，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决
