# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-ba-015/input/answer/项目计算表.xlsx
/meituan/mm-ba-015/solution/参考答案项目计算表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-ba-015/input/answer/项目计算表.xlsx</file>有且仅有四个工作表：'项目利润预测'、'项目经济预测'、'投资分类占比'、'场地规划要素统计'，工作表顺序与<file>/meituan/mm-ba-015/solution/参考答案项目计算表.xlsx</file>一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-ba-015/input/answer/项目计算表.xlsx</file>的核心内容与<file>/meituan/mm-ba-015/solution/参考答案项目计算表.xlsx</file>一致：'项目利润预测'工作表的A1:E20和'项目经济预测'工作表的A1:E16的显示数值、文字内容和数据行顺序均一致；保留公式的单元格，只对比显示的结果即可",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-ba-015/input/answer/项目计算表.xlsx</file>的'场地规划要素统计'工作表与<file>/meituan/mm-ba-015/solution/参考答案项目计算表.xlsx</file>的'场地规划要素统计'工作表的数值与文本内容和行列顺序均一致；",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-ba-015/input/answer/项目计算表.xlsx</file>中'投资分类占比'工作表包含一个饼状图，且B7:E14均有填写数值",
    "weight": 1
  }
]
```
