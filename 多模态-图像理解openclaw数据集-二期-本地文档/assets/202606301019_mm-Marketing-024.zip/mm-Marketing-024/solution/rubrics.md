# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-024/input/answer/舆情跟踪表20250615.xlsx
/meituan/mm-Marketing-024/solution/舆情跟踪表参考答案.xlsx
/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情跟踪表20250615.xlsx</file>的A-D、F列和<file>/meituan/mm-Marketing-024/solution/舆情跟踪表参考答案.xlsx</file>的A-D、F列的内容完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情跟踪表20250615.xlsx</file>中的E列表头为'解决进度判定依据'，该列除表头的内容和<file>/meituan/mm-Marketing-024/solution/舆情跟踪表参考答案.xlsx</file>'解决进度判定依据'列除表头的内容大意一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx</file>中包含两个章节，依次为：'核心指标概览'、'今日核心风险点'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx</file>的'核心指标概览'章节，包含6月14日和6月15日两天的舆情比例饼图，饼图要根据下面的数据生成：6月14日的有效舆情数量为12，负面舆情数量是6，正面舆情数量是6；6月15日的有效舆情数量为12，负面舆情数量是9，正面舆情数量是3；该章节必须有一段分析两天正面、负面舆情数量和业务归属的变化文字",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx</file>的'今日核心风险点'章节，以表格形式呈现，表头有且仅有以下4列：'风险等级'、'舆情ID'、'业务归属'、'事件简述'；",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx</file>中'今日核心风险点'章节表格的部分，'舆情ID'列从上到下依次是：'YQ-20250615-001'、'YQ-20250615-004'、'YQ-20250615-008'、'YQ-20250615-012'、'YQ-20250615-005'、'YQ-20250615-007'、'YQ-20250615-010'、'YQ-20250615-013'、'YQ-20250615-014'，其中前面4个舆情都是'P1'等级，后面5个舆情都是'P2'等级，业务归属列内容依次是：'商家问题'、'社区电商'、'商家问题'、'平台服务'、'配送问题'、'配送问题'、'公司和员工相关信息'、'商家问题'、'产品体验/功能咨询'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Marketing-024/input/answer/舆情日报20250615.docx</file>'今日核心风险点'章节的表格'事件简述'列必须有对该舆情内容的简述",
    "weight": 1
  }
]
```
