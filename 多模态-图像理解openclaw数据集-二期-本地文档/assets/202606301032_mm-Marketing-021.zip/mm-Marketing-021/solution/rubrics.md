# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-Marketing-021/input/answer/新瑞冲牙器7天测试期全渠道投放数据明细.xlsx
/meituan/mm-Marketing-021/input/answer/新瑞冲牙器测试素材分析.xlsx
/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx
/meituan/mm-Marketing-021/solution/新瑞冲牙器测试素材分析-参考答案.xlsx
/meituan/mm-Marketing-021/solution/新瑞冲牙器7天测试期全渠道投放数据明细-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器7天测试期全渠道投放数据明细.xlsx</file>中sheet4的表头应为'计划ID'、'异常原因'。A列数据需要和<file>/meituan/mm-Marketing-021/solution/新瑞冲牙器7天测试期全渠道投放数据明细-参考答案.xlsx</file>中sheet4的A列数据一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器7天测试期全渠道投放数据明细.xlsx</file>中，sheet4中B列异常原因处每个单元格的内容需要包含'重复访问≥5次'或者'点击率≥行业均值2倍'的字样，意思一致即可",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器测试素材分析.xlsx</file>中的文字和数字需要和<file>/meituan/mm-Marketing-021/solution/新瑞冲牙器测试素材分析-参考答案.xlsx</file>文字和数字一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx</file>文档中只能有最优定向组合、素材视觉建议、渠道预算分配比例三部分内容（注释部分的内容可豁免，不在此条规则评测范围内）",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx</file>文档中定向类型需要是'定向1-18-25岁一二线正畸女性'，输出'定向1'或者'18-25岁一二线正畸女性'均可，意思一致即可",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx</file>文档中最优渠道需要是'京东'，意思一致即可",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx</file>文档中素材视觉建议部分的内容需要包含'有真人出镜、有文字、有具体场景'，意思一致即可",
    "weight": 1
  },
  {
    "id": "08",
    "content": "输出的<file>/meituan/mm-Marketing-021/input/answer/新瑞冲牙器放量方案.docx</file>文档中渠道预算分配比例部分的内容需要是'京东占比最高、抖音第二、知乎第三'，意思一致即可，具体数据不做要求",
    "weight": 1
  }
]
```