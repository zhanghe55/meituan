# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-016/input/answer/内容运营第二周期数据表.xlsx
/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx
/meituan/mm-Operations-016/solution/参考答案_内容运营第二周期数据表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第二周期数据表.xlsx</file>的Sheet1名为'各平台内容明细'，'各平台内容明细'的表头字段须与<file>/meituan/mm-Operations-016/solution/参考答案_内容运营第二周期数据表.xlsx</file>的Sheet1表头字段完全一致；且两个数据表除表头外的16行数据文本与数值内容须完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第二周期数据表.xlsx</file>的Sheet2名为'周期汇总对比'，'环比变化（曝光）'及'环比变化（增粉）'两列的文本与数值内容及对应平台须与<file>/meituan/mm-Operations-016/solution/参考答案_内容运营第二周期数据表.xlsx</file>sheet2中的文本与数值内容及对应平台一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第二周期数据表.xlsx</file>的Sheet3名为'优劣势分析'，'优劣势分析'的表头字段须与<file>/meituan/mm-Operations-016/solution/参考答案_内容运营第二周期数据表.xlsx</file>的Sheet3表头字段完全一致；且两个数据表除表头外的6行数据文本与数值内容须完全一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx</file>的表头字段有且仅有5个，依次为：'平台'、'选题'、'内容形式'、'选题来源类型'、'来源备注'，且除表头外包含17行数据",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx</file>中，平台为公众号和小红书的数据，'内容形式'均为'图文';平台为抖音的数据，'内容形式'为'视频'",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx</file>中，平台为公众号的数据共6行，6行数据的顺序不做要求。选题来源类型列须满足：1条选题库储备数据,'来源备注'列为'GZH-01'；1条热点话题数据,'来源备注'列为'无'；2条用户反馈数据，'来源备注'列分别为 来自公众号'背包客小王'的评论 及 来自公众号'旅行达人阿梦'的评论 ；2条素材驱动数据，'来源备注'列分别为'素材B-凤凰古城'和'素材C-大理崇圣寺三塔'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx</file>中，平台为小红书的数据共7行，7行数据的顺序不做要求。选题来源类型列须满足：2条选题库储备数据,'来源备注'列分别为'XHS-01'及'XHS-06'；1条热点话题数据,'来源备注'列为'无'；2条用户反馈数据，'来源备注'列分别为 来自小红书'甜甜圈少女'的评论 及 来自小红书'旅行穿搭博主'的评论 ；2条素材驱动数据，'来源备注'列分别为'素材A-张家界国家森林公园'和'素材D-千岛湖'",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Operations-016/input/answer/内容运营第三周期选题计划表.xlsx</file>中，平台为抖音的数据共4行，4行数据的顺序不做要求。选题来源类型列须满足：1条选题库储备数据,'来源备注'列为'DY-01'；1条热点话题数据,'来源备注'列为'无'；2条用户反馈数据，'来源备注'列分别为 来自抖音'吃货旅行家'的评论 及 来自抖音'带娃去旅行'的评论 ",
    "weight": 1
  }
]
```
