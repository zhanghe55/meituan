# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中'参与上期活动用户占比'应为'60.0%'、'未参与上期活动用户占比'应为'40.0%'、'愿意继续参加同类型活动占比'应为'66.7%'、'愿意推荐给身边朋友的用户占比'应为'65.0%'、'后续活动愿意第一时间参与的用户占比'应为'50.0%'，以上数值都应以百分比的形式展示，且保留1位小数",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中'上期活动平均满意度'为'3.8'分，需保留1位小数，带不带单位（分）不做要求",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中'流失用户分级表'的表头应至少包含'用户ID'、'分级结果'、'配套福利'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中'流失用户分级表'中应有且仅有这些用户ID应为：'U016、U017、U018、U019、U020、U021、U022、U023、U024、U025、U026、U027、U028、U029、U030'，顺序不做要求",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中分级结果为'高价值流失'的用户ID有且仅有：'U016、U017、U019、U021、U023、U027、U029'",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中分级结果为'高价值流失'的用户'配套福利'应为'高级道具礼包 × 1、钻石 × 500、体力药水 × 10、回归后 7 天内全局经验 +50%、限时 3 天，享 8 折优惠'，文字和数值需一模一样",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中分级结果为'普通流失'的用户ID有且仅有：'U018、U020、U022、U024、U025、U026、U028、U030'",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中分级结果为'普通流失'的用户'配套福利'应为'普通道具礼包 × 1、钻石 × 100、体力药水 × 3、回归后 3 天内全局经验 +20%'，文字和数值需一模一样",
    "weight": 1
  },
  {
    "id": "09",
    "content": "<file>/meituan/mm-Operations-019/input/answer/快乐消消消游戏用户维稳和防流失方案.pptx</file>中用户反馈的问题有且仅有'闪退、活动奖励少、服务器延迟、规则复杂、好友推荐功能无法使用、进游戏时页面卡顿、设置图标太小'这些内容，意思一致即可，以上内容需要全部包含，少写或者多写都不通过",
    "weight": 1
  }
]
```
