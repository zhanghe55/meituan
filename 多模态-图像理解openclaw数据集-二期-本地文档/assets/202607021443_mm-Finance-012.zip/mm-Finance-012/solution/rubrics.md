# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx
/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>的Sheet名称和顺序完全一致，依次为'项目概况'、'项目选址'、'区域市场需求分析'、'经济效益预测表'、'投资预算表'，不得新增、删减、改名或调整Sheet顺序。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>中'项目概况'sheet的分区标注合计、差额、经营区的B-C列的数值完全一致。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>中'项目选址'sheet的计租面积、租金单价、月租金、押金、物业费单价、物业费（月）、首期物业（季付）、免租期、租赁年限、付款方式信息完全一致且拟选定铺位相同。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>中'区域市场需求分析'sheet的竞品与价格(元)这2列的6条竞品数据的文本内容、数值与顺序完全一致，如数据少于6条或大于6条均不通过；'代表单品(价)'这一列输出的内容，如果列出的单品包含参考答案中列出的单品，则价格需要和答案中价格保持一致，如不一致则不通过",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>中'经济效益预测表'sheet的'初估月营业额'、'预计月净利率'、'预计月净利润'、'静态投资回收期'、'行业回收期对照'、'预测结论'这几个字段的文本内容及数值完全一致",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-Finance-012/input/answer/项目投资测算基础信息表.xlsx</file>与<file>/meituan/mm-Finance-012/solution/项目投资测算基础信息表参考答案.xlsx</file>中'投资预算表'的总投资金额基本一致，允许存在±1000元的偏差。",
    "weight": 1
  }
]
```
