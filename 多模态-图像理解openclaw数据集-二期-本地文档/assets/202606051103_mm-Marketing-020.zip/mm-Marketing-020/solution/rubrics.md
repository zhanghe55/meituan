# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx
/meituan/mm-Marketing-020/input/answer/下一阶段内容排期表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx</file>的投放执行概况章节中，列出了小红书笔记总曝光、小红书互动率、用户自发晒单数、首月GMV、首月复购率这5项指标的目标值与实际达成值，并指出所有指标均未达标",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx</file>的官方素材效果对比章节中，对宣发素材01.jpg的品种描述包含'虎斑'二字（或中华田园猫）,对宣发素材02.jpg的品种描述包含'缅因'二字或该品种其他合理别名；分析内容须指出'宣发素材02'中猫咪品种更有辨识度，分析逻辑清晰合理",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx</file>的UGC用户画像与产品洞察章节中，品种描述包含'布偶猫'、'无毛猫'（或斯芬克斯猫）、'虎斑猫'（或中华田园猫）",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx</file>的UGC用户画像与产品洞察章节中，包含3位用户喂养方式的统计，其中干喂1人、复水1人、拌粮1人，且明确指出使用开水泡冻干这一错误做法",
    "weight": 1
  },
{
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/首发推广复盘报告.docx</file>的下一阶段优化方向章节中，包含3条内容优化方向，且其中一条须关于素材视觉策略调整的方向、一条须关联冻干正确复水方法的科普",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Marketing-020/input/answer/下一阶段内容排期表.xlsx</file>中仅包含1个名为'内容排期'的Sheet，共6行数据（不含表头），有且仅有以下5列：序号、标题、投放渠道、内容形式、选题简述；其中至少1行的选题涉及冻干复水温度或复水方法的科普内容，且标题须为'冻干正确复水温度与方法'、投放渠道为'小红书';其他行的'投放渠道'列只能在小红书/微信公众号/淘宝逛逛中选取一种，'内容形式'只能在图文/短视频/长图文选取一种",
    "weight": 1
  }
]
```
