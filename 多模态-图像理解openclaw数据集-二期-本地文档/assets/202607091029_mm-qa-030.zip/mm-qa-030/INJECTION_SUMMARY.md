# Bug Injection Summary — figma-D2-L2-1

## b006 (L2 / D2)
- **位置**: `js/state.js:addReply()`
- **描述**: addReply() 在推入回复内容后，额外将父评论的 resolved 状态切换为 true（comment.resolved = !comment.resolved 在未解决评论上等价于 resolved=true），导致对未解决评论提交一条回复后，该评论立即呈现为已解决（灰色）状态。
- **预期行为**: 提交回复后，回复出现在评论线程中，父评论的 resolved 状态不变（未解决评论仍为未解决）。

