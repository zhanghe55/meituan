# Rubrics
> **每个 rubric 独立评分，满分 5 分。**
> **⚠️ 评分规则（新版）：BC-1 需同时满足"答案字母正确"与"observed 字段命中注入 bug 症状关键词"两个条件，两者缺一则 BC-1 得 0 分，BC-2/3/4 亦不计分。即：选项选对但描述的是其他 bug、或描述对但选项选错，均不得分。**

## 文件读取路径
```path
/meituan/mm-qa-030/input/answer.json
```

```json
[
  {
    "id": "BC-1",
    "content": "<file>/meituan/mm-qa-030/input/answer.json</file> 中 answer 字段值为\"C\"（答案为路径 C 且 observed 命中注入 bug 症状（回复评论后父评论被自动标记为已解决））。两个条件——答案字母正确 AND observed 字段提到了（已解决、resolved、变灰、被自动解决、绿色勾 中的任意一项）——必须同时满足，任一不满足 BC-1 得 0 分。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-030/input/answer.json</file> 中 trigger_steps 提到了对未解决评论提交回复（提到了 Reply、回复、未解决评论、Comments 面板 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-030/input/answer.json</file> 中 observed 对注入 bug 现象的描述更完整（提到了 已解决、resolved、变灰、被自动解决、绿色勾 中的任意一项，且结合具体数值、状态或对比说明）",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-030/input/answer.json</file> 中 expected 提到了回复后父评论状态应保持不变（提到了 状态不变、未解决仍为未解决、resolved 不应改变 中的任意一项）",
    "weight": 1
  }
]
```
