# Bug Injection Summary — figma-D1-L1-1

## b001 (L1 / D1)
- **位置**: `js/components.js:statusBadge()`
- **描述**: statusBadge() 中 'draft' 与 'archived' 的颜色值对调：draft 本应显示黄色 (#FFC700) 却显示灰色 (#888888)，archived 本应显示灰色却显示黄色，状态文字正确但颜色语义完全相反。
- **预期行为**: published 标签显示绿色 (#14AE5C)，draft 显示黄色 (#FFC700)，archived 显示灰色 (#888888)，颜色与状态语义一致。

