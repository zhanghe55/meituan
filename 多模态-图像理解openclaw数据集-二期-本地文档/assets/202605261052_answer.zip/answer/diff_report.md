# API接口差异报告

**生成时间**：2026-04-01  
**权威基准**：Swagger API文档（swagger_api.html）  
**辅助参考**：接口文档截图（api_doc_01.png / api_doc_02.png / api_doc_03.png）  
**实际响应来源**：response_logs.json  
**边界值测试来源**：test_data_boundary.json  

---

## 差异汇总

| 编号 | 端点 | 字段 | 类型 | 严重程度 |
|------|------|------|------|----------|
| DIFF-001 | POST /api/v1/users | age | data_type | 高 |
| DIFF-002 | POST /api/v1/users | age（参数校验） | required_field | 高 |
| DIFF-003 | POST /api/v1/orders | created_at | missing_field | 中 |
| DIFF-004 | PUT /api/v1/products/{id} | category | missing_field | 中 |
| DIFF-005 | POST /api/v1/orders | quantity（负数校验） | required_field | 高 |
| DIFF-006 | POST /api/v1/users | age（截图类型标注） | data_type | 低 |

---

## 详细差异描述

---

### DIFF-001

- **type**：data_type  
- **端点**：POST /api/v1/users  
- **字段**：age  
- **Swagger定义**：`age` 字段类型为 `integer`（见swagger_api.html，POST /api/v1/users参数表，age行：Type=integer）  
- **实际返回**：`age` 字段值为字符串 `"28"`，类型为 `string`  
- **JSON路径引用**：`response.data.age`（值为 `"28"`，实际类型为string，与Swagger定义的integer不符）  
- **截图参考**：api_doc_01.png 中 POST /api/v1/users 参数表将 age 标注为 `string` 类型，与Swagger定义的 `integer` 不一致（见DIFF-006）  
- **边界值关联**：TC-003（test_data_boundary.json）传入 `age: "twenty-five"`，期望返回400，进一步佐证接口对age字段的类型校验存在缺失，导致字符串类型数据被接受并原样返回  
- **影响**：接口未对age字段做类型强制转换或校验，导致响应中age以字符串形式返回，违反Swagger integer定义，下游系统若按integer解析将出现类型错误

---

### DIFF-002

- **type**：required_field  
- **端点**：POST /api/v1/users  
- **字段**：age（参数校验缺失）  
- **Swagger定义**：`age` 为必填字段（Required=Yes），类型为 `integer`，描述为"must be valid number"，即接口应对非数字类型的age入参返回400错误  
- **实际行为推断**：根据TC-003（test_data_boundary.json，触发数据来自test_data_boundary.json，不在response_logs.json中），传入 `age: "twenty-five"`（字符串），期望状态码400，但结合DIFF-001中实际返回 `age: "28"`（字符串被接受）可推断接口未对age字段做类型校验，直接接受了字符串类型入参并返回201，未触发400校验错误  
- **边界值关联**：**TC-003**（test_data_boundary.json）—— 传入非数字字符串age，期望400，推断接口缺少age类型校验  
- **影响**：必填字段的类型校验缺失，导致非法数据写入，违反Swagger required_field约束

---

### DIFF-003

- **type**：missing_field  
- **端点**：POST /api/v1/orders  
- **字段**：created_at  
- **Swagger定义**：GET /api/v1/orders/{id} 响应示例中包含 `created_at` 字段（值为 `"2026-04-01T10:00:00Z"`），表明订单对象应包含创建时间字段；截图api_doc_02.png中GET /api/v1/orders/{id}响应示例同样包含 `created_at` 字段，与Swagger一致  
- **实际返回**：POST /api/v1/orders 响应中 `created_at` 字段完全缺失  
- **JSON路径引用**：`response.data.created_at`（该字段在实际返回中不存在）  
- **截图参考**：api_doc_02.png（GET /api/v1/orders/{id}响应示例包含created_at，与Swagger一致）  
- **影响**：新建订单后响应缺少创建时间字段，客户端无法获取订单创建时间，需额外发起GET请求补充信息

---

### DIFF-004

- **type**：missing_field  
- **端点**：PUT /api/v1/products/{id}  
- **字段**：category  
- **Swagger定义**：GET /api/v1/products 响应示例中产品对象包含 `category` 字段（如 `"electronics"`），截图api_doc_03.png中GET /api/v1/products响应示例同样包含 `category` 字段，表明产品对象的标准结构应包含category  
- **实际返回**：PUT /api/v1/products/{id} 响应数据为 `{id, name, price, stock}`，`category` 字段完全缺失  
- **JSON路径引用**：`response.data.category`（该字段在实际返回中不存在）  
- **截图参考**：api_doc_03.png（GET /api/v1/products响应示例包含category字段，与Swagger一致）  
- **影响**：更新产品后响应缺少category字段，响应结构与GET接口不一致，客户端需额外处理字段缺失情况

---

### DIFF-005

- **type**：required_field  
- **端点**：POST /api/v1/orders  
- **字段**：quantity（负数校验缺失）  
- **Swagger定义**：`quantity` 为必填字段（Required=Yes），描述为"Quantity (must be positive)"，即接口应拒绝负数或零值的quantity入参并返回400  
- **实际行为推断**：根据TC-006（test_data_boundary.json，触发数据来自test_data_boundary.json，不在response_logs.json中），传入 `quantity: -5`，期望状态码400，推断接口可能缺少对quantity负数的校验，存在接受非法负数quantity并创建订单的风险  
- **边界值关联**：**TC-006**（test_data_boundary.json）—— 传入负数quantity=-5，期望400，推断接口缺少quantity正数校验  
- **影响**：若接口未校验quantity必须为正数，将导致负数订单数量被写入，违反业务逻辑和Swagger约束

---

### DIFF-006

- **type**：data_type  
- **端点**：POST /api/v1/users  
- **字段**：age（参数定义类型）  
- **Swagger定义**：`age` 参数类型为 `integer`（swagger_api.html，POST /api/v1/users参数表）  
- **截图定义**：api_doc_01.png 中 POST /api/v1/users 参数表将 `age` 标注为 `string` 类型  
- **此差异为截图与Swagger文档定义对比，不涉及实际返回值**  
- **截图参考**：api_doc_01.png  
- **影响**：截图文档与Swagger权威定义不一致，可能导致开发人员按截图实现时使用错误的字段类型，是DIFF-001问题的根本原因之一

---

## 差异统计

| 维度 | 数量 |
|------|------|
| 实际返回 vs Swagger（核心差异） | 4个（DIFF-001、DIFF-002、DIFF-003、DIFF-004） |
| 边界值推断触发差异 | 2个（DIFF-002引用TC-003、DIFF-005引用TC-006） |
| 截图 vs Swagger（文档内部差异） | 1个（DIFF-006） |
| **有效差异总数** | **6个** |

---

## 附：截图信息提取摘要（辅助参考）

### api_doc_01.png（用户接口）
- GET /api/v1/users：参数 page(integer)、limit(integer)、email(string)，均非必填；响应包含 code、data.items[{id,name,email,age,status}]、data.total
- POST /api/v1/users：参数 name(string,Yes)、email(string,Yes)、**age(string,Yes)**、status(string,No)；响应 code:201

### api_doc_02.png（订单接口）
- GET /api/v1/orders/{id}：参数 id(integer,Yes)、include_items(boolean,No)；响应包含 id、user_id、total_amount、status、created_at、items
- POST /api/v1/orders：参数 user_id(integer,Yes)、product_id(integer,Yes)、quantity(integer,Yes)、address(string,Yes)、payment_method(string,Yes)

### api_doc_03.png（产品接口）
- GET /api/v1/products：参数 category(string)、min_price(number)、max_price(number)、sort(string)，均非必填；响应包含 id、name、price、stock、category
- PUT /api/v1/products/{id}：参数 id(integer,Yes)、name(string,No)、price(number,No)、stock(integer,No)
