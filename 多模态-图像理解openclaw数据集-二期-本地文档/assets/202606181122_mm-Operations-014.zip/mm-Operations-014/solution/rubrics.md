# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-014/input/answer/直播脚本流程表.csv
/meituan/mm-Operations-014/input/answer/商品卖点话术卡片表.csv
/meituan/mm-Operations-014/input/answer/弹窗素材排期表.csv
/meituan/mm-Operations-014/solution/参考答案_直播脚本流程表.csv
/meituan/mm-Operations-014/solution/参考答案_商品卖点话术卡片表.csv
/meituan/mm-Operations-014/solution/参考答案_弹窗素材排期表.csv
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-014/input/answer/直播脚本流程表.csv</file>的表头字段依次为'环节序号','开始时间','结束时间','环节名称','环节内容',除表头外有且仅有10行数据",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-014/input/answer/直播脚本流程表.csv</file>中，除表头外的文本与数值内容须与<file>/meituan/mm-Operations-014/solution/参考答案_直播脚本流程表.csv</file>中对应的文本与数值内容完全一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-014/input/answer/商品卖点话术卡片表.csv</file>的表头字段依次为'商品编号','品牌名','规格参数','图片卖点关键词','包装形态','产品质地描述','直播价','日常价','产品容器是否透明',除表头外有且仅有5行数据",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-014/input/answer/商品卖点话术卡片表.csv</file>中，除'产品质地描述'列，其余列的文本与数值内容须与<file>/meituan/mm-Operations-014/solution/参考答案_商品卖点话术卡片表.csv</file>中对应的文本与数值内容完全一致",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-014/input/answer/弹窗素材排期表.csv</file>的表头字段依次为'弹窗序号','弹出时间','素材文件名','弹窗时长(秒)',除表头外有且仅有7行数据",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-014/input/answer/弹窗素材排期表.csv</file>中，除表头外的文本与数值内容须与<file>/meituan/mm-Operations-014/solution/参考答案_弹窗素材排期表.csv</file>中对应的文本与数值内容完全一致",
    "weight": 1
  }
]
```
