# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-017/input/answer/ORD-2026-001_sampling_results.md
/meituan/mm-administration-017/input/answer/order_summary_updated.csv
/meituan/mm-administration-017/solution/参考答案_order_summary_updated.csv
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-administration-017/input/answer/ORD-2026-001_sampling_results.md</file> 中包含产品信息部分，且产品信息中包含以下所有维度：Order No. 为 'ORD-2026-001'，Article No. 为 'WIC-4391-SET'，Product Description 为 'Walk-in Wardrobe Set 4391mm'，Front Color 为 'Ivory White'，Body Color 为 'Warm White'，Sample quantity为'4'。数值正确，意思相近即可。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-administration-017/input/answer/ORD-2026-001_sampling_results.md</file> 中包含对质量、样式、颜色三个维度的逐一检查结论，质量为'pass'，并备注样品2柜门上有灰尘；样式为'no pass'，原因是‘与图纸对比，多层衣柜样品多了一根杆子’，意思相近即可；颜色为 'no pass'；比例尺寸维度注明‘不做检查’。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-administration-017/input/answer/ORD-2026-001_sampling_results.md</file> 中整体结论为 'no pass'，且备注中明确说明了整体结论为 no pass 的原因。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-administration-017/input/answer/order_summary_updated.csv</file> 与 <file>/meituan/mm-administration-017/solution/参考答案_order_summary_updated.csv</file>中的内容一致。",
    "weight": 1
  }
]
```
