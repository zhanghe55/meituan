你是 KitchenPro Factory GmbH 的行政采购专员。今天是2026-06-10号，承接上一轮订单处理周期，Müller GmbH（ORD-2026-001）的货物生产已完成，工厂今日发来了装箱信息确认单与样品抽检照片（已告知有1张样品图的柜门上有很明显的灰尘）。你现在需要处理以下新收到的单据，请读取下方所有输入文件:

```
/meituan/mm-administration-017/input/bank_receipt_balance_Muller.png
/meituan/mm-administration-017/input/样品1.jpg
/meituan/mm-administration-017/input/样品2.jpg
/meituan/mm-administration-017/input/样品3.jpg
/meituan/mm-administration-017/input/样品4.jpg
/meituan/mm-administration-017/input/factory_packing_info_Muller.png
/meituan/mm-administration-017/input/order_summary_updated.csv
/meituan/mm-administration-017/input/dealer_order_A_Muller.png
/meituan/mm-administration-017/input/shipping_rules.txt
```
按照以下操作规范完成工作：
### 第一步：样品抽检：
检查多张样品图片，根据order_summary_updated以及dealer_order_A_Muller.png的产品信息，检查样品是否存在质量、颜色、样式等问题，按照以下规则输出至:
```
/meituan/mm-administration-017/input/answer/ORD-2026-001_sampling_results.md
```
先填入产品信息：包含以下维度：'Order No.', 'Article No.', 'Product Description', 'Front Color', 'Body Color ', 产品信息与dealer_order_A_Muller.png中的一致， 'Sample quantity'为本次样品抽检的数量。
请按以下维度逐一检查这一批次的样品，对一个批次的样品有一条完整的抽检结果即可，每个维度单独给出结论（pass 或 no pass）：
- **分维度结论**：
	- 质量：无影响使用的缺陷，无任何裂痕、破碎、缺失部件；轻微瑕疵（如微小划痕、≤1mm²污点）或灰尘可判 Pass，但需备注具体是哪张样品图有轻微可接受的瑕疵
	- 样式：与图纸完全一致；允许不影响功能/外观的微小偏差（2mm）
	- 颜色：与订单色值比对，色差 ΔE ≤ 2 或目视无明显差异
	- 比例尺寸：不做检查
- **整体结论**：仅当所有维度均为 `pass` 时，整体 = `pass`；任一维度为 `no pass` 则整体 = `no pass`。
- **备注要求**：
  - 必须说明整体结论的原因。
  - 若有任何轻微问题（如划痕、微小色差）但仍判 pass，需在备注中明确列出。
  - 若有 no pass 维度，详细描述问题（例如：与图纸对比，XX多了XXX）。


### 第二步：核对尾款、工厂提供的最终产品信息以及抽检信息，更新最终订单汇总表，输出至:
```
/meituan/mm-administration-017/input/answer/order_summary_updated.csv
```
获取付款通知单的相关截图信息，与订单对照，确认信息是否正确，并进行最终汇总表的填写。具体规则如下：
- 根据提供的所有信息，更新表中需要修改的原有字段信息。
- 在表的最后新增'Sampling Results'字段，并根据第一步的判断结果填入相应数据。
- 根据实际尾款情况，在'Deposite Date'右侧插入新增字段'Balance Paid (EUR)'，'Balance Date'，并填入相应数据。
- 'Qty (sets)'：统一填写单位为 sets 的订单数量，如：100, 如果订单中存在单位问题，填入'error'
- 'Status'：根据发货规则及其他输入的文件信息来填写，已确认的订单填写 'Confirmed'，, 正在生产的填写'Producing'；正在运输或生产完成装箱待运输的填写 'Shipping'；已经收货完成交易的填写 'Completed'。填写该订单的最新状态即可。
- dimensions以'width*height*depth'的格式保存，日期用YYYY/M/D的格式保存，如'2026/5/1'。
- 若提供的信息中，未包含某订单的该字段信息，直接置空。



请直接执行，不要向我提问或请求进一步决策，遇到歧义自行判断处理。
