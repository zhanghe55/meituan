# Bug Injection Summary — bigmail-D1-L3-1

## (L1 / D1)
- **位置**: `js/state.js:blockSender()`
- **描述**: `blockSender()` 函数体被替换为直接 `return;`，调用时静默返回，发件人地址永远不会被添加到 `blockedSenders` 列表；操作无任何错误提示，但 Settings > Filters and Blocked Addresses 中始终找不到已阻止的发件人。
- **预期行为**: 在邮件更多操作菜单中执行「Block sender」后，该发件人应出现在 Settings > Filters and Blocked Addresses 的屏蔽列表中。
