# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-hr-020/input/answer/书目筛选结果表.xlsx
/meituan/mm-hr-020/input/answer/采购计划表.xlsx
/meituan/mm-hr-020/solution/参考答案_书目筛选结果表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-hr-020/input/answer/书目筛选结果表.xlsx</file>只含1个Sheet，名称为'书目筛选结果',且表头内容须与<file>/meituan/mm-hr-020/solution/参考答案_书目筛选结果表.xlsx</file>的表头内容完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-hr-020/input/answer/书目筛选结果表.xlsx</file>共12行数据（不含表头），12行数据除'主题相关性评分'和'淘汰原因'列，其它列内容须与<file>/meituan/mm-hr-020/solution/参考答案_书目筛选结果表.xlsx</file>的内容和数值完全一致，‘京东价格、当当网价格、博库价格’列单元格格式需设置为‘数值-小数位数1’",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-hr-020/input/answer/书目筛选结果表.xlsx</file>中序号为'2'、'5'、'7'、'10'的数据'淘汰原因'列内容为‘—’，其余行的'淘汰原因'列必须包含具体的淘汰理由",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-hr-020/input/answer/采购计划表.xlsx</file>中包含1个名为'采购计划'的Sheet，共5行数据（不含表头），列名依次为：序号、书名、采购数量、推荐采购平台、单价（元）、运费（元）、小计（元）（共7列）；前4行为入选书籍的采购明细，第5行'书名'列为'合计'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-hr-020/input/answer/采购计划表.xlsx</file>前4行入选书籍的采购明细中，'序号'列由上至下依次为'2'、'5'、'7'、'10'；'书名'列由上至下依次为'赋能'、'深度学习'、'创新者的窘境'、'智能时代'；四本书均选择当当网，单价分别为49.9、112.0、39.8、52.3（须严格保留到小数点后一位）。采购数量均为10，运费均为0",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-hr-020/input/answer/采购计划表.xlsx</file>中前4行'小计（元）'分别为499.0、1120.0、398.0、523.0（须严格保留到小数点后一位），合计行的'小计（元）'为2540.0（须严格保留到小数点后一位）",
    "weight": 1
  }
]
```
