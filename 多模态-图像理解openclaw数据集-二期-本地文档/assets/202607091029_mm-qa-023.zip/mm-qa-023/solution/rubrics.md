# Rubrics
> **每个 rubric 独立评分，满分 6 分。**
> **🚫 清零规则：若 answer 数组包含任何错误路径（非注入 bug 路径），则本题全部得分立即清零，BC-1 至 BC-6 均得 0 分，不再计算其余项。**
> **⚠️ BC-1 和 BC-2 各自独立：每项需同时满足"answer 数组包含对应路径字母"与"observed/trigger_steps 描述命中该路径 bug 症状关键词"两个条件。BC-3 为 bonus，仅在 BC-1、BC-2 均通过时计分。BC-4/5 分别依赖 BC-1/BC-2，BC-6 依赖 BC-3。**

## 文件读取路径
```path
/meituan/mm-qa-023/input/answer.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【清零规则优先检查】若 answer 数组含错误路径（A、B、D），全部清零。否则：<file>/meituan/mm-qa-023/input/answer.json</file> 中 answer 数组包含\"C\"（路径 C（Reply 时 To 字段填入自己的地址）），且 observed 或 trigger_steps 提到了路径 C 的 bug 症状（提到了 收件人错误、To 字段错误、填入自己、email.to 中的任意一项）。路径选择与症状描述必须同时满足。",
    "weight": 1
  },
  {
    "id": "BC-2",
    "content": "【清零规则优先检查】若 answer 数组含错误路径（A、B、D），全部清零。否则：<file>/meituan/mm-qa-023/input/answer.json</file> 中 answer 数组包含\"E\"（路径 E（批量删除多封邮件仅第一封进入 Trash）），且 observed 或 trigger_steps 提到了路径 E 的 bug 症状（提到了 Trash 只有一封、第二封消失、批量删除部分失效 中的任意一项）。路径选择与症状描述必须同时满足。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "**Bonus：本项仅在 BC-1 AND BC-2 均通过时计分，否则得 0 分。** BC-1 与 BC-2 均已通过（两个注入 bug 均被正确识别并描述），且 answer 不含错误路径（由清零规则保证）。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "**前提：本项仅在 BC-1 通过时计分，否则得 0 分。** <file>/meituan/mm-qa-023/input/answer.json</file> 中 trigger_steps 提到了触发路径 C bug 的具体操作步骤（提到了 Reply 按钮、回复窗口、To 字段、reply 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "**前提：本项仅在 BC-2 通过时计分，否则得 0 分。** <file>/meituan/mm-qa-023/input/answer.json</file> 中 trigger_steps 提到了触发路径 E bug 的具体操作步骤（提到了 勾选、批量、Delete、删除 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-6",
    "content": "**前提：本项仅在 BC-3（Bonus）通过时计分，否则得 0 分。** <file>/meituan/mm-qa-023/input/answer.json</file> 中 expected 提到了两条路径的正确行为（提到了 应为发件人、email.from、全部应进入 Trash 中的任意一项）",
    "weight": 1
  }
]
```
