这是一个 Web 应用，页面地址：

```
http://webapp:8000
```

> **注意**：环境中存在 HTTP 代理，代理无法解析 Docker 内部主机名 `webapp`，且 agent-browser 内置的 Chromium 不支持 `no_proxy` 环境变量。请按以下步骤访问页面：
>
> 1. 先获取 webapp 的 IP 地址：`getent hosts webapp`（例如得到 `10.7.130.2`）
> 2. 使用 agent-browser 时，需要清除所有代理环境变量并使用 IP 地址访问：
> ```bash
> export http_proxy="" && export https_proxy="" && export HTTP_PROXY="" && export HTTPS_PROXY="" && agent-browser open http://<IP>:8000
> ```
> - 查看截图时，请使用 **`read`** 工具直接读取截图文件（`read /path/to/screenshot.png`），
>   不要使用 `image` 工具，`image` 工具在当前环境下不可用。
> - agent-browser 使用说明 详见：`~/.agents/skills/agent-browser/SKILL.md`

该应用是一个邮件管理 Web 应用。请完成以下每道题描述的业务操作，
在操作过程中像 QA 工程师一样观察应用行为，
判断执行过程的页面信息**是否存在 bug**，
判断执行过程中的操作反馈**是否存在 bug**，
判断执行过程中和该操作的关联模块反馈中**是否存在 bug**。

> **Bug 判断标准**：与同类产品的功能差异属于应用的设计选择，不算 bug。
> 只有应用内部行为自相矛盾、或操作结果与应用自身的反馈提示不一致时，才应列为 bug。

测试必须通过浏览器交互工具进行，不得通过 curl、cat、read 等方式直接读取应用的 JS/CSS 源码文件。

---

## 题目

以下五条路径中，每条路径可能存在 bug，也可能不存在 bug（共 0-2 条存在 bug），请依次执行并独立判断。

**路径 A**
在 标签 中为 创建一个名为 Consonnm 的一级标签，颜色为红色，再为其创建一个名为 Leander 的二级标签，颜色为黄色。

---

**路径 B**
在 Settings > Labels 中找到「Newsletters」标签，点击 edit 编辑，将名称修改为另一个名称后保存，浏览侧边栏标签，然后再次编辑将名称改回「Newsletters」保存。

---

**路径 C**
在收件箱中打开一封来自外部联系人发来的邮件，点击 Reply（回复）按钮，在撰写窗口中确认收件人信息后填写回复内容。

---

**路径 D**
在收件箱中阅读几封未读的邮件。

---

**路径 E**
在收件箱中同时勾选 2 封邮件，点击工具栏删除按钮，然后分别浏览各邮件列表模块。

---

## 文件输出要求

如需截图，请保存到 `/app/input/screenshots/` 目录下

以下五条路径中，请选出所有存在 bug 的路径：
- **A**：路径 A 存在 bug
- **B**：路径 B 存在 bug
- **C**：路径 C 存在 bug
- **D**：路径 D 存在 bug
- **E**：路径 E 存在 bug
- **F**：以上路径均不存在 bug

将答案写入 `/app/input/answer.json`，格式如下：

```json
{
  "answer": ["A"],
  "trigger_steps": "分别描述存在 bug 路径的复现操作",
  "observed": "分别描述各 bug 路径实际看到了什么",
  "expected": "正确情况下应该是什么",
  "severity": "high / medium / low"
}
```

answer 为从 A/B/C/D/E 中选出的若干字母组成的数组（bug 数量不固定，可能为 1 个或多个），或 ["F"] 表示均无 bug。
