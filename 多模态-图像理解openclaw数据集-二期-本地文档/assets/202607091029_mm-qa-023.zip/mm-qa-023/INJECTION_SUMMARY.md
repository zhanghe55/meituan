# Bug Injection Summary — bigmail-D3-L23-1

## (L2 / D3) — 路径 C
- **位置**: `js/app.js:case 'reply'`（工具栏回复按钮）
- **描述**: 工具栏 Reply 按钮触发时，收件人字段错误填入 `email.to[0].email`（原邮件的收件人），而非 `email.from.email`（原邮件的发件人）；在邮件详情页点击 Reply 按钮走另一分支，收件人正确填入 `email.from.email`。两条路径行为不一致，工具栏路径会将回复发给错误对象。
- **预期行为**: 回复邮件时，撰写窗口中的收件人应自动填入原邮件的发件人（`email.from.email`）。

## (L3 / D3) — 路径 E
- **位置**: `js/state.js:trashEmails()`
- **描述**: `trashEmails()` 重构后将 `email.isTrashed = true` 移出循环体，改为 `const first = this.getEmailById(emailIds[0]); if (first) first.isTrashed = true;`，导致批量删除多封邮件时仅第一封被标记为 `isTrashed=true` 进入回收站，其余邮件仅被移出 INBOX 标签，既不在收件箱也不在 Trash 中，消失于隐身状态。
- **预期行为**: 批量勾选并删除 N 封邮件后，所有 N 封邮件均应出现在 Trash 视图中。
