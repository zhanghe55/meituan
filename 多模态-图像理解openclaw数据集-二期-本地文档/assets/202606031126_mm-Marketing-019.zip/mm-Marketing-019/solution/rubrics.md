# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-Marketing-019/input/answer/星小椰x噗噗星球联合营销活动星小椰ROI测算表.xlsx
/meituan/mm-Marketing-019/input/answer/物料预审报告.docx
/meituan/mm-Marketing-019/solution/星小椰x噗噗星球联合营销活动星小椰ROI测算表-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-Marketing-019/input/answer/星小椰x噗噗星球联合营销活动星小椰ROI测算表.xlsx</file>中的文字和数值需要和<file>/meituan/mm-Marketing-019/solution/星小椰x噗噗星球联合营销活动星小椰ROI测算表-参考答案.xlsx</file>中的文字和数值一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-Marketing-019/input/answer/物料预审报告.docx</file>中需要包含通过的素材和不通过的素材两部分内容",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-Marketing-019/input/answer/物料预审报告.docx</file>中'通过的素材'这部分内容需要填写'无通过素材'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-Marketing-019/input/answer/物料预审报告.docx</file>中'不通过的素材'这部分内容素材名称需要包含'图1'、'图2'、'图3'、'图4'、'图5'、'图6'，包含以上名称即可，有无文件扩展名不做要求；每个素材名称后需要列明违规问题和修改建议",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-Marketing-019/input/answer/</file>里除了上述提到的两个文件，不应存在其他多余文件",
    "weight": 1
  }
]
```