# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx
/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中的列表头完全一致，且顺序依次是'新人姓名'、'所属部门'、'岗位方向'、'线上考试分数'、'线下实操分数'、'在岗表现分数'、'任务完成质量分数'、'综合得分'、'实操成果图像核对'、'岗位适配等级'、'定级依据'、'主要短板'、'后续培养建议'、'是否重点辅导'、'是否暂缓定级'",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中的行表头姓名完全一致，且顺序依次是'陈思雨'、'李泽航'、'王钰'、'赵晨'、'周明'、'刘雅琪'、'孙浩'、'马欣'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中的综合得分完全一致,依次是'87.4'、'73'、'56.7'、'90.4'、'76.9'、'86.7'、'70.2'、'92.2'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中'实操成果图像核对'的核验结果完全一致,依次是'通过'、'不通过'、'不通过'、'通过'、'不通过'、'通过'、'不通过'、'不通过',冒号后的视觉依据不作精确比对。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中'岗位适配等级'的结果完全一致,依次是'B级-基本适配'、'C级-需重点辅导'、'D级-暂缓定级'、'A级-高度适配'、'C级-需重点辅导'、'B级-基本适配'、'C级-需重点辅导'、'C级-需重点辅导'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中'是否重点辅导'的结果完全一致,依次是'否'、'是'、'是'、'否'、'是'、'否'、'是'、'是'",
    "weight": 1
  },
  {
    "id": "08",
    "content": "输出的<file>/meituan/mm-hr-012/input/answer/新人考核定级表.xlsx</file>和<file>/meituan/mm-hr-012/solution/新人考核定级表答案.xlsx</file>中'是否暂缓定级'的结果完全一致,依次是'否'、'否'、'是'、'否'、'否'、'否'、'否'、'否'",
    "weight": 1
  }
]
```