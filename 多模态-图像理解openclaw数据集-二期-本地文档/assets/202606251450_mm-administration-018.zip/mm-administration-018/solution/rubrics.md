# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-018/input/answer/采购比价报告.xlsx
/meituan/mm-administration-018/solution/采购比价报告-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-administration-018/input/answer/采购比价报告.xlsx</file>中的文字和数值内容需要和<file>/meituan/mm-administration-018/solution/采购比价报告-参考答案.xlsx</file>中的文字和数值内容完全一致",
    "weight": 1
  }
]
```
