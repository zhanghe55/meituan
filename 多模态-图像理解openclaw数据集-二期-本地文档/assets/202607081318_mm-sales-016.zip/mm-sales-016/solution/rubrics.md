# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-016/input/answer/CRM客户全景画像.xlsx
/meituan/mm-sales-016/solution/参考答案CRM客户全景画像.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-sales-016/input/answer/CRM客户全景画像.xlsx</file>文件A、B、C、D、E、G列的内容与 <file>/meituan/mm-sales-016/solution/参考答案CRM客户全景画像.xlsx</file> 的A、B、C、D、E、G列的文本内与行列顺序容完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-sales-016/input/answer/CRM客户全景画像.xlsx</file>文件F2、F4单元格的文本内容需要包含'一字领'，H2、H4单元格文本内容需要包含'M'",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-sales-016/input/answer/CRM客户全景画像.xlsx</file>文件F3、F5、F6、H3、H5、H6单元格的文本内容与 <file>/meituan/mm-sales-016/solution/参考答案CRM客户全景画像.xlsx</file> 的F3、F5、F6、H3、H5、H6单元格的文本内容完全对应一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-sales-016/input/answer/CRM客户全景画像.xlsx</file> 必须包含一张饼状图，饼状图名称为'客户咨询类型分布',饼状图的数据中，异议处理占比43%，物流时效咨询占比14%，尺码版型问题占比43%，数据四舍五入保留至整数",
    "weight": 1
  }
]
```
