# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-012/input/answer/快烤箱配件预算报表.xlsx
/meituan/mm-sales-012/solution/参考答案_快烤箱配件预算报表_含物流.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-sales-012/input/answer/快烤箱配件预算报表.xlsx</file>有且仅有三个工作表：'预算汇总'、'工艺拆分明细'、'对应关系'，工作表顺序与<file>/meituan/mm-sales-012/solution/参考答案_快烤箱配件预算报表_含物流.xlsx</file>一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-sales-012/input/answer/快烤箱配件预算报表.xlsx</file>的核心内容与<file>/meituan/mm-sales-012/solution/参考答案_快烤箱配件预算报表_含物流.xlsx</file>一致：'预算汇总'工作表A1:M11、'工艺拆分明细'工作表A1:G15、'对应关系'工作表A1:G9的文本与数值内容和行列顺序一致；其中'预算汇总'D5:D11、I5:M11以及'工艺拆分明细'D4:E15、G4:G15的数值按两位小数核对，允许绝对误差小于等于0.01",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-sales-012/input/answer/快烤箱配件预算报表.xlsx</file>中'预算汇总'工作表的使用范围为A1:N11，'工艺拆分明细'工作表的使用范围为A1:H15，'对应关系'工作表的使用范围为A1:H9，不存在额外数据行或额外数据列",
    "weight": 1
  }
]
```
