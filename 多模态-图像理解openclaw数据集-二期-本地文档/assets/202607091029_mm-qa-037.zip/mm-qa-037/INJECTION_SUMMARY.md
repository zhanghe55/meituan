# Bug Injection Summary — figma-D3-L23-3_to_check

## b013 (L2 / D3)

- **位置**: `js/state.js:_buildThumbnailCache()` + `js/views.js:_renderPresentationCard()`
- **描述**: 初始化时将每个演示文稿第一张幻灯片快照到 `_thumbnailCache`（会话级 Map，不序列化）。之后卡片缩略图读取快照而非实时数据，编辑器修改背景后返回列表缩略图不更新；刷新页面后缓存从最新 localStorage 重建，才显示新颜色。
- **触发路径**: 从列表进入编辑器 → 修改第一张幻灯片背景色 → 返回列表 → 卡片缩略图仍显示旧颜色
- **可见矛盾**: 编辑器/Filmstrip 已显示新背景色，列表卡片仍显示旧背景色

## b014 (L3 / D3)

- **位置**: `js/state.js:createPresentation()`
- **描述**: `createPresentation()` 将 slideCount 初始化为 0（应为 1），导致新建演示文稿的 Dashboard 卡片显示「0 slides」，而编辑器 Filmstrip 正确显示 1 张幻灯片，形成跨模块矛盾。
- **触发路径**: 新建演示文稿 → 进入编辑器查看 Filmstrip → 返回 Dashboard 查看卡片 slideCount
