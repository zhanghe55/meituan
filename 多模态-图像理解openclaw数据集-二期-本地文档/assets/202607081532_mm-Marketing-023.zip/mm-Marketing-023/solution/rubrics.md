# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-023/input/answer/舆情分类与分析结果表.xlsx
/meituan/mm-Marketing-023/input/answer/紧急舆情专报.docx
/meituan/mm-Marketing-023/input/answer/舆情风险日报.docx
/meituan/mm-Marketing-023/solution/舆情分类与分析结果表参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-023/input/answer/舆情分类与分析结果表.xlsx</file>的A-E列、H列与<file>/meituan/mm-Marketing-023/solution/舆情分类与分析结果表参考答案.xlsx</file>表的A-E列、H列的内容完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-023/input/answer/舆情分类与分析结果表.xlsx</file>中F列与<file>/meituan/mm-Marketing-023/solution/舆情分类与分析结果表参考答案.xlsx</file>中F列的文本内容和格式一致，同时如果涉及多个三级分类，中间必须用‘；’隔开，‘；’链接的多个三级分类的书写顺序不要求一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-023/input/answer/舆情分类与分析结果表.xlsx</file>的G列仅G2、G4-G6、G8-G9、G11-16单元格对核心槽点进行了分析，G2单元格内容需要提到‘头发’，G4单元格内容需要提到‘下雨天骑手送餐，服务态度好’，G5单元格内容需要提到‘腐烂’或‘质量问题’，G6单元格内容需要提到‘洒漏’，G8单元格内容需要提到‘洒漏’，G9单元格内容需要提到‘塑料薄膜异物’，G11单元格内容需要提到‘骑手打架’，G12单元格内容需要提到‘配送快’，G13单元格内容需要提到‘大数据杀熟’，G14单元格内容需要提到‘份量虚假宣传’，G15单元格内容需要提到‘App访问出错’，G16单元格内容需要提到‘房间干净’，内容不要求完全一致，但意思需要相近；",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-023/input/answer/紧急舆情专报.docx</file>中，必须包含【P1紧急】YQ-20250615-001、【P1紧急】YQ-20250615-004、【P1紧急】YQ-20250615-008、【P1紧急】YQ-20250615-012这4条舆情标题，舆情的模块内容包含'事件概述'、'当前影响'、'风险评估'、'建议措施'、'涉及舆情原文摘录'；4条舆情的'事件概述'的大致意义分别为‘外卖中发现头发异物’、‘蔬菜腐烂’、‘外卖中含塑料异物’、‘美团会员大数据杀熟’；‘风险评估’均为P1等级",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-023/input/answer/舆情风险日报.docx</file>中，包含舆情ID为‘YQ-20250615-005’、‘YQ-20250615-007’、‘YQ-20250615-010’、‘YQ-20250615-013’、‘YQ-20250615-014’的5条舆情，每条舆情的‘逐条摘要’大致意义分别为‘配送中汤汁洒漏’、‘奶茶洒漏且骑手态度差’、‘骑手打架斗殴’、‘商品图分量与实际不符’、‘支付页面报错’，涉及的舆情发布平台分别为‘微博’、‘微博’、‘小红书’、‘微博’、‘小红书’；",
    "weight": 1
  }
]
```