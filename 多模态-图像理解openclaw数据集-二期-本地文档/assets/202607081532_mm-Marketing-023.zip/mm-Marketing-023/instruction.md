你是美团的舆情分析师，负责对每日从微博、小红书等社交平台收集到的原始舆情数据进行清洗、分类和风险预警。

输入文件

```
/meituan/mm-Marketing-023/input/今日原始舆情数据.xlsx
/meituan/mm-Marketing-023/input/pic_001.png
/meituan/mm-Marketing-023/input/pic_002.png
/meituan/mm-Marketing-023/input/pic_003.png
/meituan/mm-Marketing-023/input/pic_004.png
/meituan/mm-Marketing-023/input/pic_005.png
/meituan/mm-Marketing-023/input/pic_006.png
/meituan/mm-Marketing-023/input/pic_007.png
/meituan/mm-Marketing-023/input/pic_008.png
/meituan/mm-Marketing-023/input/pic_009.png
/meituan/mm-Marketing-023/input/pic_010.png
/meituan/mm-Marketing-023/input/pic_011.png
/meituan/mm-Marketing-023/input/pic_012.png
/meituan/mm-Marketing-023/input/pic_013.png
/meituan/mm-Marketing-023/input/pic_014.png
/meituan/mm-Marketing-023/input/pic_015.png
/meituan/mm-Marketing-023/input/舆情信息清洗规范.docx
/meituan/mm-Marketing-023/input/舆情多级分类与槽点提取指南.docx
/meituan/mm-Marketing-023/input/风险定级判断与联系人.docx
```
任务描述：

1. 新建一个Excel文件，命名为‘舆情分类与分析结果表’，表头依次为‘舆情ID’、‘清洗状态’、‘过滤原因’、‘一级分类（情感极性）’、‘二级分类（业务归属）’、‘三级分类（细分事由）’、‘核心槽点分析’、‘风险等级评估’
2. ‘舆情ID’列和‘今日原始舆情数据.xlsx’中‘舆情ID’列的内容和顺序完全一致，‘清洗状态’列的取值有且仅有‘保留’或‘过滤’两种。
3. ‘过滤原因’列：若清洗状态为‘保留’则留空；若为‘过滤’则填写标准化原因（从‘营销推广广告’、‘水军刷好评’、‘无意义重复内容’中选取）；被过滤的数据行，‘一级分类（情感极性）’、‘二级分类（业务归属）’、‘三级分类（细分事由）’、‘核心槽点分析’四列均留空。
4. 被保留的数据行，四列分类字段必须全部填写：
   - ‘一级分类（情感极性）’取值为‘正面’、‘负面’或‘中性’
   - ‘二级分类（业务归属）’内容必须按照‘舆情多级分类与槽点提取指南.docx’中二级分类中的业务归属来填写，如果涉及多个二级分类，中间用‘；’隔开
   - ‘三级分类（细分事由）’内容必须按照‘舆情多级分类与槽点提取指南.docx’中三级分类的细分事由来填写，格式为‘二级分类-细分事由’，如‘商家问题-食品安全’，如果涉及多个三级分类，中间用‘；’隔开，
   - ‘核心槽点分析’需结合文本与配图内容，用一句话提炼用户的核心诉求或好评点
5. 根据‘风险定级判断与联系人.docx’，对上面保留且判定为‘负面’的舆情逐条进行风险等级评估，‘风险等级评估’列取值为‘P1’、‘P2’、‘P3’。
6. 针对P1级舆情，输出一份《紧急舆情专报》，专报内容要求：
- 专报中，每条P1级舆情涉及的内容单独一个模块，每个模块的标题格式为‘【P1紧急】舆情ID’，如“【P1紧急】YQ-20250615-001”；
- 每条P1级舆情都包含以下结构：事件概述、当前影响、风险评估、建议措施、涉及舆情原文摘录
- 事件概述需说明何时、何平台、何用户、发生了什么
- 建议措施需提出2-3条具体可执行的应对建议
7. 针对P2级舆情，输出一份《舆情风险日报》， 日报内容要求：
- 标题为 ‘美团舆情风险日报 2025年6月15日’
- 包含以下章节：今日概况、逐条摘要、趋势分析、建议关注点
- 今日概况需说明P2级舆情总条数及涉及的业务线分布
- 逐条摘要需包含每条P2舆情的舆情ID、涉及舆情发布平台、事由和风险点

输出文件：

```
/meituan/mm-Marketing-023/input/answer/舆情分类与分析结果表.xlsx
/meituan/mm-Marketing-023/input/answer/舆情风险日报.docx
/meituan/mm-Marketing-023/input/answer/紧急舆情专报.docx
```

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。