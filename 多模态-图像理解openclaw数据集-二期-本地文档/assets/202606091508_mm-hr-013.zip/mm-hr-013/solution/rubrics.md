# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中,至少包含'最终结论'、'数据整体表现'、'详细分析'、'高频薄弱点与共性问题'、'问题定位'、'优化建议'这6部分内容。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中,'数据整体表现'部分必须包含表格，表格表头字段需按顺序依次为'指标'、'结果'、'依据'、'复盘判断'。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中,'数据整体表现'表格的第一列'指标'从第二行开始需按顺序依次为'应参训人数'、'实际到场人数'、'缺席人数'、'出勤率'、'必修学习完成率'、'考核通过率'、'重点辅导人数'、'暂缓定级人数'。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中,'数据整体表现'表格的'结果'列需依次为'8人'、'7人'、'1人'、'87.5%'、'75.0%'、'62.5%'、'3人'、'1人',人数类结果忽略单位是否带'人'。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中，'重点辅导人数'对应的'依据'字段必须只有'王钰'、'孙浩'、'马欣'三人姓名。",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-hr-013/input/answer/新人培训复盘报告.pdf</file>文档中，'暂缓定级人数'对应的'依据'字段必须只有'王钰'。",
    "weight": 1
  }
]
```