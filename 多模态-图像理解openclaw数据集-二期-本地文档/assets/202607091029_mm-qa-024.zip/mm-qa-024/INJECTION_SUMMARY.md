# Bug Injection Summary — bigmail-D3-L33-1

## b004 (L2 / D3)
- **位置**: `js/app.js:_advanceAfterAction()`
- **描述**: `newer` 分支从 `older` 分支 copy-paste 后忘记改方向：条件由 `idx > 0` 改为 `idx < emails.length - 1`，索引由 `emails[idx - 1]` 改为 `emails[idx + 1]`。邮件列表按时间降序排列（index 0 最新），`idx + 1` 实际指向更旧邮件，导致 Auto-advance 设为「newer」时归档后实际跳转到更旧的邮件。
- **预期行为**: Auto-advance 设为「Go to the next (newer) conversation」时，归档邮件后应自动跳转到时间上比当前邮件更新（日期更近）的邮件。

## b006 (L3 / D3)
- **位置**: `js/state.js:moveToInbox()`
- **描述**: 重构时从 `muteEmails` copy-paste 状态清理代码，漏将 `email.isMuted = true` 改为 `false`。`isTrashed / isArchived` 均正确清除、INBOX 标签正确添加、toast 显示成功，但 `getInboxEmails()` 含 `!e.isMuted` 过滤条件，邮件从 Trash 消失后在收件箱中始终找不到，进入隐身状态。
- **预期行为**: 将 Trash 中邮件 Move to Inbox 后，邮件应从 Trash 移除并出现在 Inbox 视图中。
