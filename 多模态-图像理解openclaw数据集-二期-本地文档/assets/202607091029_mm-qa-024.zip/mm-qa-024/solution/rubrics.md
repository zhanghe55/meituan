# Rubrics
> **每个 rubric 独立评分，满分 6 分。**
> **🚫 清零规则：若 answer 数组包含任何错误路径（非注入 bug 路径），则本题全部得分立即清零，BC-1 至 BC-6 均得 0 分，不再计算其余项。**
> **⚠️ BC-1 和 BC-2 各自独立：每项需同时满足"answer 数组包含对应路径字母"与"observed/trigger_steps 描述命中该路径 bug 症状关键词"两个条件。BC-3 为 bonus，仅在 BC-1、BC-2 均通过时计分。BC-4/5 分别依赖 BC-1/BC-2，BC-6 依赖 BC-3。**

## 文件读取路径
```path
/meituan/mm-qa-024/input/answer.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【清零规则优先检查】若 answer 数组含错误路径（A、C、E），全部清零。否则：<file>/meituan/mm-qa-024/input/answer.json</file> 中 answer 数组包含\"B\"（路径 B（Auto-advance Newer 方向反，归档后跳到更旧邮件）），且 observed 或 trigger_steps 提到了路径 B 的 bug 症状（提到了 跳转到更旧、方向相反、Auto-advance 错误 中的任意一项）。路径选择与症状描述必须同时满足。",
    "weight": 1
  },
  {
    "id": "BC-2",
    "content": "【清零规则优先检查】若 answer 数组含错误路径（A、C、E），全部清零。否则：<file>/meituan/mm-qa-024/input/answer.json</file> 中 answer 数组包含\"D\"（路径 D（Move to Inbox 后邮件不出现在收件箱）），且 observed 或 trigger_steps 提到了路径 D 的 bug 症状（提到了 收件箱找不到、Inbox 不出现、操作无效、隐身 中的任意一项）。路径选择与症状描述必须同时满足。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "**Bonus：本项仅在 BC-1 AND BC-2 均通过时计分，否则得 0 分。** BC-1 与 BC-2 均已通过（两个注入 bug 均被正确识别并描述），且 answer 不含错误路径（由清零规则保证）。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "**前提：本项仅在 BC-1 通过时计分，否则得 0 分。** <file>/meituan/mm-qa-024/input/answer.json</file> 中 trigger_steps 提到了触发路径 B bug 的具体操作步骤（提到了 Auto-advance、Settings、归档、Archive 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "**前提：本项仅在 BC-2 通过时计分，否则得 0 分。** <file>/meituan/mm-qa-024/input/answer.json</file> 中 trigger_steps 提到了触发路径 D bug 的具体操作步骤（提到了 Move to Inbox、移回收件箱、Trash 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-6",
    "content": "**前提：本项仅在 BC-3（Bonus）通过时计分，否则得 0 分。** <file>/meituan/mm-qa-024/input/answer.json</file> 中 expected 提到了两条路径的正确行为（提到了 更新邮件、应出现、应回到收件箱 中的任意一项）",
    "weight": 1
  }
]
```
