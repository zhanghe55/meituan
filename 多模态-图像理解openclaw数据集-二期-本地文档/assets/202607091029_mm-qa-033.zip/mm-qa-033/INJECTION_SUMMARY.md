# Bug Injection Summary — figma-D2-L1-1

## b005 (L3 / D2)
- **位置**: `js/views.js:renderDashboard()`
- **描述**: Dashboard 排序方向切换按钮的图标与实际排序方向相反：sortOrder 为 'desc'（降序）时显示上箭头 ↑，为 'asc'（升序）时显示下箭头 ↓，图标语义与实际数据顺序颠倒。
- **预期行为**: sortOrder 为 'desc' 时显示下箭头 ↓（表示当前为降序），为 'asc' 时显示上箭头 ↑（表示当前为升序），图标与实际排序方向一致。

