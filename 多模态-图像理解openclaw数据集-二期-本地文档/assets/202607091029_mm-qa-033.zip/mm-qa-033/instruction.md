这是一个 Web 应用，页面地址：

```
http://webapp:8000
```

> **注意**：环境中存在 HTTP 代理，代理无法解析 Docker 内部主机名 `webapp`，且 agent-browser 内置的 Chromium 不支持 `no_proxy` 环境变量。请按以下步骤访问页面：
>
> 1. 先获取 webapp 的 IP 地址：`getent hosts webapp`（例如得到 `10.7.130.2`）
> 2. 使用 agent-browser 时，需要清除所有代理环境变量并使用 IP 地址访问：
> ```bash
> export http_proxy="" && export https_proxy="" && export HTTP_PROXY="" && export HTTPS_PROXY="" && agent-browser open http://<IP>:8000
> ```
> - 查看截图时，请使用 **`read`** 工具直接读取截图文件（`read /path/to/screenshot.png`），
>   不要使用 `image` 工具，`image` 工具在当前环境下不可用。
> - agent-browser 使用说明 详见：`~/.agents/skills/agent-browser/SKILL.md`

该应用是一个演示文稿设计与管理 Web 应用。请完成以下题目描述的业务操作，
在操作过程中像 QA 工程师一样观察应用行为，
判断执行过程的页面信息**是否存在 bug**，
判断执行过程中的操作反馈**是否存在 bug**，
判断执行过程中和该操作的关联模块反馈中**是否存在 bug**。

> **Bug 判断标准**：与同类产品的功能差异属于应用的设计选择，不算 bug。
> 只有应用内部行为自相矛盾、或操作结果与应用自身的反馈提示不一致时，才应列为 bug。

测试必须通过浏览器交互工具进行，不得通过 curl、cat、read 等方式直接读取应用的 JS/CSS 源码文件。

---

## 题目

以下四条路径中，每条路径可能存在 bug，也可能不存在 bug，请依次执行并独立判断。

**路径 A**
从 Presentations 列表打开一个演示文稿进入编辑器，在编辑器中，选用矩形工具在画布上添加 3 个矩形元素，在属性面板中依次调整各矩形的位置坐标和尺寸数值。

---

**路径 B**
在 Presentations 列表，切换排序。

---

**路径 C**
从 Presentations 列表打开一个演示文稿进入编辑器，在编辑器中，选用圆形工具在画布上添加 1 个圆形元素，将他拖动到页面中央，修改底色为黑色。

---

**路径 D**
在编辑器中打开有多张幻灯片的演示文稿，进入 Presenter Mode，用键盘右箭头导航至第 5 张幻灯片，点击 Notes 按钮关闭备注面板，继续导航到第 8 张，然后按 Escape 退出演示模式。

---

## 文件输出要求

如需截图，请保存到 `/app/input/screenshots/` 目录下

对每条路径，根据你的实际操作观察，判断是否存在 bug：
- **A**：路径 A 存在 bug
- **B**：路径 B 存在 bug
- **C**：路径 C 存在 bug
- **D**：路径 D 存在 bug
- **E**：以上路径均不存在 bug

将答案写入 `/app/input/answer.json`，格式如下：

```json
{
  "answer": "A",
  "trigger_steps": "复现该 bug 的操作序列",
  "observed": "实际看到了什么",
  "expected": "正确情况下应该是什么",
  "severity": "high / medium / low"
}
```

answer 为 A、B、C、D、E 之一。若 answer 为 E（无 bug），其余字段可留空字符串。
