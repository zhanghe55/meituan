# Rubrics
> **每个 rubric 独立评分，满分 5 分。**
> **⚠️ 评分规则（新版）：BC-1 需同时满足"答案字母正确"与"observed 字段命中注入 bug 症状关键词"两个条件，两者缺一则 BC-1 得 0 分，BC-2/3/4 亦不计分。即：选项选对但描述的是其他 bug、或描述对但选项选错，均不得分。**

## 文件读取路径
```path
/meituan/mm-qa-033/input/answer.json
```

```json
[
  {
    "id": "BC-1",
    "content": "<file>/meituan/mm-qa-033/input/answer.json</file> 中 answer 字段值为\"B\"（答案为路径 B 且 observed 命中注入 bug 症状（排序图标与实际方向相反））。两个条件——答案字母正确 AND observed 字段提到了（图标相反、方向错误、↑↓倒置、箭头颠倒 中的任意一项）——必须同时满足，任一不满足 BC-1 得 0 分。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-033/input/answer.json</file> 中 trigger_steps 提到了查看 Dashboard 排序方向按钮图标（提到了 排序、方向、图标、↑↓、按钮 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-033/input/answer.json</file> 中 observed 对注入 bug 现象的描述更完整（提到了 图标相反、方向错误、↑↓倒置、箭头颠倒 中的任意一项，且结合具体数值、状态或对比说明）",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-033/input/answer.json</file> 中 expected 提到了图标应与实际排序方向一致（提到了 方向一致、图标正确、语义一致 中的任意一项）",
    "weight": 1
  }
]
```
