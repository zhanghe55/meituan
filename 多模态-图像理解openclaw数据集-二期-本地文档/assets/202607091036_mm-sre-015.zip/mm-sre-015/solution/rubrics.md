# Rubrics

> **rubric 权重合计 6 分,每条独立评分、互不重叠。**
>
> **门槛规则:BC-1 是门槛项(2 分)。BC-1 未通过则本卷判 0 分,BC-2~BC-5 一律不计分。** BC-1 通过后,BC-2~BC-5 各自独立判分。

## 文件读取路径
```path
/meituan/mm-sre-015/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【门槛项】<file>/meituan/mm-sre-015/input/answers.json</file> 须同时满足两个条件,任一不满足则 BC-1 得 0 分且 BC-2~BC-5 均不计分:(1) failed_service 判断为 `cart`(而非因调用它而报错的上游 checkout / frontend,也非错误率绝对值更高的常驻噪声 product-reviews);(2) fault_type 判断为错误型故障(存储依赖失败 / gRPC 调用错误,而非变慢或资源耗尽)。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "【源头 vs 传播,仅 BC-1 通过时计分】evidence 体现对『源头 vs 传播』与噪声甄别:cart 是错误从 0 基线拉起的源头且错误全集中在 `EmptyCart` 操作;checkout 因在下单末尾调用 cart.EmptyCart 出现同步错误(传播);product-reviews / frontend 是基线噪声须排除。提到 cart从0拉起、EmptyCart、checkout同步传播、product-reviews背景噪声 中的任意一项即得分。本项只考甄别逻辑,不要求给出具体数值(数值在 BC-5 判)。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "【根因行为,仅 BC-1 通过时计分】root_cause 指向 cartFailure 行为——cart 的 EmptyCart 切到一个连不上 redis / valkey 的损坏存储,`ValkeyCartStore.EnsureRedisConnected()` 失败,每次 EmptyCart 抛 `Grpc.Core.RpcException` / `FailedPrecondition`(连不上 redis)。提到 cartFailure、连不上redis / valkey、EnsureRedisConnected、FailedPrecondition、RpcException、存储依赖失败 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "【三信号运用,仅 BC-1 通过时计分】evidence 命中本故障最核心的反直觉考点:证据只在 trace span 的 exception event,日志层完全无签名(cart 零 Error、关键字 `connect to redis` 在日志里 0 命中),必须靠 trace / span-metrics 定位而非日志。提到 日志零签名 / 零Error、connect to redis 日志0命中、证据在trace span exception、须靠trace而非日志 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "【量化峰值,仅 BC-1 通过时计分】evidence 指认关键信号并读出窗口内峰值量级(涉及具体数值时以窗口内最大值为准):(a) 指认到 cart(而非噪声 product-reviews)的错误率信号(traces_span_metrics_calls_total{status_code=\"STATUS_CODE_ERROR\",service_name=\"cart\"},或按 span_name 定位到 EmptyCart,或等价的看板 Error Rate 面板),(b) 明确的『0 → 峰 ~0.92/s』峰值量级读数。缺信号指认或缺峰值量级读数均不得分。",
    "weight": 1
  }
]
```
