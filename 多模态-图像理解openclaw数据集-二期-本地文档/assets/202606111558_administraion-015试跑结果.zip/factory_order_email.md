# Factory Order Submission Email

**To:** orders@kitchenpro-factory.de  
**From:** procurement@kitchenpro-factory.de  
**Subject:** Purchase Order Submission – ORD-2026-001 & ORD-2026-002  

---

Dear KitchenPro Factory Production Team,

Please find below the confirmed purchase orders submitted for production scheduling. The corresponding order PDF files are attached to this email.

---

**Order 1**

- **Dealer:** Muller GmbH
- **Order No.:** ORD-2026-001
- **Product:** Walk-in Wardrobe Set 4391mm (Article No.: WRC-4391-SET)
- **Quantity:** 85 sets

---

**Order 2**

- **Dealer:** Nordic Home AB
- **Order No.:** ORD-2026-002
- **Product:** Dining Chair 850mm (Article No.: DC-850-SET)
- **Quantity:** 200 sets

---

Please process the above orders at your earliest convenience. Should you have any questions regarding the specifications, do not hesitate to contact us.

**Attachments:**
- ORD-2026-001_Muller_GmbH_order.pdf
- ORD-2026-002_Nordic_Home_AB_order.pdf

Best regards,

KitchenPro Factory GmbH – Procurement Department  
procurement@kitchenpro-factory.de  
Industriestraße 42, 70565 Stuttgart, Germany  
Tel: +49 711 123456
