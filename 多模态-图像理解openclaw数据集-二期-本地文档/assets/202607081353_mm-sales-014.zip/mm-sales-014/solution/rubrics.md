# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-014/input/answer/数控刀片发货复核归档表.xlsx
/meituan/mm-sales-014/solution/参考答案_数控刀片发货复核归档表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-sales-014/input/answer/数控刀片发货复核归档表.xlsx</file>与<file>/meituan/mm-sales-014/solution/参考答案_数控刀片发货复核归档表.xlsx</file>满足以下要求：有且仅有1个sheet，名称为`发货复核归档`；`发货复核归档`的A-AG列范围内所有文本和数值内容以及行列顺序一致",
    "weight": 1
  }
]
```
