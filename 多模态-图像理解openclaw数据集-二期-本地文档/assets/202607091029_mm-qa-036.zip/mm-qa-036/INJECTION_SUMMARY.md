# Bug Injection Summary — figma-D3-L23-3

## b015 (L2 / D3)
- **位置**: `js/state.js:toggleResolveComment()`
- **描述**: toggleResolveComment() 将 toggle 逻辑（!comment.resolved）改为始终赋值 false（comment.resolved = false），导致对「未解决」评论点击"解决"按钮时，resolved 本已为 false，赋值 false 后不发生任何变化，解决按钮图标无响应；而对「已解决」评论点击时，将从 true 改为 false，反而正确地变为未解决。
- **预期行为**: 点击未解决评论的解决按钮后，评论应变为已解决状态（绿色勾图标，文字变灰），工具栏徽章计数 -1；点击已解决评论的解决按钮后，评论恢复为未解决状态。

## b016 (L3 / D3)
- **位置**: `js/state.js:addSlide()`
- **描述**: addSlide() 在向 slides 数组推入新幻灯片后，省略了对 pres.slideCount 和 pres.updatedAt 的更新，导致在编辑器中新增幻灯片后 Filmstrip 计数正确，但 Dashboard 卡片上的幻灯片数量仍显示操作前的旧数值。
- **预期行为**: 每次在编辑器中新增幻灯片后，pres.slideCount 应实时更新，使 Dashboard 卡片显示与 Filmstrip 一致的幻灯片总数。

