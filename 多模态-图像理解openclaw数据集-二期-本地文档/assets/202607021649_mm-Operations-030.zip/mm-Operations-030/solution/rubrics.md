# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx
/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>文件，且该文件包含4个sheet，sheet名称分别为：‘客源信息整合表’、‘意向客户产品匹配表’、‘优质商机报价策略表’、‘更新后客户档案’；",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>的‘客源信息整合表’sheet中，表头A1-L1单元格有且仅有以下12个字段，字段名称与顺序完全一致：‘来源渠道’、‘产品名称’、‘买家国家’、‘采购量(pcs)’、‘目标价(USD)’、‘认证要求’、‘截止日期’、‘文字需求描述’、‘附件情况’、‘图片需求点’、‘客户意向度评分’、‘客户评级’；共5行数据（不含表头），其中 A-G 列、J-L 列的最终显示内容需要与<file>/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx</file>的‘客源信息整合表-参考答案’sheet对应列的显示文本和数值内容保持完全一致，忽略单元格格式设置及中英文符合，最终显示一致即可；",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>的‘客源信息整合表’sheet中，H 列的H2-H4单元格内容内容的要点表述需要包含<file>/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx</file>的‘客源信息整合表-参考答案’sheet内对应单元格中的所有要点，H5-H6的单元格内容需要与‘客源信息整合表-参考答案’中对应单元格的英文文字内容保持完全一致，忽略空格和标点符号；I 列中I2-I3单元格的内容从上到下的内容必须以‘INQ-xxx.png’的格式结尾，按照文件名升序排列，从上往下依次为：‘INQ-001.png’、‘INQ-002.png’,I4-I6单元格的内容均为中文汉字‘无’；",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>的‘意向客户产品匹配表’sheet中，表头A1-E1单元格有且仅有以下5个字段，字段名称与顺序完全一致：‘客源ID’、‘来源渠道’、‘匹配的商品型号’、‘匹配度结论’、‘差异点说明’；共5行数据（不含表头），其中 A-D 列中的内容需要与<file>/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx</file>的‘意向客户产品匹配表-参考答案’sheet中 A-D 列的显示文本和数值内容保持完全一致，忽略A列的空格和标点符号，忽略单元格格式设置，最终显示一致即可；E列单元格差异点的输出格式统一为：‘客户需求为xxxx；我方产品为xxxx。’，其中E2单元格在‘结构’层面给出的内容需要与‘意向客户产品匹配表-参考答案’sheet中，对应单元格关于‘结构’的表述保持指向的差异点一致，E3单元格在‘外观’、‘结构’、‘功能’层面给出的内容需要与‘意向客户产品匹配表-参考答案’sheet中，对应单元格关于这三部分的内容表述保持指向的差异点一致，以上两个单元格的文字描述不做限制，仅需满足格式、标点使用要求即可；E4-E6单元格中的内容需要与‘外观：无。结构：无。功能：无。场景：无。’保持文字和标点使用的完全一致；",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>的‘优质商机报价策略表’sheet中，表头A1-I1单元格有且仅有以下9个字段，字段名称与顺序完全一致：‘客源ID’、‘来源渠道’、‘匹配产品型号’、‘基础报价(USD)’、‘认证附加费(USD/pcs)’、‘市场溢价系数’、‘竞品均价(USD)’、‘竞品修正’、‘最终推荐报价区间(USD)’；共3行数据（不含表头），其中 A-I 列的内容与<file>/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx</file>的‘优质商机报价策略表-参考答案’sheet的对应列的显示文本和数值内容保持完全一致，忽略A列的空格和标点符号，忽略单元格格式设置，最终显示一致即可；",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx</file>的‘更新后客户档案’sheet中，表头A1-J1单元格有且仅有以下10个字段，字段名称与顺序完全一致：‘买家ID’、‘来源渠道’、‘买家国家’、‘需要产品名称’、‘采购量级(pcs)’、‘意向度’、‘产品匹配度’、‘推荐报价区间(USD)’、‘首次接触日期’、‘跟进优先级’；共6行数据（不含表头），所有行的内容与<file>/meituan/mm-Operations-030/solution/获客全链路分析表-参考答案.xlsx</file>的‘更新后客户档案-参考答案’sheet中对应行的显示文本和数值内容保持完全一致，忽略A列的空格和标点符号，忽略单元格格式设置，最终显示一致即可。",
    "weight": 1
  }
]
```
