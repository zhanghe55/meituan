你是阿里国际站LED台灯类目运营人员，需完成当日完整获客链路工作。请依次读取以下输入文件，按照获客流程文档中的SOP步骤，完成客源整合、意向度评分、产品匹配分析、报价策略制定及客户档案更新的全链路操作。

输入文件在：
```
/meituan/mm-Operations-030/input/站内消息汇总表.xlsx
/meituan/mm-Operations-030/input/INQ-001.png
/meituan/mm-Operations-030/input/INQ-002.png
/meituan/mm-Operations-030/input/平台RFQ列表截图.png
/meituan/mm-Operations-030/input/我方产品报价表.xlsx
/meituan/mm-Operations-030/input/现有客户档案.xlsx
/meituan/mm-Operations-030/input/获客流程文档.docx
```

任务要求：依据给定的‘INQ-001.png’、‘INQ-002.png’、‘平台RFQ列表截图.png’图片文件，严格遵循‘获客流程文档.docx’中的需求，结合输入的表格文件，输出一个xlsx文件：‘获客全链路分析表.xlsx’，其中必须包含4个sheet。

输出到：
```
/meituan/mm-Operations-030/input/answer/获客全链路分析表.xlsx
```

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
