# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-011/input/answer/快烤箱配件内部报价单.xlsx
/meituan/mm-sales-011/solution/参考答案_快烤箱配件内部报价单.xlsx
/meituan/mm-sales-011/input/快烤箱配件内部报价单模板.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-sales-011/input/answer/快烤箱配件内部报价单.xlsx</file>中的所有 sheet 名称和顺序与<file>/meituan/mm-sales-011/solution/参考答案_快烤箱配件内部报价单.xlsx</file>完全一致；第 1 个 sheet 必须为“报价汇总”，后续零件 sheet 必须按 BOM 序号升序排列并使用“两位序号_零件名称”的命名格式",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-sales-011/input/answer/快烤箱配件内部报价单.xlsx</file>必须在<file>/meituan/mm-sales-011/input/快烤箱配件内部报价单模板.xlsx</file>的原有格式基础上填写；模板中已有的表头、说明文本、固定公式和报价日期不得删除、移动或改写；报价汇总仅填写 A4：I10，零件 sheet 填写范围不得超过 A1：H41",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-sales-011/input/answer/快烤箱配件内部报价单.xlsx</file>与<file>/meituan/mm-sales-011/solution/参考答案_快烤箱配件内部报价单.xlsx</file>中“报价汇总”sheet 的 A4：I10 对应单元格的数值和文本内容以及行列顺序完全一致；每个零件 sheet 的 B4：B6、D4：D5、F4、B10：B19、B37：B41 对应单元格的数值和文本内容以及行列顺序完全一致，其中 B6 需使用类似 OD36/ID12.1/L19.5 的格式；参考答案中为公式的单元格，答案中对应单元格也必须填写相同公式",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-sales-011/input/answer/快烤箱配件内部报价单.xlsx</file>中每个零件 sheet 的“三、工步成本计算”区域单独校验 B23：B34、D23：D34、E23：E34、F23：F34、G23：G34；按“工步名称、计价单位、单价、价格计算系数、工步金额公式”的组合与<file>/meituan/mm-sales-011/solution/参考答案_快烤箱配件内部报价单.xlsx</file>中对应零件 sheet 一致，工步行顺序可以不同；不得缺少、增加或改写工步；同名工步可以分行填写，也可以合并后使用累计价格计算系数填写；每个已填写工步行的工步金额必须为本行单价乘以本行价格计算系数的 Excel 公式",
    "weight": 1
  }
]
```
