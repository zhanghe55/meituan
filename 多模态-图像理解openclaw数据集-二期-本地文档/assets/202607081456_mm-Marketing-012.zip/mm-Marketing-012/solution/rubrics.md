# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-012/input/answer/打样质检和试产测试.xlsx
/meituan/mm-Marketing-012/solution/打样质检和试产测试参考答案.xlsx
/meituan/mm-Marketing-012/input/answer/产品上市报告.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/打样质检和试产测试.xlsx</file> 包含两个工作表，Sheet1 命名为‘打样质检’，Sheet2 命名为‘测试结果’",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/打样质检和试产测试.xlsx</file> 中Sheet1（打样质检）的A-M列文本内容与<file>/meituan/mm-Marketing-012/solution/打样质检和试产测试参考答案.xlsx</file>中Sheet1（打样质检）的A-M列填写的单元格的文字及符号内容完全一致，且数据的顺序也是一致的",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/打样质检和试产测试.xlsx</file> 的 Sheet2（测试结果）中A-E列的文本和数值内容，与输入文件 <file>/meituan/mm-Marketing-012/solution/打样质检和试产测试参考答案.xlsx</file> 的 Sheet2（测试结果）A-E的文本及数值内容完全一致，且数据的顺序也是一致的",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/打样质检和试产测试.xlsx</file>的 Sheet2（测试结果）中，F3、F5和F15单元格中必须包含‘后续优化’4个字",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/产品上市报告.docx</file> 可正常打开，且必须包含以下四个章节标题：‘用户体验反馈分析’、‘市场销售趋势分析’、‘退换货问题诊断’、‘上市策略建议’",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/产品上市报告.docx</file> 的‘用户体验反馈分析’章节需要对基础版、标准版、旗舰版三个版本的用户体验打分的表现进行分析，并提炼用户关注度最高的正向体验亮点与痛点，其中旗舰版的平均评分最高，标准版的平均评分第二高，基础版的平均评分最低",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/产品上市报告.docx</file> 的‘市场销售趋势分析’章节必须分析4周销售走势，对基础版、标准版、旗舰版的销售表现进行对比，并识别增长点和风险信号",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/产品上市报告.docx</file> 的‘退换货问题诊断’章节必须分析退货率和主要退货原因，识别质量短板，并针对至少一个主要退货原因提出具体的改善方向",
    "weight": 1
  },
  {
    "id": "09",
    "content": "<file>/meituan/mm-Marketing-012/input/answer/产品上市报告.docx</file>的‘上市策略建议’章节必须从定价策略、重点推广版本、问题改善优先级、渠道策略四个维度分别提出具体可落地的建议，四个维度缺一不可",
    "weight": 1
  }
]
```
