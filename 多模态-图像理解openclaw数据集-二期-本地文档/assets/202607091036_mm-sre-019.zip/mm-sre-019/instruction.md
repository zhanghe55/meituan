# SRE 看板探查任务

你负责运维一套**电商网站的微服务系统**(在线商店:商品浏览、购物车、结账、推荐、广告、支付等服务)。系统已接入完整可观测性,所有遥测汇聚到一个 **Grafana**,包含三类信号:

- **Metrics**(Prometheus 数据源):RED 指标(请求率 / 错误率 / 延迟)、资源指标(CPU / 内存 / GC 等)
- **Traces**(Jaeger 数据源):分布式调用链
- **Logs**(OpenSearch 数据源):各服务应用日志

**访问地址(时间范围已固定到故障发生的窗口,直接打开即可):**

```
http://10.177.198.13:8410/t1/d/W2gX2zHVk/demo-dashboard
```

> 说明:这是一份**回放快照**——数据冻结在故障发生的那段时间,不会更新。仪表盘默认时间窗已对准该窗口,直接用浏览器打开上面的地址即可查看。

> **故障数据时间窗(仪表盘已默认对准此窗口):**
>
> - 起:2026-07-02 16:10:25 CST(1782979825276 ms)
> - 止:2026-07-02 16:24:36 CST(1782980676884 ms)
>
> 若你在 Explore 或面板里自行调整时间范围/查询,请把时间钉在这个窗口内,否则查不到数据(回放数据冻结在过去)。

> **看板用法**:这块 Demo Dashboard 顶部有一个 **`service` 下拉变量**,用来切换当前查看的服务;下方的「Requests Rate / Error Rate / Average Duration by Span Name」等面板会随所选服务刷新。**请学会切换这个变量**,逐个服务观察它们的错误率面板。

> **查询方式**:除仪表盘外,也可使用 Grafana 顶部的 **Explore** 页面,在浏览器里选择 Prometheus / Jaeger / OpenSearch 数据源交互式地查询三类信号(输入 PromQL、检索 trace、检索日志)。请优先用**浏览器界面**(仪表盘面板 + Explore),而不是直接调用后端 API。agent-browser 使用说明详见 `~/.agents/skills/agent-browser/SKILL.md`。

---

## 提问

1. 查看service denpendency，checkout的直接上游是什么？
2. cart有几个直接上游节点？分别是什么？
3. Home->Dashboards->Demo下共有几个dashboard？

---

## 文件输出要求

如需截图,请保存到 `/app/input/screenshots/` 目录下。

将答案写入 `/app/input/answers.json`,格式如下:

```json
{
  "问题1": "你的答案",
  "问题2": "你的答案",
  "问题3": "你的答案"
}
```
