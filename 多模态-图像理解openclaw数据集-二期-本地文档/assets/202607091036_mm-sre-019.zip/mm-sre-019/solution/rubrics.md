# Rubrics

> **每个 rubric 独立评分,rubric 权重合计 3 分。**
> **模型回复需与参考答案的数值完全一致**

## 文件读取路径
```path
/meituan/mm-sre-019/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "checkout节点的上游是frontend-proxy",
    "weight": 1
  },
  {
    "id": "BC-2",
    "content": "cart有2个上游节点，分别是frontend和checkout",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "Home->Dashboards->Demo下共有8个dashboard",
    "weight": 1
  }
]
```
