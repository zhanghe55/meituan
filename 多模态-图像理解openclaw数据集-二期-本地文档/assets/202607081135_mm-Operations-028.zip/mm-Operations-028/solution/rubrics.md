# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中需要包含竞品调研、本品产品优惠方案两部分内容",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>'竞品调研'部分的内容有且仅有'立白洗洁精'和'苏泊尔汤勺'两个产品的调研结果",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中'立白洗洁精'的活动平台应为'淘宝'，活动价格应为'19.9/2瓶 共3kg'、满减优惠应为'跨店满300减50'，以上不要求一模一样，但必须包含引号中意思一致的内容",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中'苏泊尔汤勺'的活动平台应为'京东'，活动价格应为'24.9/把'、满减优惠应为'跨店满150减20，满2件打8折'，以上不要求一模一样，但必须包含引号中意思一致的内容",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中本品优惠方案中'01号产品'参与的活动名称应为'抖音618好物节主会场'，活动平台应为'抖音'，需一模一样，且参与的活动及平台有且仅有上述内容",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中本品优惠方案中'02号产品'参与的活动名称应为'618超级单品日'，活动平台应为'淘宝'，需一模一样，且参与的活动及平台有且仅有上述内容",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中本品优惠方案中'01号产品'活动价格不得低于'25.415元/瓶'，且方案中需要包含满减套餐",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Operations-028/input/answer/618大促活动价格方案.pdf</file>中本品优惠方案中'02号产品'的活动价格不得低于'18.308元/把'，且方案中需要包含满减套餐",
    "weight": 1
  }
]
```
