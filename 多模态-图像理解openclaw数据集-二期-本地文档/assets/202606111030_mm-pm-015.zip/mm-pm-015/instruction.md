你是一名经验丰富的产品经理，正在负责一款 C 端记账 APP 的 PRD 评审修订工作。初版 PRD 和 SVG 原型图已完成，现已收到来自领导和客户两方的评审意见。

请你读取我提供的 docx 文件，依据 docx 中涉及的实际需要，依次读取输入文件，按照评审意见及流程处理规范文档的要求，同步产出评审意见表与需求宣讲材料，并输出最终版本的PRD文件。

输入文件在：
```
/meituan/mm-pm-015/input/群聊评审意见汇总.docx
/meituan/mm-pm-015/input/记账APP_PRD_V1.0.md
/meituan/mm-pm-015/input/支出记账页原型图.svg
/meituan/mm-pm-015/input/收入记账页原型图.svg
/meituan/mm-pm-015/input/统计页原型图.svg
/meituan/mm-pm-015/input/评审意见及流程处理规范.docx
```

输出要求：请综合分析以上所有输入文件
1. 依据给定的‘群聊评审意见汇总.docx’，参考三张原型图文件：‘收入记账页原型图.svg’、‘支出记账页原型图.svg’和‘统计页原型图.svg’的相关内容，严格遵循‘评审意见及流程处理规范.docx’中规定的要求输出一份符合需求‘评审意见表.xlsx’的文件，
2. 结合‘记账APP_PRD_V1.0.md’中的内容并严格依据‘评审意见及流程处理规范.docx’中的相关要求，产出最终版的‘记账APP_PRD_V2.0.md’，并输出一份‘需求宣讲材料.docx’的文件。

输出到这里：
```
/meituan/mm-pm-015/input/answer/评审意见表.xlsx
/meituan/mm-pm-015/input/answer/记账APP_PRD_V2.0.md
/meituan/mm-pm-015/input/answer/需求宣讲材料.docx
```

请直接执行命令，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。