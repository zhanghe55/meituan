# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-hr-022/input/answer/2025Q2任职资格认证总表.xlsx
/meituan/mm-hr-022/solution/参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-hr-022/input/answer/2025Q2任职资格认证总表.xlsx</file> 中A、B、C、D、F、G列的内容与 <file>/meituan/mm-hr-022/solution/参考答案.xlsx</file> 中A、B、C、D、F、G列的顺序、文本及数值内容完全一致。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-hr-022/input/answer/2025Q2任职资格认证总表.xlsx</file> 中E列的内容与 <file>/meituan/mm-hr-022/solution/参考答案.xlsx</file> 中E列的内容完全一致，E2-E6单元格格式为数值，保留两位小数。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-hr-022/input/answer/2025Q2任职资格认证总表.xlsx</file> 中H列的内容与 <file>/meituan/mm-hr-022/solution/参考答案.xlsx</file> 中H列的内容需要语义相似。李晓雯的备注需要提及与评委存在直接利益关系或直属上下级关系；王浩然的备注需要体现分数处于临界区间；陈美琳的备注需要体现未持有相应证书、HR序列工作年限不满足、近两年绩效不满足；张伟东的备注需要体现本公司HR序列工作年限不满、现任HR-P2任职周期不满、未持有相应证书；刘思远的备注需要体现证书信息不一致以及分数处于临界区间。如以上内容有遗漏未提及，则不通过",
    "weight": 1
  }
]
```
