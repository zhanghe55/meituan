# Bug Injection Summary — figma-D3-L23-1

## b009 (L2 / D3)
- **位置**: `js/app.js:_handleCanvasClick()` — `case 'rectangle'`
- **描述**: `_handleCanvasClick()` 中矩形工具的 case 将 `shapeType` 误写为 `'circle'`，导致用户点击工具栏矩形工具后在画布上点击，出现的是圆形而非矩形；工具栏高亮矩形图标与画布实际出现圆形同屏矛盾可见。
- **预期行为**: 点击矩形工具后在画布添加元素，应出现矩形（`shapeType: 'rectangle'`），属性面板 Shape Type 显示 Rectangle。

## b010 (L3 / D3)
- **位置**: `js/state.js:deleteSlide()` + `js/views.js:renderPresenter()`
- **描述**: `deleteSlide()` 删除幻灯片后不更新 `pres.slideCount`（计数冻结在旧值），同时 `renderPresenter()` 进度指示器读取 `pres.slideCount` 而非实时的 `slides.length`；删除幻灯片后进入 Presenter Mode，进度总数显示旧值，与编辑器 Filmstrip 刚展示的数量产生跨模块矛盾。
- **预期行为**: 删除幻灯片后进入 Presenter Mode，进度指示器应显示更新后的正确总数（如删除 2 张后显示 `1 / 13` 而非 `1 / 15`）。

