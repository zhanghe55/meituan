# -*- coding: utf-8 -*-
"""课程详情页业务逻辑（被测实现 / System Under Test）。

测试工程师须依据「原型图 + 多状态对比图 + PRD」推导各场景的期望行为，
对本模块编写自动化测试（test_course_page.py）并实际运行通过。

数据结构（纯 dict，测试中自行构造 fixture）：
  course = {
    "id": str,
    "title": str,
    "price": int,                 # 现价/售价
    "original_price": int | None, # 原价（划线价）；None 表示无划线原价
    "discount_label": str | None, # 折扣标签，如 "限时5折"；None 表示无折扣
    "is_free": bool,
    "status": "on_sale" | "off_shelf",
    "stock": int | None,          # None=不限量；整数=库存；0=售罄
    "chapters": [ {"title": str, "trial": bool}, ... ],
  }
  user = {"logged_in": bool, "purchased_ids": [course_id, ...], "favorite_ids": [course_id, ...]}
"""


def get_price_display(course):
    """返回价格区展示。免费→{type:free}; 有原价+折扣标签→{type:discount, price, original_price, discount_label}; 否则→{type:original, price}。"""
    if course.get("is_free"):
        return {"type": "free", "display": "免费", "price": 0}
    if course.get("original_price") and course.get("discount_label"):
        return {
            "type": "discount",
            "price": course["price"],
            "original_price": course["original_price"],
            "discount_label": course["discount_label"],
        }
    return {"type": "original", "price": course["price"]}


def get_purchase_button(course, user):
    """返回底部购买按钮 {text, enabled}。下架/售罄置灰不可点；免费→立即学习；已购买→去学习；否则→立即购买。"""
    if course.get("status") == "off_shelf":
        return {"text": "立即购买", "enabled": False}
    if course.get("stock") == 0:
        return {"text": "已售罄", "enabled": False}
    if course.get("is_free"):
        return {"text": "立即学习", "enabled": True}
    if user.get("logged_in") and course["id"] in user.get("purchased_ids", []):
        return {"text": "去学习", "enabled": True}
    return {"text": "立即购买", "enabled": True}


def click_purchase(course, user):
    """点击购买后的跳转动作：
    'blocked:off_shelf' / 'blocked:sold_out' / 'goto_login'(未登录) / 'goto_study'(免费或已购) / 'goto_pay'。"""
    if course.get("status") == "off_shelf":
        return "blocked:off_shelf"
    if course.get("stock") == 0:
        return "blocked:sold_out"
    if not user.get("logged_in"):
        return "goto_login"
    if course.get("is_free") or course["id"] in user.get("purchased_ids", []):
        return "goto_study"
    return "goto_pay"


def get_catalog(course, expanded=False):
    """目录展示。收起→仅前3章 + {expand_entry: '展开全部 N 章'}; 展开→全部 + {expand_entry: '收起'}。"""
    chapters = course.get("chapters", [])
    total = len(chapters)
    if expanded:
        return {"visible": chapters, "total": total, "expand_entry": "收起"}
    return {"visible": chapters[:3], "total": total, "expand_entry": "展开全部 %d 章" % total}


def can_play_chapter(course, user, index):
    """是否可播放某章：可试看章节任何人可播放；非试看章节需已登录且已购买。"""
    chapter = course["chapters"][index]
    if chapter.get("trial"):
        return True
    return bool(user.get("logged_in")) and course["id"] in user.get("purchased_ids", [])


def click_favorite(user, course):
    """点击收藏：未登录→'goto_login'；已收藏→取消返回'removed'；未收藏→收藏返回'added'。"""
    if not user.get("logged_in"):
        return "goto_login"
    fav = user.setdefault("favorite_ids", [])
    if course["id"] in fav:
        fav.remove(course["id"])
        return "removed"
    fav.append(course["id"])
    return "added"


def get_page_notice(course):
    """页面顶部提示：下架→'该课程已下架'；否则 None。"""
    if course.get("status") == "off_shelf":
        return "该课程已下架"
    return None
