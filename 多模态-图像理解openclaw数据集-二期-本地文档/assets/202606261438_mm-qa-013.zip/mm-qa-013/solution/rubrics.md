# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-qa-013/input/answer/test_cases.json
/meituan/mm-qa-013/input/answer/test_course_page.py
```

```json
[
  {
    "id": "01",
    "content": "产物齐全且格式正确：<file>/meituan/mm-qa-013/input/answer/test_cases.json</file> 与 <file>/meituan/mm-qa-013/input/answer/test_course_page.py</file> 均存在且内容不为空；其中 test_cases.json 须可解析为合法 JSON 且顶层为数组（list）、用例条数在 10～15 条之间；任一文件缺失/为空，或 test_cases.json 无法解析/非数组/用例条数少于 10 条或超过 15 条，则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "02",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file>，每条用例须含 id、scenario、title、priority、precondition、steps、expected_result、related_ui 全部字段，且 precondition、steps、expected_result 三个核心字段不得为空；scenario 取值须为 购买流程/价格展示/课程目录/收藏功能/异常场景 之一，priority 取值须为 P0/P1/P2 之一；存在用例缺字段、核心字段为空、或 scenario/priority 取值非法，则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "03",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file>，用例须覆盖全部 5 大场景（场景清单与取值见 rub 02），每个场景至少 1 条用例；任一场景未覆盖则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "04",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file>，P0/P1/P2 须按以下标准分配：P0 = 核心主流程与阻断性场景，仅限：已登录用户正常下单购买、课程下架导致不可购买、库存为 0 售罄导致不可购买；P1 = 重要分支，包括：未登录点击购买跳转登录、折扣价三要素展示、免费课程价格与按钮状态、已购买进入学习（按钮「去学习」）、目录展开收起、试看与锁定章节播放差异、收藏与取消收藏（含未登录跳登录）；P2 = 次要/提示类（如加载失败提示等）；若全部用例同一优先级、或 P0 场景（下单购买主流程、下架/售罄不可购买）未标 P0、或将 P2 级别场景标为 P0，则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "05",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file> 的 related_ui 与用例内容：1. related_ui 须引用真实存在的页面模块/元素（如价格区、课程目录、收藏按钮、立即购买按钮、讲师信息、可试看标签等），不得普遍为空或填写无意义占位；2. 至少 3 条用例的 expected_result 体现正常态视觉数值（折扣价 ¥199、划线原价 ¥399、「限时5折」、目录收起 3 章、「展开全部 12 章」、第 1 章「可试看」等）；3. 至少 2 条用例的 expected_result 体现异常/状态变化（「该课程已下架」、「已售罄」、「去学习」、「免费」/「立即学习」等）；若 related_ui 普遍缺失、未出现上述视觉数值、或异常状态用例的 expected_result 无具体可判定内容，则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "06",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file>，须同时满足：1. 每条用例的 steps 为具体操作描述（如「点击立即购买按钮」），不得为空、「待补充」等占位文本；2. 每条用例的 expected_result 为具体可判定的结果（如「跳转至登录页」「按钮文案显示已售罄且不可点击」），不得使用「验证功能正常」「测试是否正确」等无法判定的空泛表述；3. 不得出现 3 条及以上用例的 steps 或 expected_result 内容完全相同（即雷同堆砌凑数）；任一项不满足则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "07",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_course_page.py</file> 的文本内容，须同时满足：1. 该文件中出现 import course_page（真实导入被测实现）；2. 该文件中出现对 course_page 函数的调用（如 get_price_display、get_purchase_button、click_purchase、get_catalog、can_play_chapter、click_favorite、get_page_notice 中至少 4 个）；3. 该文件中存在至少 5 个独立测试函数或测试方法定义（def test_）；4. 该文件中存在真实断言（如 assertEqual、assert、assertFalse、assertTrue 等），且不得全为 assert True 或空函数体；任一项不满足则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "08",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_course_page.py</file> 的文本内容，须覆盖以下关键场景（共 7 项，须全部命中）：1. 折扣价：文件中出现 get_price_display 调用且断言中含折扣价、划线原价、折扣标签相关关键词（如 discount、original_price、label 等）；2. 课程下架：文件中出现 get_purchase_button 调用且断言 enabled 为 False，并出现 get_page_notice 调用且断言含「该课程已下架」；3. 库存为 0：文件中出现按钮文案「已售罄」的断言且断言 enabled 为 False；4. 已购买或免费：文件中出现按钮文案「去学习」或「立即学习」的断言；5. 目录：文件中出现 get_catalog 调用且断言收起时可见 3 章、展开入口含「展开全部 12 章」、展开后为 12 章；6. 试看与锁定章节：文件中出现 can_play_chapter 调用且有可播放为 True、不可播放为 False 的对比断言；7. 未登录购买或收藏：文件中出现 goto_login 相关断言；任一项缺失则判定为 FAIL；",
    "weight": 1
  },
  {
    "id": "09",
    "content": "检查 <file>/meituan/mm-qa-013/input/answer/test_cases.json</file> 与 <file>/meituan/mm-qa-013/input/answer/test_course_page.py</file>，二者须相互对应——test_cases.json 设计的关键场景（购买/价格/目录/收藏/异常）在 test_course_page.py 中有对应的自动化断言落实；若设计与自动化彼此脱节（如设计了下架/折扣等关键用例但自动化完全未覆盖），或自动化只测无关紧要点而回避设计的关键场景，则判定为 FAIL；",
    "weight": 1
  }
]
```
