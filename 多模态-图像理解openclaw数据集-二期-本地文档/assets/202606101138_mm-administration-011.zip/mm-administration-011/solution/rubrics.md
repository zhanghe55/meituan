# Rubrics


> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-011/input/answer/来访信息确认表.csv
/meituan/mm-administration-011/solution/参考答案_来访信息确认表.csv
/meituan/mm-administration-011/input/answer/接待执行方案.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-administration-011/input/answer/来访信息确认表.csv</file> 中包含：'序号'、'日期'、'来访人姓名'、'职位'、'来访时间'、'来访事由'、'食物过敏源'，列名称与此处完全一致，不得增加、删减或修改列名",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-administration-011/input/answer/来访信息确认表.csv</file> 的A-F列这6列的内容与 <file>/meituan/mm-administration-011/solution/参考答案_来访信息确认表.csv</file> 的A-F列这6列的内容完全一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-administration-011/input/answer/来访信息确认表.csv</file> 需写明Zahid Khan的食物过敏源需要填写'坚果类'或'坚果'，其他2位的食物过敏源为'无'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-administration-011/input/answer/接待执行方案.docx</file> 中明确写出接待时间为 '2026年6月9日' 且时间段为 '15:00—18:00'（或等价表述 15:00至18:00）",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-administration-011/input/answer/接待执行方案.docx</file>中明确写出参会总人数给出具体的外宾人数3人、我司接待人数5人、翻译人数1人，以及参会总人数9人",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-administration-011/input/answer/接待执行方案.docx</file> 中明确写出会场椅子配置数量为14把",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-administration-011/input/answer/接待执行方案.docx</file> 中明确写出选定酒店为 '上海锦江都城酒店'，选择理由：上海瑞吉酒店虽然最近，但因为1200的价格不含早，含早后会超过1200的标准，所以不符合要求；'上海锦江都城酒店'次近，价格、星级等均符合要求。选择理由语义相近即可，不要求表述一致。",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-administration-011/input/answer/接待执行方案.docx</file> 中明确写出预订房间数为 3 间，入住日期为6月9日，退房日期为6月10日",
    "weight": 1
  }
]
```
