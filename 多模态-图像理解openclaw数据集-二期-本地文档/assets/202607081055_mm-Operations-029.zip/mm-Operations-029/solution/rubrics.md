# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-029/input/answer/断码劳保鞋推广计划表.xlsx
/meituan/mm-Operations-029/solution/参考答案-断码劳保鞋推广计划表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-029/input/answer/断码劳保鞋推广计划表.xlsx</file>与<file>/meituan/mm-Operations-029/solution/参考答案-断码劳保鞋推广计划表.xlsx</file>中的表头、A-C列、F列、H-J列的文本与数值内容以及行列顺序完全相同",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-029/input/answer/断码劳保鞋推广计划表.xlsx</file>与<file>/meituan/mm-Operations-029/solution/参考答案-断码劳保鞋推广计划表.xlsx</file>中的D列筛选标准的具体条数、淘汰情形编号和数量必须相同（如：第1-8条、淘汰情形A/D），后面有无其他补充说明具体内容都不算错误",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-029/input/answer/断码劳保鞋推广计划表.xlsx</file>与<file>/meituan/mm-Operations-029/solution/参考答案-断码劳保鞋推广计划表.xlsx</file>中的E列的颜色、鞋型高低必须一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-029/input/answer/断码劳保鞋推广计划表.xlsx</file>中只有实拍图片2和实拍图片3的G列有文字内容，其他实拍图片对应的G列内容为‘—’；实拍图片2的G列内容中包含‘消防防护靴’‘原价329元’‘清仓价165元’‘尺码38/43/44’这些字眼，除此之外还需列出E列中填写的1个其他特征；实拍图片3的G列内容中包含‘钢包头防砸安全鞋’‘原价299元’‘清仓价150元’‘尺码38/40/43/44’这些字眼，除此之外还需列出E列中填写的1个其他特征",
    "weight": 1
  }
]
```
