# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-014/input/answer/海报设计需求单.xlsx
/meituan/mm-Marketing-014/input/answer/主视觉创意定稿方向.xlsx
/meituan/mm-Marketing-014/input/answer/多尺寸排版指南.docx
/meituan/mm-Marketing-014/solution/参考答案_海报设计需求单.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-014/input/answer/海报设计需求单.xlsx</file> 中 Sheet「海报尺寸需求清单」的所有数据值需与 <file>/meituan/mm-Marketing-014/solution/参考答案_海报设计需求单.xlsx</file> 中 Sheet「海报尺寸需求清单」的所有数据值保持一致，顺序不做要求，但只能有8行数据（不含表头）；其中'推荐尺寸规格'字段须使用'宽×高px'格式（如1080×1920px），'比例'字段须使用'宽:高'格式（如9:16），'方向'字段须填写'竖版'/'横版'/'方形'，'色彩模式'字段须填写'RGB'或'CMYK'",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-014/input/answer/海报设计需求单.xlsx</file> 中 Sheet「核心要素提炼」的所有数据值需与 <file>/meituan/mm-Marketing-014/solution/参考答案_海报设计需求单.xlsx</file> 中 Sheet「核心要素提炼」的所有数据值保持一致，顺序不做要求，但只能有9行数据（不含表头），仅保留优先级为P0和P1的数据；其中'嘉宾姓名'对应的具体内容，不同人名需用'/'分隔，人名的顺序不作要求",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-014/input/answer/主视觉创意定稿方向.xlsx</file> 中 ，第一行表头依次为'整体色彩倾向'、'排版构图风格'、'字体层级'、'整体风格定位'，其中'整体色彩倾向'对应的值为'#0A2A6E'；'排版构图风格'需提及三段式构图；'字体层级'为'4'；'整体风格定位'需提及科技感或商务感或未来感，含义相近即可",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-014/input/answer/多尺寸排版指南.docx</file> 应包含'总体原则'、'各版本视觉重心速查表'、'各元素统一缩放参考规则'、'品牌规范合规自检清单'四个层级，且'各版本视觉重心速查表'中包含'9:16竖版'、'16:9横版'、'1:1方形'、'32:10横版'四种版本的排版指引；若列出了具体尺寸，需遵守以下规则，若出现规则以外的尺寸与版本对应关系则为不通过：'9:16竖版'只有1080×1920px，'16:9横版'只有900×383px，'1:1方形'只有200×200px或1080×1080px，'32:10横版'只有1920×600px；'各元素统一缩放参考规则'中包含至少4种元素（比如：Slogan字号/Logo尺寸/图形/二维码），并给出了各版本的缩放比例；'品牌规范合规自检清单中包含'色彩/字体/Logo/信息完整性'4个类别，每类别至少2-3条具体检查项",
    "weight": 1
  }
]
```
