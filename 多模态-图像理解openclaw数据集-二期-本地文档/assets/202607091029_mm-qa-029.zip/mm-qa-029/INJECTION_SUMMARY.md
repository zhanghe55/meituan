# Bug Injection Summary — figma-D1-L3-2

## b004 (L3 / D1)
- **位置**: `js/views.js:renderPresenter()`
- **描述**: renderPresenter() 在渲染演讲备注时使用 slides[0].speakerNotes 替代 currentSlide.speakerNotes，导致演示模式下无论当前在第几张幻灯片，备注面板始终显示第 1 张幻灯片的备注内容。
- **预期行为**: 在演示模式中，备注面板应随幻灯片切换显示对应幻灯片的 speakerNotes 内容。

