# Bug Injection Summary — bigmail-D2-L2-2

## b003 (L2 / D2)
- **位置**: `js/state.js:toggleStar()`
- **描述**: `toggleStar()` 开头新增 `if (email.isRead) return;`，已读邮件（`isRead=true`）触发星标操作时直接静默返回，星标既无法添加也无法取消；未读邮件不受影响。收件箱中绝大多数邮件在打开后即变为已读，因此实际上几乎所有邮件都无法收藏。
- **预期行为**: 对任意邮件点击星标图标，应正常切换 `isStarred` 状态，与邮件是否已读无关。
