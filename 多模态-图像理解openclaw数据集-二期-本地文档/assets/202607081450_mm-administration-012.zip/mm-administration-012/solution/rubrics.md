# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明'邀请外国人来华手续申请表.pdf'文档中，拟停留日期错误，应该为39天；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明'担保函.pdf'文档中，离境日期错误，应于2026年8月7日及之前离境；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明Zahid Khan的护照，不满足有效期须在半年以上的要求；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明'派遣函.pdf'中缺少公司盖章；意思表达一致即可",
    "weight": 1
  }, 
  {
    "id": "05",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明'项目合同01.pdf'中缺少乙方公司授权代表签字及盖章；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明Asma Bibi的护照人像部分不够清晰；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中需要说明缺少中外方直接业务往来的其他材料；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中，不能提及需要提供申办单位的营业执照、法定代表人身份证件、电子缴款凭证；意思表达一致即可",
    "weight": 1
  },
  {
    "id": "09",
    "content": "<file>/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md</file>中，需要针对列出的每一条问题，提出具体的修改建议",
    "weight": 1
  }
]
```