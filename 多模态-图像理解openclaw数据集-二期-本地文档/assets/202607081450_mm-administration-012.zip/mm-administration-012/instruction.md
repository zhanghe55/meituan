我是上海市一家公司的行政专员，现我司因有巴基斯坦的合作方因公务需要访华，我司需要准备相关材料，申办'外国人来华邀请核实单'，以支持合作方人员在我国停留大于30天，我司已注册过申请该材料的网站账号（历史曾申办过），上传的我司材料没有需要更新的部分，且来访人员均从其国籍国出发，来访人员均为第一次来华。

请根据我输入的文件：

```
/meituan/mm-administration-012/input/护照1.png
/meituan/mm-administration-012/input/护照2.png
/meituan/mm-administration-012/input/护照3.png
/meituan/mm-administration-012/input/担保函.pdf
/meituan/mm-administration-012/input/派遣函.pdf
/meituan/mm-administration-012/input/项目合同01.pdf
/meituan/mm-administration-012/input/邀请函.pdf
/meituan/mm-administration-012/input/邀请外国人来华手续申请表.pdf
```
按照我市政府官方要求的申请邀请核实单的所需材料要求（截至2026年6月10日），帮我审核一下我输入的文件是否完全符合要求。我准备6月10日正式提交申请。
1、若完全符合要求，则直接文字回复“输入所有材料均符合要求，且无缺少材料”，不需要输出任何文件；
2、若不符合要求，仅需要输出一份审核不通过说明文档至：
```
/meituan/mm-administration-012/input/answer/外国人来华申请文档审核不通过说明.md
```
  该文档须包含：
   1、审核结论（不通过）
   2、具体不通过原因：列明所有不符合要求的材料名称及具体问题，涵盖缺失材料清单和已提交材料的问题
      如"XX文件未盖章"、"XX文件的XX日期不符合要求"、缺失"XX文件"等
   3、文件修改建议：对每个不符合的文件提出修改建议
 
请注意，输入文件中敏感信息使用XXXX替代的（如手机号中间4位数），只是因为隐私等敏感信息不能上传，不属于错误信息。

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。