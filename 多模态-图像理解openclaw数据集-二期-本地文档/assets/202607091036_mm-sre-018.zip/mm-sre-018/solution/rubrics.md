# Rubrics

> **rubric 权重合计 6 分,每条独立评分、互不重叠。**
>
> **门槛规则:BC-1 是门槛项(2 分)。BC-1 未通过则本卷判 0 分,BC-2~BC-5 一律不计分。** BC-1 通过后,BC-2~BC-5 各自独立判分。
>
> **数值口径:** lag 峰值按 Grafana Explore 默认(原生 ~10s 分辨率)读取,fraud-detection 组窗口内峰值约 **1.4 万~1.5 万**;评分**按数量级判定**(基线个位数 → 峰值上万级),不钉死单一数字。

## 文件读取路径
```path
/meituan/mm-sre-018/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【门槛项】<file>/meituan/mm-sre-018/input/answers.json</file> 须同时满足两个条件,任一不满足则 BC-1 得 0 分且 BC-2~BC-5 均不计分:(1) 故障环节 failed_service 定位到 Kafka `orders` 消息队列积压环节——即 checkout 生产端 与/或 fraud-detection(及 accounting)消费端(答『kafka orders 队列 / checkout 生产端 / fraud-detection 消费端 / 生产消费两端』中任一或组合均可,因同一 flag 双侧驱动;但不可答成常驻噪声 product-reviews / frontend);(2) fault_type 判断为消息队列积压型 / 吞吐失衡(下单不失败、消息最终被消费、只是滞后堆积),而非错误型、非单纯某服务变慢、非资源耗尽。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "【入口思路,仅 BC-1 通过时计分】evidence 体现正确的入口判断:错误率维度为空 ≠ 无故障——下单错误率无变化,须转向 **Kafka 消费组 lag(队列健康)指标**作为入口;并能把本故障与 product-reviews / frontend 的常驻高错误率背景噪声区分开(明确指出后者与本故障无关)。只要体现『错误率看不到故障、须看队列 lag』或『product-reviews/frontend 是背景噪声』即可得分。本项只考入口逻辑,不要求给出具体数值(数值在 BC-5 判)。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "【生产端归因,仅 BC-1 通过时计分】root_cause 明确指认**生产端过载**:kafkaQueueProblems flag 置 on 使 checkout 每笔订单额外向 orders 队列灌入约 100 条重复消息(spawn ~100 goroutine),放大写入速率。可由 checkout 日志签名 `overloading queue now` / `overload simulation`(实测 ×148)佐证。体现『checkout 生产端过载 / 灌入放大』即得分。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "【消费端归因,仅 BC-1 通过时计分】root_cause 明确指认**消费端变慢**:fraud-detection 每消费一条订单消息 `Thread.sleep(1000)`,消费速率压到近 0。可由消费端证据佐证——`process orders` span P95 从 ~2ms 涨到 ~1.4s 且 span 无 error(慢而不错)、consumed rate 从 ~0.7 掉到 0,或 fraud-detection 日志 `sleeping 1 second`(实测 ×239)。体现『fraud-detection 消费端被人为拖慢 / sleep』即得分。",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "【量化峰值,仅 BC-1 通过时计分】evidence 指认关键信号并读出其窗口内峰值量级(带真实指标名):核心是 Kafka 消费组积压 **`kafka_consumer_group_lag_sum_ratio`**(须认准该实际指标名,而非本环境不存在的 `kafka_consumer_group_lag`),读数从个位数基线(~4)爆炸到**上万级**(fraud-detection 组峰值约 1.4 万~1.5 万,数量级正确即可);或消费端 fraud-detection `process orders` P95 延迟(~2ms → ~1.4s)。须同时包含 (a) 信号指认 到 lag 或消费端延迟,(b) 峰值量级读数(基线 → 峰值)。缺信号指认或缺峰值量级读数均不得分。",
    "weight": 1
  }
]
```
