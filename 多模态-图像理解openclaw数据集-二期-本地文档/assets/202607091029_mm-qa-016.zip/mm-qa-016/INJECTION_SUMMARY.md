# Bug Injection Summary — bigmail-D1-L1-1

## b001 (L1 / D1)
- **位置**: `js/components.js:labelBadge()`
- **描述**: `colorSwap` 映射表中 Work（label_1）与 Personal（label_2）的 id 写反，导致邮件列表中 Work badge 显示 Personal 的绿色、Personal badge 显示 Work 的蓝色；侧边栏圆点直接读取 `label.color.background`，不受影响，颜色正确。左右同屏两处颜色错位，一眼可见。
- **预期行为**: Work badge 应与侧边栏 Work 圆点颜色一致（蓝色），Personal badge 与侧边栏 Personal 圆点一致（绿色）。
