# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-016/input/answer/ORD-2026-003_Casa_Bella_S.r.l._order.pdf
/meituan/mm-administration-016/input/answer/factory_order_email.md
/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-001.txt
/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-002.txt
/meituan/mm-administration-016/input/answer/shipping_notice_Muller.md
/meituan/mm-administration-016/input/answer/shipping_notice_Nordic.md
/meituan/mm-administration-016/input/answer/order_summary_updated.csv
/meituan/mm-administration-016/solution/参考答案_order_summary_updated.csv
/meituan/mm-administration-016/solution/production_notice_ORD-2026-001.txt
/meituan/mm-administration-016/solution/production_notice_ORD-2026-002.txt
/meituan/mm-administration-016/input/dealer_order_CasaBella.jpg
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-administration-016/input/answer/ORD-2026-003_Casa_Bella_S.r.l._order.pdf</file> 为 Casa Bella S.r.l. 的工厂订单 PDF，且满足以下所有条件：(1) 订单号为 'ORD-2026-003'；(2) 下单日期为 '2026/5/22'；(3) 经销商名称为 'Casa Bella S.r.l.'，国家为 'Italy'；(4) 产品编号为 'WRB-2000-SET'，产品描述为 'Wardrobe Set 2000mm'；(5) 尺寸为 '2000*2600*600mm'；(6) Front Color 为 'Warm Oak'，颜色代码为 'F-208'；(7) Body Color 为 'Light Grey'，颜色代码为 'B-202'；(8) Qty为 '40'，也可以是'40 sets'；(9) PRODUCT DRAWING区域的图纸和<file>/meituan/mm-administration-016/input/dealer_order_CasaBella.jpg</file>的Technical DRAWING对应的图纸是一样；(10)文件命名正确且为pdf格式",
    "weight": 2
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-administration-016/input/answer/factory_order_email.md</file> 为发送给工厂的英文下定邮件，且满足以下所有条件：(1) 收件人邮箱为 'orders@kitchenpro-factory.de'；(2) 包含发件人邮箱'procurement@kitchenpro-factory.de'；(3) 邮件主题（Subject）为 'Purchase Order Submission – ORD-2026-003'；(4) 正文包含 ORD-2026-003 订单的信息: 经销商名称 'Casa Bella S.r.l.'、订单编号 'ORD-2026-003'、产品名称 'Wardrobe Set 2000mm'、数量 '40'；(5) 正文注明附件文件名为 'ORD-2026-003_Casa_Bella_S.r.l._order.pdf'；(6) 语言为英文",
    "weight": 2
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-001.txt</file> 与<file>/meituan/mm-administration-016/solution/production_notice_ORD-2026-001.txt</file>的内容一致。",
    "weight": 2
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-002.txt</file> 与<file>/meituan/mm-administration-016/solution/production_notice_ORD-2026-002.txt</file>的内容一致。",
    "weight": 2
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-administration-016/input/answer/shipping_notice_Muller.md</file> 收件人为 'hans.mueller@muller-gmbh.de'，发件人为 'procurement@kitchenpro-factory.de'，邮件主题格式为 'Shipment Notice – ORD-2026-001 (Muller GmbH) – 2026-06-23'；正文包含订单编号 'ORD-2026-001'、产品名称'Walk-in Wardrobe Set 4391mm'、数量 '85 sets'、颜色规格，发货体积 '45.6 m³'、毛重 '8,500 kg'，集装箱数量 '2'，发货时间 '2026-06-23' ，尾款金额 'EUR 50,575.00'、支付截止日期 '2026-06-09'，拼箱说明必须提到 '有1个拼箱，拼箱预计发货时间为2026-06-24'。",
    "weight": 2
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-administration-016/input/answer/shipping_notice_Nordic.md</file> 收件人为 'order@nordichome.se'，发件人为 'procurement@kitchenpro-factory.de'，邮件主题格式为 'Shipment Notice – ORD-2026-002 (Nordic Home AB) – 2026-06-24'；正文包含订单编号 'ORD-2026-002'、产品名称'Dining Chair 850mm'、数量 '200 sets'、颜色规格，发货体积 '38.4 m³'、毛重 '3,200 kg'，集装箱数量 '2'，发货时间 '2026-06-24' 、尾款金额 'EUR 22,400.00'、支付截止日期 '2026-06-10'，拼箱说明必须提到 '有1个拼箱，拼箱预计发货时间为2026-06-24'。",
    "weight": 2
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-administration-016/input/answer/order_summary_updated.csv</file>与 <file>/meituan/mm-administration-016/solution/参考答案_order_summary_updated.csv</file> 的数值/内容完全一致",
    "weight": 2
  }
]
```
