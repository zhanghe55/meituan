你是 KitchenPro Factory GmbH 的行政采购专员。你已处理了 3 家经销商的初始下单方案，其中 Casa Bella 的订单因单位错误（pcs）和日期缺失被暂停，已发送错误确认邮件。今日收到了更正方案及相关跟进文件，请根据以下输入的所有文件：

```
/meituan/mm-administration-016/input/dealer_order_CasaBella.jpg
/meituan/mm-administration-016/input/bank_receipt_Muller.png
/meituan/mm-administration-016/input/bank_receipt_Nordic.png
/meituan/mm-administration-016/input/shipping_rules.txt
/meituan/mm-administration-016/input/production_notice_template.txt
/meituan/mm-administration-016/input/order_summary_base.csv
/meituan/mm-administration-016/input/factory_order_template.pdf
/meituan/mm-administration-016/input/color_reference_table.xlsx
/meituan/mm-administration-016/input/order_confirm_Muller.png
/meituan/mm-administration-016/input/order_confirm_Nordic.png
/meituan/mm-administration-016/input/order_confirm_email_Nordic.png
/meituan/mm-administration-016/input/order_confirm_email_Muller.png
```

按照以下操作规范完成工作。

### 第一步：处理 Casa Bella 更正订单，按 factory_order_template.pdf 为模板，生成更正版 PDF，输出至：
```
/meituan/mm-administration-016/input/answer/ORD-2026-003_Casa_Bella_S.r.l._order.pdf
```
填写注意事项如下：
1、颜色标准代码需对照 color_reference_table.xlsx 填写。
2、所有必填字段（订单号ORD-2026-003、下单日期（格式 YYYY/M/D）、经销商名称（dealer_name/Acquirente）、产品编号、产品描述、尺寸(mm)、颜色代码、数量）须完整填写，缺失或信息有误的字段不得留空或填写错误内容。
3、若某张订单存在字段缺失或信息错误，则该订单不输出工厂订单PDF文件。
4、将订单中的'PRODUCTION DRAWING'区域部分，进行截图，附在对应PDF订单文件的图纸区域中（必填）。
5、直接在提供的模板文件的基础上进行信息填写，不允许修改模板。
6、经销商名称应使用完整名称
7、尺寸的格式为width*height*depth, 单位为mm，从图纸中读取，最后需要带单位进行填写

### 第二步：针对 Casa Bella 更正订单，生成一份发送给工厂的英文下定邮件文件（只需要写出文本并以 MD 形式保存），收件人为工厂订单邮箱，正文须包含已核对的订单信息，并注明附件文件名，输出至：
```
/meituan/mm-administration-016/input/answer/factory_order_email.md
```
邮件须包含以下内容：
- 收件人邮箱（工厂订单邮箱，从 factory_order_template.pdf 页脚中读取）
- 发件人（采购部门邮箱，为'procurement@kitchenpro-factory.de'）
- 邮件主题（Subject）为 Purchase Order Submission – 【本次待下定订单的订单编号(与第一步中的订单号一致)】
- 正文须包含本次待下定订单的下单请求，每份订单单独列出，包含：经销商名称、订单编号、产品名称、数量
- 正文须注明附件为对应的订单 PDF 文件，并列出附件文件名
- 语言使用英文

### 第三步：生成生产通知单

依据 'shipping_rules.txt' 中的排箱规则，对经销商已签字确认且首付款足额到账的订单，按付款到账日期（Transaction Date）升序排列，确定发货优先级。 依据 'production_notice_template.txt' 的规范格式以及字段填入[]中的内容，根据订单编号为上述订单各生成一份生产通知单，输出至：
```
/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-001.txt
/meituan/mm-administration-016/input/answer/production_notice_ORD-2026-002.txt
```
注意：
- 通知单按照整个订单的完整信息进行填写即可
- 输出的通知单文件名中001和002的流水号，与order_summary_base.csv中的订单流水号，属于同一个订单
- 所有[]字段都要填写。模板里[]中的文字是格式说明，（）里的是额外字段说明以及规则，填写完正确的数值之后，请将[]及其内部的说明，（）及其内部的额外说明都删掉，保留正确的数值及其他模板数据即可。
- 模型中没有提到填写格式的字段，按照读取的文件截图信息中的原格式进行填写即可。

### 第四步：生成经销商发货通知邮件

为 Muller GmbH 和 Nordic Home AB 各生成一封发货通知邮件，以 Markdown 文件保存，输出至：
```
/meituan/mm-administration-016/input/answer/shipping_notice_Muller.md
/meituan/mm-administration-016/input/answer/shipping_notice_Nordic.md
```
邮件须包含：
- 收件人邮箱
- 发件人 'procurement@kitchenpro-factory.de'
- 邮件主题格式为：Shipment Notice – {Order No.} ({Dealer Name}) – {Estimated Dispatch Date}，例如：Shipment Notice – ORD-2026-001 (Muller GmbH) – 2026-06-23
- 订单基本信息：订单编号、产品名称、发货数量（sets）、颜色规格
- 货物信息：发货体积（m³）、毛重（kg）、集装箱安排（集装箱总数量，如涉及拼箱，需要列出拼箱的发货时间及拼箱数量）
- 发货时间：每个集装箱的预计发货日期及预计到库日期（格式 YYYY-MM-DD）
- 尾款信息：尾款金额（EUR）及支付截止日期（格式 YYYY-MM-DD）
- 语言使用英文。

### 第五步：更新订单汇总表

在 'order_summary_base.csv' 的基础上，更新新增信息，填入对应数据后输出至：
```
/meituan/mm-administration-016/input/answer/order_summary_updated.csv
```
在status右列新增信息维度包含'Factory Confirmed Amount (EUR)'、'Volume (m^3)'、'Weight (kg)'、'Container (20feet)'、'Deposit Paid (EUR)'、'Deposit Date'（格式 YYYY/M/D）、'Estimated Shipment Date'（格式 YYYY/M/D）、'Estimated Arrival Date'（= Estimated Shipment Date + 30 days，格式 YYYY/M/D）、'Dealer Confirmation Status'（'Confirmed' 、 'Rejected'）、'Order Confirmation Email Subject'、'Email Sender ID'、'Email Recipient ID'、'Email Sent Time'（格式 YYYY/M/D）。同时根据新提供的订单及截图信息，更新原有字段内容（包含已填写的尺寸等信息，以及 'MISSING' 或 'error' 的字段）。

其中：
1、'Qty (sets)'：统一填写单位为 sets 的订单数量，如：100, 如果订单中存在单位问题，填入'error'
2、'Status'：已确认的订单填写 'Confirmed'，有问题待确认的订单填写 'Pending - Awaiting Clarification', 有问题已修改的订单填写 'Pending - Correction Submitted', 正在生产的订单填写 'Producing', 正在发货的订单填写'shipping', 完成收货的填写'Completed'。
3、dimensions以'width*height*depth'的格式保存，日期用YYYY/M/D的格式保存，如'2026/5/1'。
4、Estimated Shipment Date：此处显示的预计发货时间，仅对应订单中首批货物的运输时间。
5、若提供的图片中有该字段，但图片中填写的信息有错误，则填写'error'；若图片中有该字段，但图片中填写的信息有缺失或不完整，填写'MISSING'；若图片中根本不包含该字段，则直接置空。（若未提供该订单的相关字段内容，视为图片中不包含该字段）



请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
