# Bug Injection Summary — figma-D1-L2-2

> **注意：本任务测试架构固有 bug，无代码注入。**

## b_notes_render (L2 / D1)

- **位置**: `js/app.js:_handleInput('speaker-notes')` ← 架构固有 bug，未注入代码
- **Bug 原因**: speaker-notes 每次按键触发 `updateSlide()` → `notify()` → `content.innerHTML` 全量重建，
  原 textarea 被销毁，焦点丢失；IME composition 会话中断导致字符重复。
- **触发路径**: 在 Speaker Notes 文本区域连续输入文字（尤其使用输入法时）
- **可见症状**:
  - 每输入一个字符后焦点丢失，必须重新点击
  - 使用输入法时字符叠加重复
- **正确答案**: A（存在 bug）

### 技术细节

```
用户按键 → _handleInput
    → AppState.updateSlide({ speakerNotes }) → notify()
    → App.render() → content.innerHTML = Views.renderContent()
    → 原 textarea 销毁 → 新 textarea 创建（无焦点，IME 断开）
```

### 修复方案（已应用于其他所有任务）

在 app.js `_handleInput` 的 `'speaker-notes'` case 中，
绕过 `updateSlide()`，直接更新 state 而不触发 notify/re-render：

```javascript
// 修复后：直接更新 state，不触发重渲
const _slide = AppState.getSlideById(curSlide.id);
if (_slide) {
    _slide.speakerNotes = target.value;
    const _pres = AppState.getPresentationById(_slide.presentationId);
    if (_pres) _pres.updatedAt = new Date().toISOString();
}
```
