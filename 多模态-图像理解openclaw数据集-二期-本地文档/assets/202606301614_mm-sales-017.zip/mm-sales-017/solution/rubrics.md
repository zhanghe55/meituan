# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx
/meituan/mm-sales-017/solution/参考答案_对比表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>中包含以下五个部分：第一部分（沙盘楼栋位置及景观特点）、第二部分（客户画像汇总）、第三部分（微信接待话术）、第四部分（本周邀约计划表）、第五部分（KPI追踪表），五个部分缺一不可",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>的第一部分中，基于沙盘图内容正确描述了以下内容：1号楼位于小区的西侧或西北侧；5号楼位于小区的东侧（回答中带东即可）；最中心的核心设施（如中央水景/中庭等）位于1号楼的东侧或东南侧；最中心的核心设施（如中央水景/中庭等）位于5号楼的西侧（回答中带西即可）；儿童乐园位于1号楼的东南侧（回答东侧或南侧均算正确）；儿童乐园位于5号楼的西南侧（回答西侧或南侧均算正确）；主入口位于1号楼与5号楼的西南侧（回答西侧或南侧均算正确）；5号楼临高架桥。回答中关于以上内容的描述必须按照以上答案进行回复，语义和以上内容一致即可。不能缺失以上任一一条回复，如有缺失或语义和以上内容不一致，则为不通过",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>中存在名为「客户画像汇总表」的表格，其中'客户ID'、'客户等级'、'需求类型'、'推荐楼栋'四列的文本内容与<file>/meituan/mm-sales-017/solution/参考答案_对比表.xlsx</file>中「客户画像汇总表」sheet对应列填写的文本内容一致，顺序可以不一致，但除去表头后只有4行的内容，且每个客户这4列的每一行数据内容需要一致",
    "weight": 1
  },

  {
    "id": "04",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>的第三部分微信接待话术中，针对 User_B+E 和 User_D 的话术内容，需要包含'我是锦绣华庭的置业顾问，主要为您提供房产咨询服务。'这一个完整的句子",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>中存在名为「本周邀约计划表」的表格，其中：（1）'视频带看'动作只有User_A和User_C客户；（2）'到访预约'动作只有User_B+E、User_C、User_D；（3）'秒杀锁位'动作只有User_B+E、User_D；（4）同一责任销售的不同客户邀约时间不存在重叠；（5）销售人员只有2名，即该表中只能出现2个不同销售的名字。不满足以上任一条要求即不通过",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-sales-017/input/answer/客户线上接待与邀约到访计划书.docx</file>中存在名为「KPI追踪表」的表格，其中'指标'列和'本周完成'列的文本内容与<file>/meituan/mm-sales-017/solution/参考答案_对比表.xlsx</file>中「KPI追踪表」sheet对应列的文本及数值内容一致，除了表头只有5行数据",
    "weight": 1
  }
]
```
