# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-hr-016/input/answer/销售部3月工资初核表.xlsx
/meituan/mm-hr-016/solution/参考答案_销售部3月工资初核表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-hr-016/input/answer/销售部3月工资初核表.xlsx</file>中的文字和数值与<file>/meituan/mm-hr-016/solution/参考答案_销售部3月工资初核表.xlsx</file>中的文字和数值完全一致",
    "weight": 1
  }
]
```
