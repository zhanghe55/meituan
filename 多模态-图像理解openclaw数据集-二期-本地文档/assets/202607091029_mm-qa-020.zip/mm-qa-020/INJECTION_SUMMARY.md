# Bug Injection Summary — bigmail-D2-L2-1

## (L2 / D2)
- **位置**: `js/app.js:case 'archive-selected'`
- **描述**: 批量归档邮件成功后弹出的 toast 消息被误写为 `"moved to Trash"`，应为 `"archived"`；邮件实际已正确归档（不在收件箱，可在 All Mail 找到），但 toast 提示与实际操作语义完全相反。
- **预期行为**: 归档操作完成后，toast 应显示「N conversation(s) archived」，而非「moved to Trash」。
