# Bug Injection Summary — figma-D3-L23-2

## b011 (L2 / D3)
- **位置**: `js/views.js:_renderElementProperties()` + `js/app.js:_handleCanvasClick()`
- **描述**: `_renderElementProperties()` 渲染 Shape 属性面板时，将 Fill 调色板的选中色从 `el.fill` 误写为 `el.stroke`。同时矩形工具默认颜色改为 fill=#FFC700（黄色）、stroke=#000000（黑色）。使用矩形工具创建矩形后，画布上出现黄色矩形，但属性面板 Fill 调色板高亮的是黑色（stroke 颜色），与画布形状实际颜色不符；Stroke 调色板也高亮黑色——Fill 与 Stroke 调色板高亮了相同颜色，而画布矩形是黄色，同屏矛盾可见。
- **预期行为**: 选中形状后，Fill 调色板应高亮与画布填充色一致的色块（黄色）；Stroke 调色板高亮描边色（黑色），两者不同。

## b012 (L3 / D3)
- **位置**: `js/state.js:moveElement()`
- **描述**: `moveElement()` 在更新元素坐标后只调用 `notify()` 而未更新 `pres.updatedAt`，导致在画布上拖动元素不会更新演示文稿的"最后修改时间"；返回 Presentations 列表后，按"Last Modified"排序，被拖动过元素的演示文稿不会上浮至列表顶部。对比之下，通过属性面板修改元素颜色等属性走 `updateElement()` 路径，会正确更新 `pres.updatedAt`，因此拖动与属性修改的行为不一致。
- **预期行为**: 拖动元素改变其位置后，演示文稿的 updatedAt 应被更新，使其在 Presentations 列表按"Last Modified"排序时出现在列表顶部。
