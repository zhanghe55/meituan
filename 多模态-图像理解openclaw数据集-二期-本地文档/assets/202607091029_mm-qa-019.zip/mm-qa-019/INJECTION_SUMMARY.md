# Bug Injection Summary — bigmail-D1-L3-2

## (L1 / D1)
- **位置**: `js/state.js:getInboxEmails()`
- **描述**: `inboxType === 'unread_first'` 分支将所有已读邮件过滤掉，仅返回未读邮件，而非「未读邮件排在前面、已读邮件在后面」。切换到 Unread first 后，收件箱邮件数量大幅减少，所有已读邮件从列表中消失。
- **预期行为**: Unread first 模式应将未读邮件置顶，已读邮件排在其后，而非将已读邮件从列表中移除。
