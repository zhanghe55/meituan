# Bug Injection Summary — figma-D1-L3-1

## b003 (L3 / D1)
- **位置**: `js/state.js:deleteSlide()`
- **描述**: deleteSlide() 更新演示文稿 slideCount 时使用 getSlidesForPresentation(presId).length + 1 而非 .length，删除幻灯片后 Dashboard 卡片上显示的幻灯片数多出 1，而编辑器 Filmstrip 显示正确数量。
- **预期行为**: 删除一张幻灯片后，Filmstrip 与 Dashboard 卡片均应显示 N-1 张幻灯片，数字一致。

