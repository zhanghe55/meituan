# Rubrics
> **每个 rubric 独立评分，满分 5 分。**
> **⚠️ 评分规则（新版）：BC-1 需同时满足"答案字母正确"与"observed 字段命中注入 bug 症状关键词"两个条件，两者缺一则 BC-1 得 0 分，BC-2/3/4 亦不计分。即：选项选对但描述的是其他 bug、或描述对但选项选错，均不得分。**

## 文件读取路径
```path
/meituan/mm-qa-028/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "<file>/meituan/mm-qa-028/input/answers.json</file> 中 q1 字段值为\"A\"（答案正确且 observed 命中注入 bug 症状（删幻灯片后 Dashboard 计数未同步））。两个条件——答案字母正确 AND observed 字段提到了（数量不一致、偏多、多一张、Filmstrip 与 Dashboard 不符 中的任意一项）——必须同时满足，任一不满足 BC-1 得 0 分。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-028/input/answers.json</file> 中 trigger_steps 提到了删除幻灯片后返回 Dashboard 查看卡片上的幻灯片数（提到了 Delete Slide、删除幻灯片、Dashboard、卡片数量 中的任意一项）",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-028/input/answers.json</file> 中 observed 对注入 bug 现象的描述更完整（提到了 数量不一致、偏多、多一张、Filmstrip 与 Dashboard 不符 中的任意一项，且结合具体数值、状态或对比说明）",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "**前提：本项仅在 BC-1 通过时计分。若 BC-1 未通过，本项得 0 分。** <file>/meituan/mm-qa-028/input/answers.json</file> 中 expected 提到了 Dashboard 与 Filmstrip 应显示相同的幻灯片数（提到了 数量一致、N-1、应相同 中的任意一项）",
    "weight": 1
  }
]
```
