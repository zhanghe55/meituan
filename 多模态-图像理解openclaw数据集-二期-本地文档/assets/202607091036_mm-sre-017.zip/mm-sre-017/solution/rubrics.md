# Rubrics

> **rubric 权重合计 6 分,每条独立评分、互不重叠。**
>
> **门槛规则:BC-1 是门槛项(2 分)。BC-1 未通过则本卷判 0 分,BC-2~BC-5 一律不计分。** BC-1 通过后,BC-2~BC-5 各自独立判分。

## 文件读取路径
```path
/meituan/mm-sre-017/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【门槛项】<file>/meituan/mm-sre-017/input/answers.json</file> 须同时满足两个条件,任一不满足则 BC-1 得 0 分且 BC-2~BC-5 均不计分:(1) failed_service 判断为 `recommendation`(而非错误的物理抛出点 product-catalog、非被连累透传的上游 frontend / frontend-proxy、非常驻噪声 product-reviews);(2) fault_type 判断为脏缓存 / 缓存污染型的逻辑数据错误(recommendation 拿无效商品 id 去查 catalog 导致 NOT_FOUND;而非 catalog 自身故障、非变慢、非内存泄漏 OOM / 资源耗尽)。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "【两服务相关 + 噪声甄别,仅 BC-1 通过时计分】evidence 体现对『两服务相关』与『新增增量 vs 常驻噪声』的甄别:recommendation 与 product-catalog 错误率同时从 0 基线拉起且数值相关(catalog 是被 recommendation 喂脏 id 才同步抬升),而 product-reviews 是基线本就高的常驻噪声(llm 无 key)须排除。提到 recommendation 从0拉起 / 纯新增、product-catalog 同步从0抬起且与之相关、product-reviews 是背景噪声 中的任意一项即得分。本项只考甄别逻辑,不要求给出具体数值(数值在 BC-5 判)。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "【根因行为,仅 BC-1 通过时计分】root_cause 指向 recommendationCacheFailure 行为——recommendation 的 get_product_list 走损坏的『缓存』分支:每次 cache miss 把 cached_ids 追加自身前 1/4(`cached_ids + cached_ids[:len//4]`)使列表几何膨胀且塞满重复 / 陈旧 id,约 50% 请求走 cache hit 直接返回陈旧列表;frontend 拿这些无效 id 逐个 GetProduct,catalog 查不到返回 NOT_FOUND。提到 recommendationCacheFailure、脏缓存 / 缓存污染、cached_ids 膨胀 / 陈旧 id、cache hit/miss 分支、无效id导致下游 NOT_FOUND 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "【三信号运用与两个反直觉考点,仅 BC-1 通过时计分】evidence 体现:(a) 用 trace 判因果方向——NOT_FOUND 因果链自 recommendation 的 get_product_list 发起,product-catalog GetProduct 只是照实返回 `Product Not Found` / grpc NOT_FOUND(status 5),据此区别于 t1 productCatalogFailure 的 INTERNAL(catalog 自身故障);(b) 用资源指标排除 OOM——recommendation RSS 平稳、进程无重启,故非内存泄漏;并指出日志层无错误签名(全 INFO,仅反常 cache miss/hit 行为线索)。提到 trace 的 NOT_FOUND 因果链 / get_product_list 发起、NOT_FOUND 而非 INTERNAL 区别于 t1、RSS 内存平稳排除 OOM、日志无错误签名仅 INFO 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "【量化峰值,仅 BC-1 通过时计分】evidence 指认关键信号并读出窗口内峰值量级(涉及具体数值时以窗口内最大值为准):(a) 指认到 recommendation 错误率信号或 RSS 内存信号,(b) 明确的峰值量级读数——recommendation 错误率(traces_span_metrics_calls_total{status_code=\"STATUS_CODE_ERROR\",service_name=\"recommendation\"})从 0 → ~0.6/s(get_product_list 与下游 GetProduct 同量级),或坐实非 OOM 的 recommendation RSS 内存(process_runtime_cpython_memory_bytes{service_name=\"recommendation\",type=\"rss\"})~62MB 全程平稳。缺信号指认或缺峰值量级读数均不得分。",
    "weight": 1
  }
]
```
