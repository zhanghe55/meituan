你是《快乐消消消》项目组的运营专员，现请根据提供的本地材料，完成7月暑期档活动策划建议。

请读取以下文件：
```
/meituan/mm-Operations-018/input/Q2消除类竞品调研包.docx
/meituan/mm-Operations-018/input/6月端午活动复盘报告.docx
/meituan/mm-Operations-018/input/消除类赛道核心运营亮点官方释义手册.docx
/meituan/mm-Operations-018/input/宾果消消消闯关赢奖活动宣传图.png
/meituan/mm-Operations-018/input/宾果消消消联动宣传图.jpg
/meituan/mm-Operations-018/input/宾果消消消好友助力活动宣传图.png
/meituan/mm-Operations-018/input/宾果消消消暑期预热宣传图.jpg
/meituan/mm-Operations-018/input/开心消消乐达人推广活动宣传图.jpg
/meituan/mm-Operations-018/input/开心消消乐联动活动宣传图.jpg
/meituan/mm-Operations-018/input/开心消消乐消除盲盒抽奖活动宣传图.jpg
/meituan/mm-Operations-018/input/开心消消乐攒清凉值活动宣传图.jpg
/meituan/mm-Operations-018/input/天天爱消除老邀回流活动宣传图.jpg
/meituan/mm-Operations-018/input/天天爱消除暑期登录活动宣传图.png
/meituan/mm-Operations-018/input/天天爱消除暑期排位赛宣传图.jpg
/meituan/mm-Operations-018/input/天天爱消除夏日主题关卡宣传图.jpg
```
任务说明及要求：
1. 根据'Q2消除类竞品调研包.docx'和'消除类赛道核心运营亮点官方释义手册.docx'中的内容，统计竞品运营动作亮点中出现频次最高的两个亮点以及其适配的用户群体，并将筛选出的运营亮点作为下期活动的运营方向建议。在填写时，运营亮点的名称应和'消除类赛道核心运营亮点官方释义手册.docx'中一模一样；适配的用户群体也应来自'消除类赛道核心运营亮点官方释义手册.docx'，文字内容需得一致，符号不做要求
2. 统计所有竞品宣传活动海报中用到的福利道具，筛选出频率最高的两种福利道具；福利道具是指游戏过程中能用到的所有道具；
3. 将第2步筛选出的福利道具融入下期活动海报素材的建议，比如'下期活动海报中应包含xx和xx两种道具元素'
4. 根据'6月端午活动复盘报告.docx'中的内容，筛选出最需要优先解决的3个核心用户痛点，做出解决方案并融入本期活动内容，作为活动特色列出；
5. 基于前三步的内容，输出完整的'快乐消消消游戏暑期活动建议'，内容需要包含：
- 运营方向建议：需包含运营亮点和适配群体
- 素材建议
- 活动特色
结果输出到：
```
/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx
```

请直接执行命令，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
