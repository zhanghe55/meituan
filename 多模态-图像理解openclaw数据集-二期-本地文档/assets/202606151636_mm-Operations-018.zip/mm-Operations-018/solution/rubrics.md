# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx</file>中频次出现最高的两个运营亮点应包含'公域社媒UGC话题挑战赛'和'熟人社交裂变玩法'，需要一模一样",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx</file>中'公域社媒UGC话题挑战赛'运营亮点中的适配群体应为'内容创作型用户、分享欲强的社交型用户、奖励敏感型用户、抖音/小红书/视频号等内容平台高频活跃用户'，文字内容一致即可，符号不做要求",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx</file>中'熟人社交裂变玩法'运营亮点中的适配群体应为'下沉市场用户、有亲友同玩需求的社交型用户、价格敏感型用户'，文字内容一致即可，符号不做要求",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx</file>中'素材建议'的内容应包含'下期活动海报中应包含体力瓶和钻石两种道具元素'，意思一致即可，但道具必须是'体力瓶'和'钻石'或者'体力'、'宝石'也可以接受",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-018/input/answer/快乐消消消游戏暑期活动建议.pptx</file>中的活动特色应包含'福利门槛低、体力充足、活动吸引力强'这些内容，大意一致即可，不要求一模一样",
    "weight": 1
  }
]
```
