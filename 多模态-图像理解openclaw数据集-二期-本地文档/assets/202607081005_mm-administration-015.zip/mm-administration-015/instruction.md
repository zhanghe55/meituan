你是 KitchenPro Factory 的行政采购专员。今日收到了 3 家经销商提交的订单（见下方截图），请根据以下输入的所有文件：
```
/meituan/mm-administration-015/input/dealer_order_A_Muller.png
/meituan/mm-administration-015/input/dealer_order_B_Nordic.png
/meituan/mm-administration-015/input/dealer_order_C_CasaBella.png
/meituan/mm-administration-015/input/factory_order_template.pdf
/meituan/mm-administration-015/input/color_reference_table.xlsx
/meituan/mm-administration-015/input/order_summary_template.csv
```
按照以下操作规范完成工作：
### 第一步：根据输入的3张订单截图，按 factory_order_template.pdf 为模板，为每张订单各生成一份完整的工厂订单 PDF 文件，命名规则为 订单号_经销商名称_order（如果经销商是'Casa Bella S.r.l',经销商名称只需要填'Casa Bella'即可），若名称中存在空格，则用_代替，其他特殊字符保留原样，输出到以下文件夹中：
```
/meituan/mm-administration-015/input/answer/
``` 


填写注意事项如下：
1、颜色标准代码需对照 color_reference_table.xlsx 填写。
2、订单号格式为ORD-下单年份-下单顺序流水号(从001开始)。流水号根据订单的下单时间先后分配：下单时间越早，流水号越小。若订单存在错误，则默认排在所有有效下单时间的订单之后；当存在多个下单时间缺失的订单时，下单时间缺失的订单之间按订单名称（或客户名称）的字母/拼音顺序依次分配流水号。
3、所有必填字段（订单号、下单日期（YYYY/M/D，忽略模板中要求）、经销商名称（dealer_name/Acquirente）、产品编号、产品描述、尺寸、颜色代码、数量）须完整填写，缺失或信息有误的字段不得留空或填写错误内容。
4、若某张订单存在字段缺失或信息错误，则该订单不输出工厂订单PDF文件，转至第二步处理。
5、将订单中的产品图纸部分，进行截图，附在对应PDF订单文件的图纸区域中（必填）。
6、直接在提供的模板文件的基础上进行信息填写，不允许修改模板。
7、经销商名称应使用完整名称
8、尺寸的格式为width*height*depth,单位为mm，从图纸中读取。若存在折叠家具，width按照展开后总长进行记录


### 第二步：为识别到错误的订单生成一份发送给经销商的英文错误确认邮件草稿 md 文件，命名规则为error_confirmation_email_经销商名称.md（如果经销商是'Casa Bella S.r.l',经销商名称只需要填'Casa Bella'即可），空格用_代替，输出到以下文件夹：
```
/meituan/mm-administration-015/input/answer/
```

邮件须包含以下内容：
- 收件人邮箱（经销商emails）
- 发件人邮箱为'procurement@kitchenpro-factory.de'
- 邮件主题（Subject）须包含经销商名称（dealer_name/Acquirente）和订单号（订单号按第一步规则分配）
- 正文须明确列出发现的所有问题，每个问题单独说明，包括：问题描述、涉及的具体字段/数据、请经销商提供的更正信息
- 语言使用英文

### 第三步：生成一份发送给工厂的英文下定邮件文件（只需要写出文本并以 MD 形式保存），收件人为工厂订单邮箱，正文须包含已确认的订单信息，并注明附件文件名，输出至：
```
/meituan/mm-administration-015/input/answer/factory_order_email.md
```
邮件须包含以下内容：
- 收件人邮箱（工厂订单邮箱，从 factory_order_template.pdf 页脚中读取）
- 发件人（采购部门邮箱，为'procurement@kitchenpro-factory.de'）
- 邮件主题（Subject）为 Purchase Order Submission – 所有已确认订单的订单编号(编号之间用&连接)
- 正文须包含所有已确认订单的下单请求，每份订单单独列出，包含：经销商名称、订单编号、产品名称、数量
- 正文须注明附件为对应的订单 PDF 文件，并列出附件文件名
- 语言使用英文

### 第四步：填写订单汇总表。
将 3 家经销商的订单信息（包括有错误的订单），按模板文件 order_summary_template.csv填写，生成一份更新后的信息汇总文件，CSV格式，输出至：
```
/meituan/mm-administration-015/input/answer/order_summary.csv
```
特殊规则说明：
1、若订单中有该字段，但订单中填写的信息有错误，则填写'error'；若订单中有该字段，但订单中填写的信息有缺失或不完整，填写'MISSING'；若订单中根本不包含该字段，则直接置空。
2、'Qty (sets)'：统一填写单位为 sets 的订单数量，如：100, 如果订单中存在单位问题，填入'error'
3、'Status'：已确认的订单填写 'Confirmed'，有问题待确认的订单填写 'Pending - Awaiting Clarification'
4、dimensions以'width*height*depth'的格式保存，日期用YYYY/M/D的格式保存，如'2026/5/1'。

以上所有输出的pdf文件不能有乱码或文字重叠情况，且需要兼容多种格式。

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
