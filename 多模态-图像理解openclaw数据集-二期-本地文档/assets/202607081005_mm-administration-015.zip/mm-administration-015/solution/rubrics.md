# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-administration-015/input/answer/ORD-2026-001_Muller_GmbH_order.pdf
/meituan/mm-administration-015/input/answer/ORD-2026-002_Nordic_Home_AB_order.pdf
/meituan/mm-administration-015/input/answer/error_confirmation_email_Casa_Bella_S.r.l..md
/meituan/mm-administration-015/input/answer/factory_order_email.md
/meituan/mm-administration-015/input/answer/order_summary.csv
/meituan/mm-administration-015/solution/参考答案_订单汇总表.csv
/meituan/mm-administration-015/input/dealer_order_A_Muller.png
/meituan/mm-administration-015/input/dealer_order_B_Nordic.png
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-administration-015/input/answer/ORD-2026-001_Muller_GmbH_order.pdf</file> 为 Muller GmbH 的工厂订单 PDF，且满足以下所有条件：(1) 订单号为 'ORD-2026-001'；(2) 下单日期为 '2026/5/20'；(3) 经销商名称为 'Muller GmbH'，国家为 'Germany'；(4) 产品编号为 'WIC-4391-SET'，产品描述为 'Walk-in Wardrobe Set 4391mm'；(5) 尺寸为 '7135*2730*560'；(6) Front Color 为 'Ivory White'，颜色代码为 'F-101'；(7) Body Color 为 'Warm White'，颜色代码为 'B-102'；(8) Qty为 '85'，也可以是'85 sets'；(9) PRODUCT DRAWING区域的图纸和与输入文件 <file>/meituan/mm-administration-015/input/dealer_order_A_Muller.png</file>中的PRODUCT  DRAWING区域对应的图纸是一样的；(10)文件命名正确且为pdf格式",
    "weight": 2
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-administration-015/input/answer/ORD-2026-002_Nordic_Home_AB_order.pdf</file> 为 Nordic Home AB 的工厂订单 PDF，且满足以下所有条件：(1) 订单号为 'ORD-2026-002'；(2) 下单日期为 '2026/5/21'；(3) 经销商名称为 'Nordic Home AB'，国家为 'Sweden'；(4) 产品编号为 'DC-850-SET'，产品描述为 'Dining Chair 850mm'；(5) 尺寸为 '570*850*592'；(6) Front Color 为 'Matte Black'，颜色代码为 'F-305'；(7) Body Color 为 'Natural Oak'，颜色代码为 'B-310'；(8) 数量为 '200',也可以是'200 sets'；(9) PRODUCT DRAWING区域的图纸和与输入文件 <file>/meituan/mm-administration-015/input/dealer_order_B_Nordic.png</file>  中的PRODUCT DRAWING对应的图纸是一样的；(10)文件命名正确且为pdf格式；",
    "weight": 2
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-administration-015/input/answer/error_confirmation_email_Casa_Bella_S.r.l..md</file> 为发送给Casa_Bella_S.r.l.经销商的英文错误确认邮件，且满足以下所有条件：(1) 收件人邮箱为 'acquisti@casabella.it'；(2) 包含发件人邮箱'procurement@kitchenpro-factory.de'；(3) 邮件主题（Subject）包含经销商名称(dealer name/Acquirente)'Casa Bella S.r.l.' 和订单编号 'ORD-2026-003'；(4) 正文明确列出以下两个错误：① 订单日期（Order Date）字段缺失，请求经销商提供正确日期；② 数量单位填写为 'pcs' 而非规定的 'sets'，请求经销商确认正确的 sets 数量；(5) 语言为英文；(6)文件命名正确且为MD格式",
    "weight": 2
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-administration-015/input/answer/factory_order_email.md</file> 为发送给工厂的英文下定邮件，且满足以下所有条件：(1) 收件人邮箱为 'orders@kitchenpro-factory.de'；(2) 包含发件人邮箱'procurement@kitchenpro-factory.de'；(3) 邮件主题（Subject）为 'Purchase Order Submission – ORD-2026-001 & ORD-2026-002'；(4) 正文包含 ORD-2026-001 订单信息：经销商名称 'Muller GmbH'、订单编号 'ORD-2026-001'、产品名称 'Walk-in Wardrobe Set 4391mm'、数量 '85 sets'；(5) 正文包含 ORD-2026-002 订单信息：经销商名称 'Nordic Home AB'、订单编号 'ORD-2026-002'、产品名称 'Dining Chair 850mm'、数量 '200 sets'；(6) 正文注明附件文件名为 'ORD-2026-001_Muller_GmbH_order.pdf' 和 'ORD-2026-002_Nordic_Home_AB_order.pdf'；(7) 语言为英文",
    "weight": 2
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-administration-015/input/answer/order_summary.csv</file> 与 <file>/meituan/mm-administration-015/solution/参考答案_订单汇总表.csv</file> 内容一致",
    "weight": 2
  }
]
```
