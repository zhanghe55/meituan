# Rubrics

> **rubric 权重合计 6 分,每条独立评分、互不重叠。**
>
> **门槛规则:BC-1 是门槛项(2 分)。BC-1 未通过则本卷判 0 分,BC-2~BC-5 一律不计分。** BC-1 通过后,BC-2~BC-5 各自独立判分。

## 文件读取路径
```path
/meituan/mm-sre-016/input/answers.json
```

```json
[
  {
    "id": "BC-1",
    "content": "【门槛项】<file>/meituan/mm-sre-016/input/answers.json</file> 须同时满足两个条件,任一不满足则 BC-1 得 0 分且 BC-2~BC-5 均不计分:(1) failed_service 判断为 `ad`;(2) fault_type 判断为资源型 / 变慢型故障——具体是 JVM 反复 Full GC 导致的性能劣化 / STW 停顿使请求变慢(而非错误型:本故障 ad 错误率基线 0、故障也 0)。",
    "weight": 2
  },
  {
    "id": "BC-2",
    "content": "【入口思路,仅 BC-1 通过时计分】evidence 命中本故障的核心入口考点:错误率为空 ≠ 无故障——ad 错误率基线 0、故障也 0(按错误率告警不触发),必须转向延迟维度,以 ad GetAds P95 延迟暴涨作为入口线索。体现『错误率为0 / 无变化』且『须转延迟维度 P95 作为入口』即得分。本项只考入口思路,不要求给出具体数值(数值在 BC-5 判)。",
    "weight": 1
  },
  {
    "id": "BC-3",
    "content": "【根因行为,仅 BC-1 通过时计分】root_cause 指向 adManualGc 行为——ad 处理 GetAds 时人为反复触发 Full GC(System.gc() / MarkSweepCompact),stop-the-world 停顿导致请求虽成功但极慢。提到 adManualGc、manual gc / System.gc、Full GC / Major GC、STW 停顿、feature flag 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-4",
    "content": "【根因落到 GC 资源指标,仅 BC-1 通过时计分】evidence 追到 GC 资源指标作为根因(而非停在『ad 慢』),并可结合日志一步坐实:ad JVM major GC 次数 / 耗时从 0 拉起、GC 耗时占比高而 CPU 仅 ~25%(据此区别于 adHighCpu 的 CPU 打满),且日志 WARN `Feature Flag adManualGc enabled, performing a manual gc now` 直接点名 flag。提到 jvm_gc 指标 / major GC increase / GC 耗时占比、区分于 CPU 打满、日志WARN点名 adManualGc 中的任意一项即得分。",
    "weight": 1
  },
  {
    "id": "BC-5",
    "content": "【量化峰值,仅 BC-1 通过时计分】evidence 指认关键信号并读出窗口内峰值量级(涉及具体数值时以窗口内最大值为准):(a) 指认到 GC 资源信号或 GetAds 延迟信号,(b) 明确的峰值量级读数——ad Full GC 增量 increase(jvm_gc_duration_seconds_count{service_name=\"ad\",jvm_gc_action=\"end of major GC\"}[2m]) 从 0 → ~1075,或 ad GetAds P95 延迟从 ~2ms → ~15s。缺信号指认或缺峰值量级读数均不得分。",
    "weight": 1
  }
]
```
