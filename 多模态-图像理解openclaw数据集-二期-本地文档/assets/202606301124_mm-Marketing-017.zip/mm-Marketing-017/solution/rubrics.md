# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-017/input/answer/媒体关系复盘.xlsx
/meituan/mm-Marketing-017/solution/媒体关系复盘参考答案.xlsx
/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系复盘.xlsx</file>和<file>/meituan/mm-Marketing-017/solution/媒体关系复盘参考答案.xlsx</file>的A列-L列的文字和数值内容和顺序完全一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系复盘.xlsx</file>中 A1-L1 单元格填充色为蓝色，色值为‘#00B0F0’",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx</file>中仅包含以下四个章节：‘破冰活动概述’、‘媒体尖锐问题总结’、‘媒体态度转变对比’、‘破冰效果分析和优化建议’",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx</file>中‘破冰活动概述’部分说明了本次破冰行动的时间范围（5月31日-6月2日）和实际参与媒体数量（有19家媒体，有一家媒体没有来），以及各分级媒体参加活动的形式和主题",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx</file>中‘媒体尖锐问题总结’章节需要对媒体提出的尖锐问题进行总结",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx</file>中‘媒体态度转变对比’部分以表格形式呈现，表格仅有以下4列：‘媒体名称’、‘破冰前友好度’、‘破冰后友好度’、‘变化幅度’，共20行数据，其中‘媒体名称’、‘破冰前友好度’、‘破冰后友好度’列的内容和顺序必须和<file>/meituan/mm-Marketing-017/solution/媒体关系复盘参考答案.xlsx</file>的‘媒体名称’、‘破冰前友好度’、‘破冰后友好度’列的内容和顺序完全一致；‘变化幅度’列格式为‘±数值’（如‘+10’、‘-10’），数值等于破冰后友好度评分减去破冰前友好度评分，数值为‘0’时仅填写‘0’即可",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Marketing-017/input/answer/媒体关系破冰效果评估与复盘报告.docx</file>的‘破冰效果分析和优化建议’章节必须生成对破冰活动整体效果的分析，分析时必须结合关于公司的报道次数在破冰前后的变化、负面报道在破冰前后的数量变化和负面配图在破冰前后的数量进行分析，然后给出对破冰活动的总结，总结中必须得出破冰活动对媒体关系是正面效果的结论，最后生成该次破冰活动的优化建议",
    "weight": 1
  }
]
```
