# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-hr-021/input/现场照片/现场全景.png
/meituan/mm-hr-021/input/现场照片/互动讨论场景.png
/meituan/mm-hr-021/input/answer/读书会活动总结.docx
/meituan/mm-hr-021/input/answer/读书会成效报告.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第一章【活动概述】须包含以下全部信息：活动名称为“AI与未来工作”主题读书会；活动时间为2025年11月15日14:30-17:00；活动地点为3楼多功能厅；签到人数为6人，且实际参会人数为4人",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第二章【活动现场内容总结】的第一小节须包含两张输入的现场照片",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第二章须包含参会人员名单表格，表格中包含以下全部6个姓名：张伟、刘洋、陈思远、赵静、王芳、孙鹏，且刘洋、陈思远、赵静、王芳的【是否参会】标注为【是】，张伟、孙鹏的【是否参会】标注为【否】",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第二章【分享内容亮点】部分须提到团队已开始使用AI工具进行code review（或代码审查）",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第三章【参与度评估报告】包含参会者评分表格，表格中刘洋和王芳的评分均为4分，且评分依据中提到了发言或位于演讲位；陈思远和赵静的评分均为3，且评分依据中提到了记笔记或翻阅资料或目光专注于发言者",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会活动总结.docx</file>中第三章【参与度评估报告】中参与度评分的算数平均数为3.5分，且整体参与度结论为【高】（或【参与度高】）",
    "weight": 1
  },
    {
    "id": "07",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会成效报告.docx</file>中第一部分【基本信息】须包含以下全部信息：活动名称为“AI与未来工作”主题读书会；签到6人/现场可见4人；共读书目为《AI 2041》",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会成效报告.docx</file>中第二部分【成效总结】的满意度数据表格中，须包含【活动组织安排】、【分享内容质量】、【互动讨论氛围】、【场地设施条件】、【整体满意度】五个维度，且平均分依次为4.7分、4.7分、4.3分、3.0分、4.3分",
    "weight": 1
  },
  {
    "id": "09",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会成效报告.docx</file>中第三部分【不足与改进】须包含【设施设备类】和【活动安排类】两个类别的建议，其中设施设备类包含关于投影设备（或投影仪、投影幕布）需更换的建议且标注了来源为【问卷1】及【问卷2】，活动安排类包含关于增加实操（或hands-on、动手操作）环节和延长活动时长的建议且标注了来源为【问卷1】、【问卷2】及【问卷3】",
    "weight": 1
  },
  {
    "id": "10",
    "content": "<file>/meituan/mm-hr-021/input/answer/读书会成效报告.docx</file>中第四部分【下一步计划】须包至少3条计划内容，且须包含：（1）一条关于投影设备设施的改善计划；（2）一条关于增加实操/动手环节的计划；（3）一条关于增加活动时间的计划",
    "weight": 1
  }
]
```
