# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-sales-015/input/answer/客服审计回复表.csv
/meituan/mm-sales-015/solution/参考答案_客服审计回复表.csv
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-sales-015/input/answer/客服审计回复表.csv</file>文件；",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-sales-015/input/answer/客服审计回复表.csv</file>文件中A、B、C、D、F、H、J列的内容与<file>/meituan/mm-sales-015/solution/参考答案_客服审计回复表.csv</file>的A、B、C、D、F、H、J列的文本内容与行列顺序完全一致；",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-sales-015/input/answer/客服审计回复表.csv</file>文件中E列的内容需要包含<file>/meituan/mm-sales-015/solution/参考答案_客服审计回复表.csv</file>的E列的文本内容，大致意思相同即可，不能有和答案相悖的内容描述；E3单元格必须包含‘鱼子西’字样。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-sales-015/input/answer/客服审计回复表.csv</file>文件中I列的内容与<file>/meituan/mm-sales-015/solution/参考答案_客服审计回复表.csv</file>文件中I列的文本信息逐行对比，每一个单元格中，多句话术之间可以有顺序上的差异，但必须要包含参考答案中的文字内容；其中I6单元格的'面料说明'、'工艺说明'、'优惠活动'可自由发挥",
    "weight": 1
  }
]
```
