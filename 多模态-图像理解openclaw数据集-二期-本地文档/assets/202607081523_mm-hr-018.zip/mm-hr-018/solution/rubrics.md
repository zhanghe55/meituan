# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx
/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>的Sheet名称和顺序完全一致，依次为'候选人评审明细'、'选拔结果汇总'。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>中'候选人评审明细'和'选拔结果汇总'两个Sheet的表头，与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>中同名Sheet的表头完全一致，且不得新增、删减、改名或调整列顺序。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>中'候选人评审明细'的数据行数为6行，且A-E列（'候选人编号'、'姓名'、'部门'、'岗位'、'申报课程'）与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>逐行完全一致。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>中'候选人评审明细'的F列'基础门槛审核结果'，每行冒号前的'通过/不通过'结果完全一致。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>中'候选人评审明细'的G-K列评分完全一致，列范围包括'基础资格得分(20)'、'业绩专业匹配得分(15)'、'自荐推荐得分(10)'、'面试表现得分(15)'、'试讲评分折算(25)'。",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>的L-N列，与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>的L-N列，对应单元格的评分允许存在±1分偏差，列范围包括'课件截图质量得分(5)'、'试讲视频表现得分(5)'、'证书相关性得分(5)'。",
    "weight": 1
  },
  {
    "id": "08",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>中'候选人评审明细'的O-P列：P列'选拔结果'逐行完全一致；O列'综合评分'对应单元格允许存在±3分偏差。",
    "weight": 1
  },
  {
    "id": "09",
    "content": "输出的<file>/meituan/mm-hr-018/input/answer/内部讲师选拔评审汇总表.xlsx</file>中'选拔结果汇总'的数据行数为3行，A-C列（'选拔结果'、'人数'、'候选人'）与<file>/meituan/mm-hr-018/solution/内部讲师选拔评审汇总表参考答案.xlsx</file>的'选拔结果汇总'sheet的A-C列内容完全一致；",
    "weight": 1
  }
]
```
