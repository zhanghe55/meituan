# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx
/meituan/mm-ba-018/solution/参考答案_当日按揭贷款资料审核台账.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>中包含三个sheet，依次为'证件信息提取汇总'、'三证核验与照片比对结果'、'征信审查结果'",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>中，Sheet'证件信息提取汇总'的表头字段依次为'客户编号'、'姓名'、'身份证号'、'性别'、'出生日期'、'户籍地址'、'婚姻状况'、'配偶姓名'、'证件有效期'、'首付款金额(元)'、'备注'，且除了'备注'列以外，其余列的文本与数值内容须与<file>/meituan/mm-ba-018/solution/参考答案_当日按揭贷款资料审核台账.xlsx</file>中对应位置的文本与数值内容一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>的Sheet'证件信息提取汇总'中，客户A备注列须为'无'；客户B备注列须包含与'收据被涂改'相关或意思相近的描述；客户C备注列须包含与'收据缺失'相关或意思相近的描述",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>中，Sheet'三证核验与照片比对结果'的表头字段依次为'客户编号'、'姓名'、'姓名是否一致'、'证件号是否一致'、'现场照与证件照比对结论'、'异常说明'，且除了'异常说明'列以外，其余列的文本与数值内容须与<file>/meituan/mm-ba-018/solution/参考答案_当日按揭贷款资料审核台账.xlsx</file>中对应位置的文本与数值内容一致",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>的Sheet'三证核验与照片比对结果'中，客户A的异常说明列须为'无'；客户B的异常说明列须为'无'；客户C的异常说明列须包含与'非本人到场'相关或意思相近的描述",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-ba-018/input/answer/当日按揭贷款资料审核台账.xlsx</file>中，Sheet'征信审查结果'的表头字段依次为'客户编号'、'姓名'、'征信状态'、'是否失信被执行人'、'月负债额(元)'，且除表头以外数据行的文本与数值内容，须与<file>/meituan/mm-ba-018/solution/参考答案_当日按揭贷款资料审核台账.xlsx</file>中对应位置的文本与数值内容一致",
    "weight": 1
  }
]
```
