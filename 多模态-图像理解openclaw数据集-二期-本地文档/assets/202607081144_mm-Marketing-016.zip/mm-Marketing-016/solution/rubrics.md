# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md
/meituan/mm-Marketing-016/input/answer/本期内容排期表.xlsx
/meituan/mm-Marketing-016/input/answer/种草文案.md
/meituan/mm-Marketing-016/solution/参考答案_本期内容排期表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md</file>中对‘素材_博主A_猫咪.png’的审核结论为'不通过';视觉特征描述须正确识别该猫咪为'一只''英国短毛猫'（或'英国蓝猫'或'蓝猫'），且须提及其毛色为'灰色'（或'灰蓝色'）、眼睛为'黄色（或'金色'）',体型'偏胖'（或'圆润'、'丰腴'）、毛发'健康',环境'室内'",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md</file>中对‘素材_博主B_猫咪.png’的审核结论为'通过';视觉特征描述须正确识别该猫咪为'一只''布偶猫'（或'布偶'），且须提及其毛色为'白色'（或'浅色长毛'）、眼睛为'蓝色',体型'匀称'、毛发'健康',环境'室外'",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md</file>中对‘素材_博主C_猫咪.png’的审核结论为'通过';视觉特征描述须正确识别该猫咪为'一只''橘猫'（或'橘色虎斑'或'橘色中华田园猫'），且须描述其体型'偏胖'（或'圆润'、'丰腴'）、眼睛为'黄色'、毛发'健康'，环境'无法判断'（或'可能是室内'、'大概率是室内'、'疑似室内'等不确定性室内判断）",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md</file>中对‘素材_合作猫咖环境.png’的审核结论为'通过'；视觉特征描述须正确识别该猫咪为'两只'，一只'奶牛猫'（或'黑白色中华田园猫'或'黑白花'）,一只'棕色狸花猫'（或'棕色虎斑猫'或'棕色中华田园猫'）,其中'奶牛猫'的眼睛为浅蓝色（或浅绿色），'棕色狸花猫'的眼睛为黄色，体型都为'匀称'、毛发都'健康'，环境'室内'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/素材审核与选题匹配报告.md</file>中的选题匹配结果须将‘素材_博主B_猫咪.png’匹配到选题‘T-01’，将‘素材_博主C_猫咪.png’匹配到选题‘T-02’，将‘素材_合作猫咖环境.png’匹配到选题‘T-04’；‘素材_博主A_猫咪.png’的'匹配选题'小节应填写'无'",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/本期内容排期表.xlsx</file>与<file>/meituan/mm-Marketing-016/solution/参考答案_本期内容排期表.xlsx</file>的表头字段及顺序完全一致，且表头以外共4行数据，各行的'选题编号'、'选题名称'、'匹配素材'、'目标平台'、'负责人'字段内容与<file>/meituan/mm-Marketing-016/solution/参考答案_本期内容排期表.xlsx</file>完全一致（行顺序可变）",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/种草文案.md</file>的文案正文中须同时包含以下信息：品种名称'布偶'（或'布偶猫'）、产品名称'喵鲜生·原力冻干'、'95%含肉量'、'0谷物0淀粉0诱食剂'；正文末尾须包含3-5个话题标签，格式如'#科学养猫'",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Marketing-016/input/answer/种草文案.md</file>中'封面尺寸规范'板块须注明小红书封面推荐尺寸为1080×1440px（或1080*1440），比例为3:4",
    "weight": 1
  }
]
```
