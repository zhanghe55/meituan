# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx
/meituan/mm-Marketing-013/solution/媒体关系管理与破冰方案参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx</file> 中仅有两个附表，表名依次是：‘媒体关系管理’、‘破冰方案’；‘媒体关系管理’附表中有且仅有以下 13 列：‘媒体名称’、‘媒体类型’、‘关键联络人’、‘往期合作频次’、‘备注’、‘合作配合度’、‘媒体分级’、‘近期报道次数’、‘近期负面报道数量’、‘负面报道比例’、‘近期报道中有无负面配图’、‘负面配图说明’、‘友好度评分’，列名与顺序完全一致，不得新增、缺失或改动列名，且单元格填充成蓝色,色值为‘#00B0F0’；‘破冰方案’附表表头A1-B1单元格依次是：‘媒体分级’、‘破冰方案’，且单元格填充成蓝色，色值为‘#00B0F0’",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx</file> ‘媒体关系管理’附表中的A-K列和M列的文字内容及数值，与 <file>/meituan/mm-Marketing-013/solution/媒体关系管理与破冰方案参考答案.xlsx</file> 的A-K列和M列的文字内容、显示数值以及文件行顺序均一致，且J列单元格设置为百分比格式",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx</file> ‘媒体关系管理’附表的L列仅有‘互联网圈子’、‘数字经济报’、‘消费者之声’、‘财富人生’、‘创业邦’行填写了具体的负面配图说明，其他媒体在该列均没有填写内容，‘互联网圈子’的说明需要提到‘旧logo’，‘数字经济报’的说明需要提到‘滤镜不好或昏暗的环境下的人类剪影’，‘消费者之声’的说明需要提到‘公司股价下跌’，‘财富人生’的说明需要提到‘logo破碎’，‘创业邦’的说明需要提到‘滤镜不好或昏暗的环境下的人类剪影’，内容不需要完全一致，但是大意要一致",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx</file> 中，‘破冰方案’附表的A2-A4单元格依次是：‘Tier 1’、‘Tier 2’、‘Tier 3’",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx</file> 中，‘破冰方案’附表B2-B4单元格内都针对相应分级的媒体输出了具体的破冰方案",
    "weight": 1
  }
]
```
