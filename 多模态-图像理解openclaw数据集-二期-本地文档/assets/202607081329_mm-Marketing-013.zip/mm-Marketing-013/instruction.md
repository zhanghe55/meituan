你是一名苹果公司的品牌公关专员，负责公司的媒体关系管理工作，请根据输入文件完成下面任务。

输入文件：

```
/meituan/mm-Marketing-013/input/历史媒体合作名册.xlsx
/meituan/mm-Marketing-013/input/媒体分类分级评定标准.docx
/meituan/mm-Marketing-013/input/系统导出媒体近一月公司报道监测原始数据.xlsx
/meituan/mm-Marketing-013/input/正面和负面报道判断规则.docx
/meituan/mm-Marketing-013/input/媒体配图正面负面判断规则.docx
/meituan/mm-Marketing-013/input/近期媒体友好度评估.docx
/meituan/mm-Marketing-013/input/财富人生.jpg
/meituan/mm-Marketing-013/input/财富人生2.png
/meituan/mm-Marketing-013/input/财经日报.png
/meituan/mm-Marketing-013/input/财经日报2.png
/meituan/mm-Marketing-013/input/财经日报3.png
/meituan/mm-Marketing-013/input/产业链研究院.jpg
/meituan/mm-Marketing-013/input/创业邦.png
/meituan/mm-Marketing-013/input/互联网圈子.png
/meituan/mm-Marketing-013/input/华东商报.png
/meituan/mm-Marketing-013/input/经济参考报.png
/meituan/mm-Marketing-013/input/经济参考报2.png
/meituan/mm-Marketing-013/input/科技大V张博.png
/meituan/mm-Marketing-013/input/科技大V张博2.png
/meituan/mm-Marketing-013/input/科技前沿周刊2.png
/meituan/mm-Marketing-013/input/科技前沿周刊.png
/meituan/mm-Marketing-013/input/每日科技快报.png
/meituan/mm-Marketing-013/input/数字经济报.png
/meituan/mm-Marketing-013/input/数字经济报2.png
/meituan/mm-Marketing-013/input/消费者之声.png
/meituan/mm-Marketing-013/input/消费者之声2.png
```

任务描述：

1. 新建一个Excel文件，有两个附表，将sheet1命名为‘媒体关系管理’，表头A1-M1单元格依次是：‘媒体名称’、‘媒体类型’、‘关键联络人’、‘往期合作频次’、‘备注’、‘合作配合度’、‘媒体分级’、‘近期报道次数’、‘近期负面报道数量’、‘负面报道比例’、‘近期报道中有无负面配图’、‘负面配图说明’、‘友好度评分’
，并将A1-M1单元格填充为蓝色，色值为‘#00B0F0’；在A2-A21单元格，按照‘历史媒体合作名册.xlsx’的媒体名称顺序填写媒体名称，在B2-B21单元格填写相应的媒体类型，在C2-C21单元格填写相应的关键联络人，在D2-D21单元格填写相应的往期合作频次的次数，在E2-E21单元格填写相应的备注，在F2-F21单元格填写对应的合作配合程度；
2. 结合‘历史媒体合作名册.xlsx’中对各个媒体的‘备注’和‘媒体分类分级评定标准.docx’，为每家媒体评定媒体级别，内容仅能从（Tier 1、Tier 2、Tier 3）这三个等级中选择；
3. 根据‘系统导出媒体近一月公司报道监测原始数据.xlsx’统计各个媒体关于公司的报道次数，仅填写数字即可，如‘1’，除此之外不填写其他的内容；
4. 结合‘系统导出媒体近一月公司报道监测原始数据.xlsx’和‘正面和负面报道判断规则.docx’，判断媒体近期在公司层面（含旗下产品）的报道中是否有负面报道，有的话仅填写负面报道的数量即可，仅填写数字即可，如‘1’，没有负面报道，则统一填‘0’；
5.在‘负面报道比例’列计算媒体负面报道的比例，如果有负面报道，计算公式是：（近期负面报道数量/近期报道次数）× 100%，将该列的所有单元格格式设置成百分比，小数位数为0；无负面报道的，填入数值‘0’（显示为0%）；
6. 输入文件的图片全都是媒体的配图，文件名为对应的媒体名称，没有输入图片的媒体，默认无负面配图。在‘近期报道中有无负面配图’列，根据‘媒体配图正面负面判断规则.docx’判断媒体配图是否有负面，如果有的话，在对应位置写‘有’，没有的话，在对应位置写‘无’，之后在‘负面配图说明’列填写负面配图的原因，如果没有负面，则不填写内容；
7. 根据‘近期媒体友好度评估.docx’对媒体进行友好度打分，仅填写数字即可，格式如‘90’；
8. 将sheet2命名为‘破冰方案’，表头A1-B1单元格依次是‘媒体分级’、‘破冰方案’，将A1-B1单元格也填充为蓝色，色值为‘#00B0F0’；在‘媒体分级’列A2-A4依次填入‘Tier 1’、‘Tier 2’、‘Tier 3’，最后在B2-B4单元格输出相应分级媒体的具体破冰方案。

将上述内容输出到：

```
/meituan/mm-Marketing-013/input/answer/媒体关系管理与破冰方案.xlsx
```

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。