# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-012/input/answer/中奖名单最终版.xlsx
/meituan/mm-Operations-012/input/answer/活动总结贴.md
/meituan/mm-Operations-012/solution/参考答案_中奖名单最终版.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-012/input/answer/中奖名单最终版.xlsx</file>的表头有且仅有以下6个字段，依次为：'名次'、'用户ID'、'笔记链接'、'综合得分'、'奖项'、'奖品',且除表头外仅包含4行数据",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-012/input/answer/中奖名单最终版.xlsx</file>中，除表头字段外的文本与数值内容，须与<file>/meituan/mm-Operations-012/solution/参考答案_中奖名单最终版.xlsx</file>完全一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-012/input/answer/活动总结贴.md</file>中,须依次包含'一、活动数据总览'、'二、活动目标达成情况'、'三、优选打卡作品'、'四、可复用经验'四个章节",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-012/input/answer/活动总结贴.md</file>中，'活动数据总览'章节须提及'主话题累计浏览量'、'有效打卡笔记数'、'总赞评数'三项数据的实际值分别为'698500'、'4（篇）'、'41200'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-012/input/answer/活动总结贴.md</file>中，'活动目标达成情况'章节须提及'有效打卡笔记数'目标未达成，且要针对未达成的目标作出原因分析",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-012/input/answer/活动总结贴.md</file>中，'优选打卡作品'章节须包含中奖用户1-4名，用户ID依次为'U006''U001''U009''U010'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-012/input/answer/活动总结贴.md</file>中，'可复用经验'章节须提及'黄金时段曝光'、'场景化标题引流'、'优质图片激励'、'降低参与门槛与明确规则'四点",
    "weight": 1
  }
]
```
