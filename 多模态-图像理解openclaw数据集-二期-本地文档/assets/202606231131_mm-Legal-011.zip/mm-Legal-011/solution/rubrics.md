# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Legal-011/input/answer/侵权门店清单.csv
/meituan/mm-Legal-011/input/answer/未侵权案件清单.csv
/meituan/mm-Legal-011/solution/参考答案侵权门店清单.csv
/meituan/mm-Legal-011/solution/参考答案未侵权案件清单.csv
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Legal-011/input/answer/侵权门店清单.csv</file>的表头字段依次为：'案件编号'、'门店名称'、'门店地址'、'侵权类型'、'法律依据条款'、'来源证据'，有且仅有3条数据记录（不含表头行）",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Legal-011/input/answer/侵权门店清单.csv</file>中,'案件编号'、'门店名称'、'门店地址'、'来源证据'4列的文本与数值内容须与<file>/meituan/mm-Legal-011/solution/参考答案侵权门店清单.csv</file>中对应的文本与数值内容完全一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Legal-011/input/answer/侵权门店清单.csv</file>中，'星悦茶坊'对应的侵权类型须为'假冒注册商标'，法律依据条款必须包含'《商标法》第57条第（1）项'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Legal-011/input/answer/侵权门店清单.csv</file>中，'星悦茶语'对应的侵权类型须为'近似商标侵权'，法律依据条款必须包含'《商标法》第57条第（2）项'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Legal-011/input/answer/侵权门店清单.csv</file>中，'鑫达食品商行'对应的侵权类型须为'销售侵权商品'，法律依据条款必须包含'《商标法》第57条第（3）项'",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Legal-011/input/answer/未侵权案件清单.csv</file>的表头字段依次为：'案件编号'、'门店地址'、'来源证据'，有且仅有1条数据记录（不含表头行）",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Legal-011/input/answer/未侵权案件清单.csv</file>中记录的文本与数值内容须与<file>/meituan/mm-Legal-011/solution/参考答案未侵权案件清单.csv</file>中对应的文本与数值内容完全一致",
    "weight": 1
  }
]
```
