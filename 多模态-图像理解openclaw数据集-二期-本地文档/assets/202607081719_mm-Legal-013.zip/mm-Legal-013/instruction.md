你是一名法务专员，我司（深圳市XX科技有限公司）持有一项折叠式手机支架的外观设计专利，保护该产品的整体外观视觉形态。你发现YY电子商务有限公司销售的"多角度折叠手机支架"与我司专利高度相似，需要从证据分析到侵权判断，再到起诉状准备，完成完整的诉讼准备工作。

请读取以下输入文件：

```
/meituan/mm-Legal-013/input/外观设计专利权利要求书及简要说明.docx
/meituan/mm-Legal-013/input/专利主视图.png
/meituan/mm-Legal-013/input/专利侧视图.png
/meituan/mm-Legal-013/input/专利俯视图.png
/meituan/mm-Legal-013/input/被告产品图1.png
/meituan/mm-Legal-013/input/被告产品图2.png
/meituan/mm-Legal-013/input/被告产品图3.png
/meituan/mm-Legal-013/input/被告产品销售数据及成本明细.xlsx
/meituan/mm-Legal-013/input/专利侵权分析流程文档.docx
/meituan/mm-Legal-013/input/主体信息汇总.docx
```

请严格按照"专利侵权分析流程文档.docx"中规定的步骤执行以下任务，并输出两个文件：

**输出文件1：专利侵权分析报告.xlsx**

输出要求：该文件有且仅有以下四个sheet，且顺序也要按照列出的先后顺序进行创建,分别为‘专利保护要点及视觉特征表’、‘外观整体比对矩阵表’、‘侵权分析结论表’、‘赔偿计算明细表’。表格中的输出内容需要严格遵循‘专利侵权分析流程文档.docx’文件中的相关规定。

输出到：
```
/meituan/mm-Legal-013/input/answer/专利侵权分析报告.xlsx
```

**输出文件2：专利侵权起诉状.docx**

输出要求：起诉状必须依据‘专利侵权分析流程文档.docx’中要求的法院公示的起诉模板进行撰写，结合‘主体信息汇总.docx’的内容与‘专利侵权分析报告.xlsx’的内容完成‘专利侵权起诉状.docx’的撰写。‘主体信息汇总.docx’中已使用 XX/XXXX 进行脱敏的信息（如公司名称中的 XX 、联系电话中的 XXXX 等），在起诉状中保持原样输出即可，不要自行补全或修改。

输出到：
```
/meituan/mm-Legal-013/input/answer/专利侵权起诉状.docx
```

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。