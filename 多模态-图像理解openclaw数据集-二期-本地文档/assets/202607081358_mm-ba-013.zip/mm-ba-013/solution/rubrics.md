# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx
/meituan/mm-ba-013/solution/参考答案_企业信息和经营现状分析.xlsx
```

```json
[

  {
    "id": "01",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>'企业基础信息'sheet中的A-B列的文字和数值内容与<file>/meituan/mm-ba-013/solution/参考答案_企业信息和经营现状分析.xlsx</file>的'企业基础信息'sheet中的A-B列的文字、数值内容以及数据行顺序需一致，其中对应单元格内的标点符号、中英文格式不要求完全一致，输出文字和数字内容一致即可。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>'主营业务信息'sheet中的A-E列的文字和数值内容与<file>/meituan/mm-ba-013/solution/参考答案_企业信息和经营现状分析.xlsx</file>的'主营业务信息'sheet中的A-E列的文字、数值内容以及数据行顺序需一致，其中对应单元格内的标点符号、中英文格式不要求完全一致，输出文字和数字内容一致即可。",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>'投资情况'sheet中的A-D列的文字和数值内容与<file>/meituan/mm-ba-013/solution/参考答案_企业信息和经营现状分析.xlsx</file>的'投资情况'sheet中的A-D列的文字、数值内容以及数据行顺序需一致，其中对应单元格内的文段内标点符其中对应单元格内的标点符号、中英文格式不要求完全一致，输出文字和数字内容一致即可。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>的'市场反馈分析'sheet中B2需包含'课程实用'、'推题功能智能，精准推送'、'题库量大'这三条;B3中需包含'APP加载慢'、'更新频率慢'、'客服响应慢'这三条。包含内容所表达语义一致即可。",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>'市场反馈分析'sheet中的B4单元格的文字内容必须包含'价格贵'、'客服慢'、' 更新慢'、'退款难'这四条，可忽略标点。",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx</file>'市场反馈分析'sheet中的B5单元格，包含综合评分4.3分、评价总数12847条、下载量50万+、开发者回复率78%、行业均值45%、好评率80%、差评率9%；内容语义、数值一致即可，标点和单位可忽略。",
    "weight": 1
  }
]
```
