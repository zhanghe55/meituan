# 企业信息梳理和经营现状分析任务

你是咨询公司的商业分析师，目前需要对一家教育科技企业开展商业模式分析。请依据提供的企业资料，完成企业信息梳理和经营现状分析，并将分析结果输出一个 '企业信息和经营现状分析.xlsx' 文件。


## 输入文件

请读取以下文件：

```
/meituan/mm-ba-013/input/SOP.md
/meituan/mm-ba-013/input/企业基础信息包/企业简介.png
/meituan/mm-ba-013/input/企业基础信息包/企业荣誉资质.png
/meituan/mm-ba-013/input/企业基础信息包/企业组织架构图.png
/meituan/mm-ba-013/input/主营业务资料包/产品宣传册.pdf
/meituan/mm-ba-013/input/主营业务资料包/AI学习机后台截图.png
/meituan/mm-ba-013/input/投资资料包/股权结构图截图.png
/meituan/mm-ba-013/input/投资资料包/对外投资关系图截图.png
/meituan/mm-ba-013/input/市场反馈资料包/App评论截图.png
/meituan/mm-ba-013/input/市场反馈资料包/应用市场评分截图.png
/meituan/mm-ba-013/input/市场反馈资料包/社交媒体评价截图.png
```

按照'/meituan/mm-ba-013/input/SOP.md'中文件要求进行生成


## 输出文件

请将整理好的结果文档输出至：
```
/meituan/mm-ba-013/input/answer/企业信息和经营现状分析.xlsx
```

请直接执行操作，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
