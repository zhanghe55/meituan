# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-017/input/answer/市场与商品初筛报告.docx
/meituan/mm-Operations-017/input/answer/商品资质与测评表.xlsx
/meituan/mm-Operations-017/input/answer/直播选品确认单.xlsx
/meituan/mm-Operations-017/solution/参考答案_商品资质与测评表.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-017/input/answer/市场与商品初筛报告.docx</file>包含三个章节，且章节标题分别为'一、市场趋势分析'、'二、竞品直播间策略对比'、'三、初筛商品列表'",
    "weight": 1
  },
    {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-017/input/answer/市场与商品初筛报告.docx</file>的'市场趋势分析'部分须提及3个爆款，分别为'玻尿酸补水面膜'、'氨基酸温和洁面乳'、'烟酰胺美白精华'，且指出'防晒SPF50'的环比增长比例为'+88%'",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-017/input/answer/市场与商品初筛报告.docx</file>的'竞品直播间策略对比'部分包含一个表格，其中'美肌严选'的引流款品类为'面膜'、引流价为19.9；'颜究所'的引流款品类为'洁面'、引流价为29.9",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-017/input/answer/市场与商品初筛报告.docx</file>的'初筛商品列表'部分须说明8款初筛商品涉及到'洁面'、'彩妆'、'面膜'、'防晒'、'精华'这五个品类",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-017/input/answer/商品资质与测评表.xlsx</file>的表头有且仅有6列，依次为：'商品编号'、'商品名称'、'资质状态'、'核心卖点'、'样品缺陷'、'综合评分'，且除表头外共8行数据，其中'商品编号'、'商品名称'、'资质状态'、'核心卖点'、'综合评分'五列内容须与<file>/meituan/mm-Operations-017/solution/参考答案_商品资质与测评表.xlsx</file>对应列内容完全一致",
    "weight": 1
  },
    {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-017/input/answer/商品资质与测评表.xlsx</file>中的'样品缺陷'列，商品编号'SP04'的对应内容须包含与'膏体歪斜'含义相近的4字内容；商品编号'SP07'的对应内容须包含与'粉体撒漏'含义相近的4字内容；其余行该列内容均为'无'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-017/input/answer/直播选品确认单.xlsx</file>除表头外共有3行数据，仅包含商品编号为SP03、SP05、SP08的商品",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Operations-017/input/answer/直播选品确认单.xlsx</file>中SP08须分类为'引流款'，直播价(元)为'39.9'；SP05须分类为'爆款'，直播价(元)为'59.9'；SP03须分类为'利润款'，直播价(元)为'99.0'",
    "weight": 1
  }
]
```
