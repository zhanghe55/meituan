# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中'核心目标拆解表'的表头需要是'上市6个月总销售额（亿元）'、'KA卖场总销售额（亿元）'、'连锁便利店总销售额（亿元）'、'夫妻店总销售额（亿元）'、'新零售自提点总销售额（亿元）'",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中'核心目标拆解表'第二行从左至右的数值需要为'2'、'0.8'、'0.5'、'0.4'、'0.3'，此处对数值的格式不做要求",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中'区域差异化目标权重'部分的内容需要包含华东大区、华南大区、西南大区、华北大区、西北大区五个部分的内容",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中'区域差异化目标权重'中，华东大区目标权重需要为'35%'，销售额目标需要为'0.7亿元'；华南大区目标权重需要为'25%'，销售额目标需要为'0.5亿元'；西南大区目标权重需要为'15%'，销售额目标需要为'0.3亿元'；华北大区目标权重需要为'15%'，销售额目标需要为'0.3亿元'；西北大区目标权重需要为'10%'，销售额目标需要为'0.2亿元'",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中'区域差异化目标权重'中，时间节点及责任方部分的内容需要是'铺货期由各区域销售经理负责'、'动销期需要由经销商负责'、'渗透期由总部通路营销部统筹负责'，意思一致即可",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中内部调研部分的内容，ROI维度最优的渠道需要是'连锁便利店'，单店月产出维度最优渠道需要是'KA卖场'、库存周转天数维度最优渠道需要是'新零售自提点'",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中外部调研中，KA卖场的陈列策略需要包含'四种口味'、'位置在卖场门口'，意思一致即可；活动规则内容需要包含'买一送一'，意思一致即可",
    "weight": 1
  },
  {
    "id": "08",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中外部调研中，连锁便利店的陈列策略需要包含'三种口味'、'位置在收银台对面、附近'，意思一致即可；活动规则内容需要包含'指定商品第二件半价'，意思一致即可",
    "weight": 1
  },
  {
    "id": "09",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中外部调研中，夫妻店的陈列策略需要包含'两种口味'、'位置在收银台旁边'，意思一致即可；活动规则内容需要包含'月销满额返现'，意思一致即可",
    "weight": 1
  },
  {
    "id": "10",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中外部调研中，新零售自提点的陈列策略需要包含'两种口味'、'位置在自提点入口'，意思一致即可；活动规则内容需要包含'集瓶盖兑好礼'，意思一致即可",
    "weight": 1
  },
  {
    "id": "11",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中分通路政策的部分包含适用范围、执行周期、达标要求、核销规则四部分内容",
    "weight": 1
  },
  {
    "id": "12",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中风险预案的部分包含竞品跟进补贴、打价格战的应对预案和旺季货源不足的分配预案的内容",
    "weight": 1
  },
  {
    "id": "13",
    "content": "输出的<file>/meituan/mm-Marketing-022/input/answer/青小芒苏打水通路营销方案.docx</file>文档中竞品陈列策略部分，口味的种类必须是一个具体的值，不能是一个范围区间，违反则不通过",
    "weight": 1
  }
]
```