你是公司的社群运营专员，负责「焕颜精华液pro」新品试用活动的用户筛选与二次宣传素材制作。

请读取以下文件：
```
/meituan/mm-Operations-020/input/新产品实物图.png
/meituan/mm-Operations-020/input/社群内用户活跃度打分统计表.xlsx
/meituan/mm-Operations-020/input/拍摄及文案要求灵感库.docx
/meituan/mm-Operations-020/input/薄荷凉凉朋友圈截图.png
/meituan/mm-Operations-020/input/粉色泡泡朋友圈截图.jpg
/meituan/mm-Operations-020/input/暖暖子朋友圈截图.png
/meituan/mm-Operations-020/input/糖糖酱朋友圈截图.png
/meituan/mm-Operations-020/input/小鹿同学朋友圈截图.png
/meituan/mm-Operations-020/input/小鱼儿朋友圈截图.png
/meituan/mm-Operations-020/input/蜜桃酱朋友圈截图.png
/meituan/mm-Operations-020/input/社群用户报名截图.png
```
任务说明：
1. 筛选试用用户：
- 优先筛选社群内最先申请试用的3个用户
- 排除上一步已选出的3个用户，在活跃度打分统计表中剩下的用户中，筛选3个分值最高的用户
- 将筛选的6个用户所在行'A-J列'填充为标准色黄色，并输出更新后的文档
2. 核对朋友圈截图：
对步骤1中筛选出的6名用户的朋友圈截图按照'拍摄及文案要求灵感库'中的规则进行审核
3. 制作二次宣传素材库：
将步骤2审核通过的截图用来做二次宣传的素材，需要包含用户截图以及产品宣传的文案。

注意事项：
1. 二次宣传的素材文档中应包含所有审核通过的用户截图以及文案；每一个用户的素材为一个单独的部分，每一个用户的截图需要针对其内容写一个新的产品宣传文案，而非用户截图中的文案内容；具体格式为:
用户1昵称：XXX
用户1截图：xxx
宣传文案：xxx
用户2昵称：XXX
用户2截图：xxx
宣传文案：xxx
2. 产品宣传文案内容需符合'拍摄及文案要求灵感库'第二章的文案要求
3. 更新后的用户活跃度打分统计表只需按上述步骤做颜色填充的处理，其余内容不能改动，也不得擅自添加、减少内容。

结果输出到：
```
/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx
/meituan/mm-Operations-020/input/answer/更新后的用户活跃度打分统计表.xlsx
```

请直接执行命令，不要问我任何问题，也不要让我做出进一步决策。如果遇到任何问题和决策点，请你自行解决。
