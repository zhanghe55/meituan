# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Operations-020/input/answer/更新后的用户活跃度打分统计表.xlsx
/meituan/mm-Operations-020/solution/更新后的用户活跃度打分统计表-参考答案.xlsx
/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Operations-020/input/answer/更新后的用户活跃度打分统计表.xlsx</file>中，'小鱼儿'、'糖糖酱'、'粉色泡泡'、'蜜桃酱'、'暖暖子'、'薄荷凉凉'这6名用户所在行的单元格'A-J列'填充颜色为标准色黄色，且文档中所有文字和数值与<file>/meituan/mm-Operations-020/solution/更新后的用户活跃度打分统计表-参考答案.xlsx</file>中的文字和数值一致",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中有且只能有'粉色泡泡'、'蜜桃酱'、'小鱼儿'3个用户的截图，存在多余用户的截图或缺少任意一个，均不通过",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中每个用户的昵称、用户截图、宣传文案都应为单独的一部分，具体的先后顺序为'用户昵称、用户截图、宣传文案'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中'宣传文案'中必须包含产品名称'焕颜精华液 pro'，不能错写或简写",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中'宣传文案'中必须包含真实的个人推荐态度",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中'宣传文案'禁止使用'最好用、第一名、治疗、医疗级'等绝对化或医疗相关词语",
    "weight": 1
  },
  {
    "id": "07",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中'宣传文案'禁止虚假宣传，不得声称产品有超出其功效的效果",
    "weight": 1
  },
  {
    "id": "08",
    "content": "<file>/meituan/mm-Operations-020/input/answer/包含用户真实体验的二次宣传素材库.docx</file>中'宣传文案'禁止出现竞品品牌名称或负面对比相关内容",
    "weight": 1
  }
]
```
