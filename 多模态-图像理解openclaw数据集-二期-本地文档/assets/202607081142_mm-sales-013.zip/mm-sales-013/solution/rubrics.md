# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-sales-013/input/answer/6月库存更新.xlsx
/meituan/mm-sales-013/solution/参考答案_6月库存更新.xlsx
/meituan/mm-sales-013/input/签名图片.jpg
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-sales-013/input/answer/6月库存更新.xlsx</file>满足以下要求：4个sheet的顺序依次为‘销售出库单-0601’、‘销售出库单-0603’、‘销售出库单-0608’、‘库存记录表’。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-sales-013/input/answer/6月库存更新.xlsx</file>的‘销售出库单-0601’、‘销售出库单-0603’、‘销售出库单-0608’3个sheet的数值与文本内容，与<file>/meituan/mm-sales-013/solution/参考答案_6月库存更新.xlsx</file>的‘销售出库单-0601’、‘销售出库单-0603’、‘销售出库单-0608’3个sheet的A1:G13范围内（除去E5单元格）的文本和数值内容一致。‘销售出库单-0608’的E9:F10和F12单元格的数值均保留2位小数",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-sales-013/input/answer/6月库存更新.xlsx</file>的‘库存记录表’sheet，与<file>/meituan/mm-sales-013/solution/参考答案_6月库存更新.xlsx</file>的‘库存记录表’sheet的A-J、L列的文本和数值内容一致；",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-sales-013/input/answer/6月库存更新.xlsx</file>中‘销售出库单-0608’的A14单元格右侧插入了<file>/meituan/mm-sales-013/input/签名图片.jpg</file>",
    "weight": 1
  }
]
```
