# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx
/meituan/mm-Finance-011/solution/审计报告初稿-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>的表头从A1-E1应依次为：合同编号、材料是否有缺漏、风险等级结果、处理要求、备注",
    "weight": 1
  },
  {
    "id": "02",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>中'A-D'列的文字与数值内容应与<file>/meituan/mm-Finance-011/solution/审计报告初稿-参考答案.xlsx</file>中'A-D'列的文字与数值内容一致",
    "weight": 1
  },
  {
    "id": "03",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>中编号为'YF-CG-XT-2024001'的备注列应为'无'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>中编号为'YF-CG-HT-2024001'的备注列应包含'验收照片CG002空调品牌与类型与合同约定内容不一致'、'发票CG002日期早于合同签订日期'，意思一致即可，但需要同时包含两条内容，缺一条即不通过",
    "weight": 1
  },
  {
    "id": "05",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>中编号为'YF-CG-LK-2024001'的备注列应包含'发票CG007金额与合同约定金额偏差率超过3%'、'验收照片CG003安装环境不合规'、'验收照片CG007显示器数量不对，品牌不对'、'发票（CG003）的单价、税额计算错误'、'合同中乙方公章与预留公章不一致'意思一致即可，但需要同时包含以上内容，缺一条即不通过",
    "weight": 1
  },
  {
    "id": "06",
    "content": "<file>/meituan/mm-Finance-011/input/answer/审计报告初稿.xlsx</file>中编号为'YF-CG-SX-2024001'的备注列应包含'发票CG004抬头为云帆科技有限公司，与合同甲方云帆网络主体不一致'、'验收照片CG004颜色为黑色，和合同约定的浅灰色不一致'、'验收照片（CG008）工位隔断高度为0.8米，与合同约定1.2米不符'、'合同乙方名称字段为空'、'发票（CG005）开票日期2024年2月2日早于合同签订日期2024年5月10日'，意思一致即可，但需要同时包含以上内容，缺一条即不通过",
    "weight": 1
  }
]
```
