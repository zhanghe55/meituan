# Bug Injection Summary — figma-D1-L2-1

## b002 (L2 / D1)
- **位置**: `js/state.js:addComment()`
- **描述**: addComment() 创建评论时将 resolved 字段错误地初始化为 true，导致新添加的评论立即以已解决状态显示在面板中，看起来像是刚提交就被系统自动关闭。
- **预期行为**: 新添加的评论应以未解决（unresolved）状态显示，文字清晰可见，解决按钮显示空心圆圈图标，工具栏评论徽章计数 +1。

