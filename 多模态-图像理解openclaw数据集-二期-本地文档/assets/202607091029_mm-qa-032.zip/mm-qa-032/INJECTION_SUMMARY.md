# Bug Injection Summary — figma-D2-L3-1

> **注意：本任务测试应用预存真实 bug，无代码注入。**

## b_arrow_fill (L2 / D2)

- **位置**: `js/components.js:canvasElement()` ← 预存真实 bug，未注入代码
- **Bug 原因**: Arrow 形状渲染逻辑为 `el.stroke || el.fill`，只要 stroke 有值就忽略 fill。
- **触发路径**: 创建 Arrow 元素 → 通过 Fill 调色板修改填充色 → 画布颜色不变
- **可见矛盾**: Fill 调色板高亮新颜色，但画布 Arrow 仍显示 stroke 颜色（深灰）
- **正确答案**: 路径 C（创建 Arrow，修改 SHAPE 颜色相关属性）

### 路径设计

| 路径 | 描述 | 是否有 bug |
|------|------|-----------|
| 路径 A | Share 面板操作（添加/移除共享用户） | ❌ 无 bug |
| 路径 B | Dashboard Title A-Z 排序 + 搜索 | ❌ 无 bug |
| 路径 C | 创建 Arrow，修改 SHAPE 颜色属性 | ✅ **有 bug**（Fill 改了但 Arrow 颜色不变） |
| 路径 D | 搜索 Accessibility 演示文稿并放映 | ❌ 无 bug |

### 技术细节

Arrow 渲染逻辑（`components.js:canvasElement()`）：

```javascript
// shapeType === 'arrow'
inner = `<div style="border-bottom: solid ${el.stroke || el.fill || '#333'}">`;
```

`el.stroke`（默认 `#333333`）不为空，所以始终使用 stroke 颜色，fill 的修改对 Arrow 无视觉效果。修改 Fill 调色板只改 `el.fill`，不改 `el.stroke`，导致画布颜色不变但调色板显示已更改，产生同屏矛盾。
