# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx
```

```json
[
  {
    "id": "01",
    "content": "输出了<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>。",
    "weight": 1
  },
  {
    "id": "02",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,每一家企业的内容需要包含优先级跟进标签（S/A）、建联话术、合作切入点",
    "weight": 1
  },
  {
    "id": "03",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,惠家生活超市的优先级标签需要为'S'",
    "weight": 1
  },
  {
    "id": "04",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,惠家生活超市的合作切入点需要为'中秋'，意思一致即可",
    "weight": 1
  },
  {
    "id": "05",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,鲜柠季的优先级标签需要为'S'",
    "weight": 1
  },
  {
    "id": "06",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,鲜柠季的合作切入点需要为'开学季'，意思一致即可",
    "weight": 1
  },
  {
    "id": "07",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,燃卡24小时健身的优先级标签需要为'A'",
    "weight": 1
  },
  {
    "id": "08",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,燃卡24小时健身的合作切入点需要为'减脂/塑形'相关，意思一致即可",
    "weight": 1
  },
  {
    "id": "09",
    "content": "输出的<file>/meituan/mm-Marketing-018/input/answer/S&A级线索定制建联方案包.docx</file>文档中,只能有燃卡24小时健身、鲜柠季、惠家生活超市三个企业的信息",
    "weight": 1
  }
]
```