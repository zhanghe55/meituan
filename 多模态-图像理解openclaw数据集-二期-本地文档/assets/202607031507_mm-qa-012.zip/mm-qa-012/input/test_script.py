"""
Bug工单管理系统 - 自动化测试脚本
测试页面：bug_tracker.html（本地HTML，直接用浏览器打开）
"""

import time

# ─────────────────────────────────────────────────────────────
# 测试配置
# ─────────────────────────────────────────────────────────────
PAGE_PATH = "bug_tracker.html"   # 相对路径，实际执行时使用 file:// 绝对路径
WAIT_SHORT = 0.5                 # 短等待（秒）
WAIT_LONG  = 1.0                 # 长等待（秒）


# ─────────────────────────────────────────────────────────────
def step_01_open_page(browser):
    """打开页面，验证初始状态"""
    browser.navigate(PAGE_PATH)
    time.sleep(WAIT_LONG)

    title = browser.get_text("h1")
    assert title == "Bug工单管理系统", f"页面标题错误，期望'Bug工单管理系统'，实际'{title}'"

    total = browser.get_text("#cardTotal")
    assert total == "6", f"初始总工单数应为6，实际为'{total}'"


# ─────────────────────────────────────────────────────────────
def step_02_submit_bug(browser):
    """提交新工单，验证工单出现在列表首行"""
    browser.input("#bugTitle", "支付按钮点击无响应")
    browser.select("#bugPriority", "高")
    browser.select("#bugAssignee", "张三")
    browser.click("#submitBtn")
    time.sleep(WAIT_SHORT)

    first_row_title = browser.get_text("#bugTableBody tr:first-child td:nth-child(2)")
    assert "支付按钮点击无响应" in first_row_title, \
        f"列表首行标题应包含'支付按钮点击无响应'，实际为'{first_row_title}'"


# ─────────────────────────────────────────────────────────────
def step_03_verify_status(browser):
    """验证新提交工单的初始状态"""
    time.sleep(WAIT_SHORT)
    status_text = browser.get_text("#bugTableBody tr:first-child td:nth-child(4)")
    assert "处理中" in status_text, \
        f"新提交工单状态应为'处理中'，实际为'{status_text}'"


# ─────────────────────────────────────────────────────────────
def step_04_filter_by_priority(browser):
    """按优先级"高"筛选，验证筛选结果数量"""
    time.sleep(WAIT_SHORT)

    browser.select("#filterPriority", "高")
    time.sleep(WAIT_SHORT)

    count_text = browser.get_text("#resultCount")
    assert "共 3 条" in count_text, \
        f"筛选结果应为'共 3 条'，实际为'{count_text}'"


# ─────────────────────────────────────────────────────────────
def step_05_start_progress(browser):
    """清除筛选，对首行工单执行"开始处理"""
    browser.select("#filterPriority", "")
    time.sleep(WAIT_SHORT)

    browser.click("#bugTableBody tr:first-child .btn-primary")
    time.sleep(WAIT_SHORT)

    # 弹窗确认
    browser.click("#modalConfirmBtn")
    time.sleep(WAIT_SHORT)

    status_text = browser.get_text("#bugTableBody tr:first-child td:nth-child(4)")
    assert "处理中" in status_text, \
        f"点击'开始处理'并确认后，状态应为'处理中'，实际为'{status_text}'"


# ─────────────────────────────────────────────────────────────
def step_06_resolve_issue(browser):
    """对首行工单执行"标记解决"操作"""
    browser.click("#bugTableBody tr:first-child .btn-success")
    time.sleep(WAIT_SHORT)

    status_text = browser.get_text("#bugTableBody tr:first-child td:nth-child(4)")
    assert "已解决" in status_text, \
        f"点击'标记解决'并确认后，状态应为'已解决'，实际为'{status_text}'"


# ─────────────────────────────────────────────────────────────
def step_07_verify_stats(browser):
    """验证统计卡片数据更新正确"""
    time.sleep(WAIT_SHORT)

    total = browser.get_text("#cardTotal")
    assert total == "7", f"总工单数应为7，实际为'{total}'"

    resolved = int(browser.get_text("#cardResolved"))
    assert resolved >= 2, f"已解决数量应 >= 2，实际为'{resolved}'"


# ─────────────────────────────────────────────────────────────
def run_all_steps(browser):
    steps = [
        step_01_open_page,
        step_02_submit_bug,
        step_03_verify_status,
        step_04_filter_by_priority,
        step_05_start_progress,
        step_06_resolve_issue,
        step_07_verify_stats,
    ]
    results = []
    for step in steps:
        try:
            step(browser)
            results.append((step.__name__, "PASS", ""))
        except AssertionError as e:
            results.append((step.__name__, "FAIL", str(e)))
    return results


if __name__ == "__main__":
    # 实际执行时由浏览器工具驱动，此处仅作结构说明
    print("请使用浏览器自动化工具执行本脚本中的各步骤函数")
