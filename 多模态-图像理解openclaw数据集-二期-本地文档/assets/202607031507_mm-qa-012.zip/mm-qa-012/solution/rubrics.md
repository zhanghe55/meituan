# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则该任务整体判定为不通过。**

## 文件读取路径

```path
/meituan/mm-qa-012/input/answer/test_script_fixed.py
/meituan/mm-qa-012/input/answer/report.md
/meituan/mm-qa-012/input/answer/imgs/*
```

```json
[
  {
    "id": "01",
    "content": "输出了 <file>/meituan/mm-qa-012/input/answer/test_script_fixed.py</file> 和 <file>/meituan/mm-qa-012/input/answer/report.md</file>",
    "weight": 1
  },
  {
    "id": "02",
    "content": "读取 <file>/meituan/mm-qa-012/input/answer/report.md</file> 文件，检查是否包含脚本与流程图不一致点的定位分析：（1）step_03_verify_status 函数第 48 行，断言期望状态为'处理中'，但流程图要求新提交工单初始状态应为'待处理'；（2）step_06_resolve_issue 函数第 86-91 行，点击'标记解决'按钮后遗漏了弹窗确认步骤，流程图明确要求在弹窗中点击'确认'。若上述2条不一致之处缺少任意一条或者未提及准确函数名或行号，则不通过",
    "weight": 1
  },
  {
    "id": "03",
    "content": "读取 <file>/meituan/mm-qa-012/input/answer/report.md</file> 文件，（1）检查报告中是否明确记录了所有测试步骤验证通过的结论（如7 个步骤全部验证通过或等价表述）。（2）循环修复轮数不超过 3 轮.若报告中未包含全部通过的明确说明或修复轮数超过 3 轮，则不通过。",
    "weight": 1
  },
  {
    "id": "04",
    "content": "<file>/meituan/mm-qa-012/input/answer/imgs/</file> 目录下，存在7个步骤的截图。且截图中的中文内容正常显示（无乱码、无问号替代中文字符）。且每个步骤的截图必须包含对应步骤的关键断言信息：Step 01 需包含页面标题'Bug工单管理系统'和统计卡片'总工单数'为6；Step 02 需包含列表首行标题'支付按钮点击无响应'、优先级'高'和指派给'张三'；Step 03 需包含首行为刚提交的'支付按钮点击无响应'工单且统计卡片'总工单数'为7（与步骤2一致）；Step 04 需包含优先级筛选为'高'，工单列表中数量为3且所有工单优先级都为'高'；Step 05 '支付按钮点击无响应'工单状态为'处理中'；Step 06 '支付按钮点击无响应'工单状态为'已解决'；Step 07 需包含统计卡片'总工单数'为7和'已解决'为2。若上述任一条件不符合，则不通过。",
    "weight": 1
  }
]
```
