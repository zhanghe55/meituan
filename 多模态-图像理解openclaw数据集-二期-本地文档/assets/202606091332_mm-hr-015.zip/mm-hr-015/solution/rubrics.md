# Rubrics

> **通过标准：所有 rubric 均须满足，该任务才算通过。任一 rubric 不通过，则整体判定为 FAIL。**

## 文件读取路径

```path
/meituan/mm-hr-015/input/answer/技术序列任职资格评审初判及薪酬预匹配清单.xlsx
/meituan/mm-hr-015/solution/技术序列任职资格评审初判及薪酬预匹配清单-参考答案.xlsx
```

```json
[
  {
    "id": "01",
    "content": "输出的<file>/meituan/mm-hr-015/input/answer/技术序列任职资格评审初判及薪酬预匹配清单.xlsx</file>文档中文字和数值需要和<file>/meituan/mm-hr-015/solution/技术序列任职资格评审初判及薪酬预匹配清单-参考答案.xlsx</file>中的文字和数值一致'",
    "weight": 1
  }
]
```